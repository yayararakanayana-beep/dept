# Profile Validation Guide

## world_profile

疑似現実系を切り替える単位です。

置き場:

```text
configs/world_profiles/
```

例:

```text
pseudo_reality_default
pseudo_reality_shock
pseudo_reality_high_noise
```

## action_profile

作用側の設定を切り替える単位です。

置き場:

```text
configs/action_profiles/
```

注意:

```text
ActionModuleへParameterBoxを直接渡してはいけない。
作用profileはFullSpecRunnerConfig経由で作用結合や作用候補生成設定を変える。
```

## validation_profile

検証条件を切り替える単位です。

置き場:

```text
configs/validation_profiles/
```

## matrix

world_profile / action_profile / validation_profile の組み合わせです。

置き場:

```text
configs/matrices/
```

実行:

```bash
python scripts/run_matrix_validation.py --matrix configs/matrices/matrix_basic.json
```
