# GitHub投入手順

## 前提

このパッケージの `dept/` ディレクトリをGitHub repoの起点として扱います。

過去方針どおり、Codexに修正を任せきるのではなく、Codex/GitHub環境ではまず検証だけを行います。

```text
ChatGPT:
  コード作成・修正

GitHub:
  正本置き場

Codex:
  GitHub環境で検証実行
  ログ取得
  必要ならPR作成補助
```

## GitHubへ置くもの

```text
dept/
```

## Codex/GitHub環境でまず実行するコマンド

```bash
python -m compileall .
python scripts/run_smoke_validation.py
python scripts/run_q9_full_integration_validation.py
python scripts/run_matrix_validation.py --matrix configs/matrices/matrix_basic.json
```

## 問題が出た場合

Codexで無理に修正を続けず、以下をChatGPTへ戻します。

```text
validation_runs/latest/matrix_summary.json
validation_runs/latest/matrix_metrics.csv
validation_runs/latest/boundary_violation_report.csv
stderr / 実行ログ
```

## 重要

mainへ直接pushしない。まず新branchで検証し、問題なければPRにします。
