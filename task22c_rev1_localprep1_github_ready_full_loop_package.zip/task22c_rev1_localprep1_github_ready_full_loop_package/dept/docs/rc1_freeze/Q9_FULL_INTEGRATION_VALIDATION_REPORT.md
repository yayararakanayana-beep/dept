# Task22C-Rev1-Q9 Full integration validation

## 目的

Q9では、Q8で実装したcontrolled canonical updateを、FullSpec runnerの一連の閉ループ内で検証しました。
見る対象は、canonical本更新が入っても境界を壊さないか、dry-runが安全か、rollback snapshotが常にあるか、canonical値を後段窓口に使っても探索・作用が消えないか、です。

## 実行条件

```text
runs: 8
scenarios: normal / relation_lock / exploration_loss / shock
modes: dry-run, enabled+shadow-binding, enabled+canonical-binding
stress: shock mid, steps=12, high noise
```

## 全体判定

```text
overall_pass: True
boundary_violation_zero: True
dry_run_write_zero: True
rollback_every_step: True
no_forbidden_write: True
projection_not_collapsed: True
```

## 主要結果

| label | mode | scenario | steps | 境界違反 | canonical write | dry-run違反 | rollback snapshot | 探索射影 | 作用Frame強度 | gate危険度 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| dryrun_normal_shadow | dry-run | normal | 8 | 0 | 0 | False | 8 | 43 | 4.832 | 0.427 |
| dryrun_shock_shadow | dry-run | shock | 8 | 0 | 0 | False | 8 | 27 | 4.769 | 0.483 |
| enabled_shadowbind_normal | enabled-shadow | normal | 8 | 0 | 1 | False | 8 | 43 | 4.832 | 0.427 |
| enabled_canonbind_normal | enabled-canonical | normal | 8 | 0 | 1 | False | 8 | 42 | 4.943 | 0.430 |
| enabled_canonbind_relation_lock | enabled-canonical | relation_lock | 8 | 0 | 1 | False | 8 | 2 | 5.170 | 0.447 |
| enabled_canonbind_exploration_loss | enabled-canonical | exploration_loss | 8 | 0 | 1 | False | 8 | 45 | 4.868 | 0.497 |
| enabled_canonbind_shock | enabled-canonical | shock | 8 | 0 | 1 | False | 8 | 22 | 4.863 | 0.480 |
| stress_shock_mid | enabled-canonical | shock | 12 | 0 | 2 | False | 12 | 56 | 7.353 | 0.493 |

## 確認できたこと

```text
- dry-runではcanonical writeが0件
- enabledではcommit gate通過時だけcanonical write
- rollback snapshotは全stepで生成
- world / G/K / O_t writebackは0件
- ActionModuleへのParameterBox直接入力は0件
- canonical_binding_source=canonicalでも探索射影は0件に潰れていない
- max canonical deltaは設定上限内
```

## 注意点

Q9のshock系では、初期の最小観測窓・cooldown・rate limitは効いています。
ただし、shockシナリオ全体を常にshock-likeとして止めるわけではありません。持続的な変化として見なされた後は、弱いcanonical commitが許可されます。
これは「一過性shockを止める」「持続変化は追う」というTask22Cの方針には合っていますが、Q10凍結時の既知制限として、shock分類はscenario/seedに依存すると明記するのが安全です。

## Q9判定

```text
Task22C-Rev1-Q9: pass
controlled canonical update はFullSpec閉ループ内で統合検証を通過
```

## 次

```text
Task22C-Rev1-Q10: RC1 Freeze
```
