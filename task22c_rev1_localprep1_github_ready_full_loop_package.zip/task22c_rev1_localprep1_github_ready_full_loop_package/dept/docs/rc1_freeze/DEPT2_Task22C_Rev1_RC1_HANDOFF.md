# DEPT2 Task22C Rev1 RC1 Handoff

## 現在地

Task22C-Rev1-Q10 RC1 Freeze完了。

このfreezeは、ParameterBox本更新モジュールをFullSpec閉ループrunnerに統合し、controlled canonical updateとして検証した到達点です。

## 次に直接使うコード

```text
DEPT2_Task22C_Rev1_RC1_Code/
```

ここが次チャット・次フェーズで直接編集する起点です。

## 実行例

```bash
cd DEPT2_Task22C_Rev1_RC1_Code
python - <<'PY'
from dept2_fullspec_runner_rc1.runner.fullspec_integrated_closed_loop_runner import run_fullspec_task16
from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig

out = run_fullspec_task16(FullSpecRunnerConfig(
    steps=8,
    seed=1,
    scenario="normal",
    canonical_commit_enabled=True,
    canonical_commit_dry_run=False,
    canonical_binding_source="canonical",
))
print(out["boundary_violation_report"].shape)
print(out["canonical_write_audit"][[
    "loop_step",
    "commit_gate_passed",
    "commit_gate_reason",
    "canonical_write_performed",
]])
PY
```

## 最重要の構造

```text
ParameterShadowBox:
  H11局所圧場からshadow候補を作る

ControlledCanonicalUpdateModule:
  shadow候補をcommit gateで評価する
  rollback snapshotを作る
  条件を満たした時だけcanonical stateへcommitする

ParameterWindowBinder:
  shadowまたはcanonicalのParameterBox値を各モジュール窓口へ束縛する

ActionModule:
  ParameterBoxを直接読まない
  ActionFrameだけを受け取る
```

## 絶対に壊してはいけない境界

```text
- ParameterBox -> ActionModule 直結禁止
- upper pressure -> ActionSurface 直投入禁止
- ParameterBox -> world/G/K/O_t writeback禁止
- dry-run中のcanonical write禁止
- rollback snapshotなしのcanonical write禁止
- commit gateなしのcanonical write禁止
```

## 主要ファイル

```text
dept2_fullspec_runner_rc1/modules/controlled_canonical_update.py
dept2_fullspec_runner_rc1/modules/parameter_window_binder.py
dept2_fullspec_runner_rc1/modules/parameter_shadow_box.py
dept2_fullspec_runner_rc1/runner/fullspec_integrated_closed_loop_runner.py
dept2_fullspec_runner_rc1/modules/boundary_guard.py
dept2_fullspec_runner_rc1/modules/audit_ledger_module.py
dept2_fullspec_runner_rc1/contracts/cycle_state.py
```

## 既知制限

```text
- canonical stateはin-memory
- 永続化は未実装
- shock分類はscenario/seed依存が残る
- 長期・多seed・大規模検証はRC2以降
```

## 次フェーズ候補

```text
Task22C-Rev1-RC2-A:
  canonical state永続化設計

Task22C-Rev1-RC2-B:
  shock分類強化 + 多seed長期stress validation

Task22C-Rev1-RC2-C:
  rollback実行経路の強制fail検証

Task22C-Rev1-RC2-D:
  RC2 Freeze
```
