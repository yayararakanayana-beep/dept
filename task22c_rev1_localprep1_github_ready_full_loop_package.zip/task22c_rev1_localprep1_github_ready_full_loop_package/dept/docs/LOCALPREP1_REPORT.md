# Task22C-Rev1-LocalPrep-1 GitHub投入前フル統合閉ループ実行パッケージ

## 結論

LocalPrep-1 は完了です。

```text
compile:
  pass: True

smoke validation:
  pass: True
  boundary_violation_rows: 0
  canonical_write_rows: 0
  projection_rows: 15
  action_frame_rows: 440

q9 localprep validation:
  pass: True
  runs: 6
  boundary_violation_total: 0
  dry_run_write_violation_count: 0
  forbidden_write_count: 0
  projection_min: 6

matrix_basic validation:
  pass: True
  runs: 4
  boundary_violation_total: 0
  forbidden_write_count: 0
  projection_min: 25
```

総合判定:

```text
Task22C-Rev1-LocalPrep-1:
  pass
```

## このパッケージの目的

Q10 RC1 Freezeコードを、GitHub / Codex環境に置いてそのまま検証できるrepo構成に整理しました。

今回の重点は、単なるQ9再実行ではなく、今後の検証で使う以下の切替を入れることです。

```text
world_profile:
  疑似現実系を切り替える

action_profile:
  作用側の設定を切り替える

validation_profile:
  検証条件を切り替える
```

## 追加した主な構造

```text
configs/world_profiles/
configs/action_profiles/
configs/validation_profiles/
configs/matrices/
scripts/run_smoke_validation.py
scripts/run_full_loop_validation.py
scripts/run_q9_full_integration_validation.py
scripts/run_matrix_validation.py
validation_runs/localprep_smoke/
validation_runs/localprep_q9/
validation_runs/latest/
```

## 疑似現実系profile

現在用意したworld_profileです。

```text
pseudo_reality_default
pseudo_reality_relation_lock
pseudo_reality_exploration_loss
pseudo_reality_shock
pseudo_reality_high_noise
pseudo_reality_slow_drift
```

外から変えられる主な値です。

```text
scenario
n_entities
noise_scale
drift_scale
action_coupling
shock_time
shock_strength
```

## 作用profile

現在用意したaction_profileです。

```text
action_default
action_conservative
action_low_coupling
action_aggressive_probe
action_buffered
```

外から変えられる主な値です。

```text
action_coupling
min_action_strength
max_action_strength
strength_scale
alignment_threshold
```

## 実行コマンド

```bash
python -m compileall .
python scripts/run_smoke_validation.py
python scripts/run_q9_full_integration_validation.py
python scripts/run_matrix_validation.py --matrix configs/matrices/matrix_basic.json
```

単発でprofileを指定する場合:

```bash
python scripts/run_full_loop_validation.py \
  --validation-profile q9_default \
  --world-profile pseudo_reality_shock \
  --action-profile action_conservative \
  --label shock_conservative
```

## 出力先

```text
validation_runs/latest/
```

今回の検証では、比較しやすいように以下も保存しています。

```text
validation_runs/localprep_smoke/
validation_runs/localprep_q9/
validation_runs/latest/  # matrix_basic
```

## 境界条件

今回の検証でも以下は維持されています。

```text
ParameterBoxをActionModuleへ直接渡さない
上位圧をActionSurfaceへ直接足さない
ParameterBoxからworld/G/K/O_tへ書き戻さない
dry-run中はcanonical writeしない
commit gateなしでcanonical writeしない
rollback snapshotなしでcanonical writeしない
```

## 注意

実行環境によっては `artifact_tool` の spreadsheet warmup 警告がstderrに出ることがあります。対象スクリプトのreturncodeが0で、summaryがpassならLocalPrep検証としては成功扱いです。
