# Latest matrix validation

matrix: `matrix_basic`

overall_pass: `True`

See `matrix_summary.json`, `matrix_metrics.csv`, and per-run CSV files.
