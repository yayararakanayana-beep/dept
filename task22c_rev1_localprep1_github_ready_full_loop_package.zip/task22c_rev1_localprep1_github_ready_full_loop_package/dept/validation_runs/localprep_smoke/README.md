# Latest validation run

label: `smoke`

overall_pass: `True`

See `summary.json` and CSV audit files.
