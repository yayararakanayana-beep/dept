"""parameter_shadow_box: Task6 shadow-only parameter integration.

Task6 strengthens the parameter-shadow boundary:
  * lower parameters may be updated only in runner-owned shadow state;
  * shadow state carries across cycles to expose delayed effects;
  * every cycle emits a parameter_shadow_audit row;
  * canonical theta, world state, and canonical G/K writes remain forbidden.

The existing RC1 LowerParameterGovernanceBox still computes the bounded weak
update from formal G/K plus H11-local pressure. This wrapper turns that into an
auditable shadow contract and refuses lower-artifact leakage.
"""
from __future__ import annotations

import hashlib
from typing import Dict

import pandas as pd

from DEPT2_ActionModule_ActuationPrimitives_RC1.dept2_system.parameter_box import LowerParameterGovernanceBox


FORBIDDEN_INPUT_PREFIXES = (
    "ot_", "v8_", "exploration_", "graph_object", "action_surface",
    "action_", "final_gate", "coactivation_", "sidecar", "world_truth",
)


def _fingerprint_mapping(values: Dict[str, float]) -> str:
    if not values:
        return "empty"
    payload = "|".join(f"{k}:{float(values[k]):.12f}" for k in sorted(values))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def _fingerprint_df(df: pd.DataFrame) -> str:
    if df is None or df.empty:
        return "empty"
    payload = pd.util.hash_pandas_object(df.sort_index(axis=1), index=True).values.tobytes()
    return hashlib.sha256(payload).hexdigest()[:16]


class ParameterShadowBox:
    name = "parameter_shadow_box"

    def __init__(self):
        self.box = LowerParameterGovernanceBox()
        self._cycle_index = 0
        self._last_shadow_fingerprint = _fingerprint_mapping(self.box.current_params())
        self._shadow_history: list[dict] = []

    def update_shadow(self, formal_packet: pd.DataFrame, h11_local_pressure_field: pd.DataFrame, *, loop_step: int | None = None) -> dict[str, pd.DataFrame]:
        """Apply a bounded shadow-only update and emit full audit tables.

        The state inside ``LowerParameterGovernanceBox`` is used only as shadow
        carryover. It is not a canonical theta store. The emitted tables make
        that explicit so later commit-gate work can be separated cleanly.
        """
        self._validate_inputs(formal_packet, h11_local_pressure_field)
        before_params = self.box.current_params()
        before_fp = _fingerprint_mapping(before_params)
        formal_fp = _fingerprint_df(formal_packet)
        h11_fp = _fingerprint_df(h11_local_pressure_field)

        registry, updates = self.box.update(formal_packet, h11_local_pressure_field)
        after_params = self.box.current_params()
        after_fp = _fingerprint_mapping(after_params)
        effective_step = self._cycle_index if loop_step is None else int(loop_step)
        self._cycle_index = max(self._cycle_index + 1, effective_step + 1)

        registry = registry.copy()
        registry["parameter_registry_contract"] = "task6_shadow_registry_reference_only__not_canonical_theta_store__RC1"
        registry["canonical_theta_source"] = "none__shadow_only_runner_state"
        registry["canonical_write_allowed"] = False

        updates = updates.copy()
        if updates.empty:
            updates = pd.DataFrame(columns=[
                "parameter_name", "theta_before", "theta_after", "theta_delta",
                "system_caution", "exploration_need", "relation_lock_need", "pressure_signal", "h11_signal",
                "update_contract", "truth_used_for_parameter_update",
            ])
        updates["parameter_update_mode"] = "shadow_only"
        updates["shadow_carryover_enabled"] = True
        updates["shadow_cycle_index"] = effective_step
        updates["shadow_source"] = "runner_owned_parameter_shadow_state"
        updates["commit_status"] = "not_committed"
        updates["commit_gate_passed"] = False
        updates["lower_parameter_update_committed"] = False
        updates["canonical_write_performed"] = False
        updates["canonical_theta_written"] = False
        updates["world_write_performed"] = False
        updates["world_state_written"] = False
        updates["gk_writeback_performed"] = False
        updates["canonical_gk_written"] = False
        updates["rollback_ready"] = True
        updates["parameter_shadow_contract"] = (
            "bounded_shadow_carryover_only__no_commit__no_canonical_theta_write__"
            "no_world_write__no_GK_writeback__Task6_RC1"
        )
        updates["shadow_previous_fingerprint"] = before_fp
        updates["shadow_next_fingerprint"] = after_fp
        updates["formal_packet_fingerprint"] = formal_fp
        updates["h11_pressure_fingerprint"] = h11_fp

        max_abs_delta = float(updates["theta_delta"].abs().max()) if "theta_delta" in updates.columns and not updates.empty else 0.0
        total_abs_delta = float(updates["theta_delta"].abs().sum()) if "theta_delta" in updates.columns and not updates.empty else 0.0
        updated_rows = int((updates["theta_delta"].abs() > 1e-12).sum()) if "theta_delta" in updates.columns and not updates.empty else 0
        max_allowed_delta = float(registry["max_step_delta"].max()) if "max_step_delta" in registry.columns and not registry.empty else 0.0
        bounded_delta_pass = bool(max_abs_delta <= max_allowed_delta + 1e-12)

        current_rows = []
        for k, v in after_params.items():
            before_v = float(before_params.get(k, v))
            current_rows.append({
                "parameter_name": k,
                "shadow_theta": float(v),
                "shadow_theta_previous": before_v,
                "shadow_theta_delta_from_previous": float(v) - before_v,
                "shadow_cycle_index": effective_step,
                "shadow_fingerprint": after_fp,
                "previous_shadow_fingerprint": before_fp,
                "shadow_contract": "shadow_carryover_only__no_canonical_write__Task6_RC1",
                "shadow_state_owner": "parameter_shadow_box",
                "canonical_theta_written": False,
                "world_state_written": False,
                "canonical_gk_written": False,
                "rollback_ready": True,
            })
        current = pd.DataFrame(current_rows)

        audit = pd.DataFrame([{
            "parameter_shadow_contract": "Task6_parameter_shadow_box__bounded_shadow_carryover_only__not_committed__RC1",
            "shadow_cycle_index": effective_step,
            "formal_packet_fingerprint": formal_fp,
            "h11_pressure_fingerprint": h11_fp,
            "previous_shadow_fingerprint": before_fp,
            "new_shadow_fingerprint": after_fp,
            "previous_shadow_fingerprint_matches_last_cycle": bool(before_fp == self._last_shadow_fingerprint),
            "shadow_carryover_enabled": True,
            "shadow_state_rows": int(len(current)),
            "parameter_registry_rows": int(len(registry)),
            "parameter_update_rows": int(len(updates)),
            "updated_parameter_rows": updated_rows,
            "max_abs_theta_delta": max_abs_delta,
            "total_abs_theta_delta": total_abs_delta,
            "max_allowed_step_delta": max_allowed_delta,
            "bounded_delta_pass": bounded_delta_pass,
            "rollback_ready": True,
            "commit_status": "not_committed",
            "commit_gate_passed": False,
            "lower_parameter_update_committed": False,
            "canonical_write_performed": False,
            "canonical_theta_written": False,
            "world_write_performed": False,
            "world_state_written": False,
            "gk_writeback_performed": False,
            "canonical_gk_written": False,
            "formal_lower_leak_count": 0,
            "h11_lower_leak_count": 0,
            "truth_used_for_parameter_update": bool(updates.get("truth_used_for_parameter_update", pd.Series([False])).astype(bool).any()) if not updates.empty else False,
            "audit_status": "pass" if bounded_delta_pass else "fail",
        }])

        self._last_shadow_fingerprint = after_fp
        self._shadow_history.append(audit.iloc[0].to_dict())
        return {
            "parameter_registry": registry,
            "parameter_updates": updates,
            "shadow_parameter_state": current,
            "parameter_shadow_audit": audit,
        }

    def current_params(self) -> dict:
        return self.box.current_params()

    def _validate_inputs(self, formal_packet: pd.DataFrame, h11_local_pressure_field: pd.DataFrame) -> None:
        for label, df in [("formal_packet", formal_packet), ("h11_local_pressure_field", h11_local_pressure_field)]:
            if df is None or df.empty:
                raise ValueError(f"parameter_shadow_box requires non-empty {label}")
            leaked = [c for c in df.columns if c.startswith(FORBIDDEN_INPUT_PREFIXES)]
            if leaked:
                raise ValueError(f"parameter_shadow_box lower artifact leakage in {label}: {leaked}")
