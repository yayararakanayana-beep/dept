#!/usr/bin/env python3
"""CLI entrypoint for Task16 Minimal Integration Test RC1."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner


def main() -> None:
    parser = argparse.ArgumentParser(description="Run DEPT2 FullSpec Task16 minimal integration test RC1")
    parser.add_argument("--steps", type=int, default=2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--scenario", type=str, default="normal", choices=["normal", "exploration_loss", "relation_lock", "shock"])
    parser.add_argument("--out", type=Path, default=ROOT / "results")
    parser.add_argument("--exploration-enabled", action="store_true", help="Enable Task12 exploration + local audit + bridge + coactivation gate pipeline. Default config also enables exploration.")
    parser.add_argument("--exploration-disabled", action="store_true", help="Disable exploration module for boundary regression checks.")
    args = parser.parse_args()

    exploration_enabled = True
    if args.exploration_disabled:
        exploration_enabled = False
    elif args.exploration_enabled:
        exploration_enabled = True

    cfg = FullSpecRunnerConfig(
        steps=args.steps,
        seed=args.seed,
        scenario=args.scenario,
        exploration_enabled=exploration_enabled,
    )
    runner = FullSpecIntegratedClosedLoopRunner(cfg)
    summary = runner.write_outputs(args.out)
    print(summary)


if __name__ == "__main__":
    main()
