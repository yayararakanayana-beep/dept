from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner
from dept2_fullspec_runner_rc1.modules.action_surface_planning_module import ActionSurfacePlanningModule


def test_task11_action_surface_planning_audit_is_emitted_and_passes():
    cfg = FullSpecRunnerConfig(steps=3, seed=111, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    audit = out["cycle_audit_row"]
    planning = out["action_surface_planning_audit"]
    assert len(audit) == 3
    assert len(planning) == 3
    assert int(audit["boundary_violation_count"].sum()) == 0
    assert audit["action_surface_planning_status"].eq("pass").all()
    assert planning["audit_status"].eq("pass").all()
    assert planning["pressure_intent_used"].astype(bool).all()
    assert planning["ot_action_view_used"].astype(bool).all()
    assert planning["shadow_parameter_summary_used"].astype(bool).all()
    assert planning["candidates_have_required_contract"].astype(bool).all()


def test_task11_action_candidates_are_pre_actionframe_only():
    cfg = FullSpecRunnerConfig(steps=2, seed=112, scenario="relation_lock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    candidates = out["action_candidates"]
    planning = out["action_surface_planning_audit"]
    assert not candidates.empty
    assert candidates["candidate_status"].eq("pre_gate_candidate").all()
    assert candidates["action_candidate_contract"].astype(str).str.contains("pre_ActionFrame_candidate", regex=False).all()
    assert not candidates["action_frame_created_by_planning"].astype(bool).any()
    assert not candidates["actionmodule_called_by_planning"].astype(bool).any()
    assert not candidates["canonical_parameter_write"].astype(bool).any()
    assert not candidates["world_write_performed"].astype(bool).any()
    assert not candidates["gk_writeback_performed"].astype(bool).any()
    assert not planning["action_frame_created_by_planning"].astype(bool).any()
    assert not planning["actionmodule_called_by_planning"].astype(bool).any()


def test_task11_local_observation_needs_are_emitted_from_ot_action_view():
    cfg = FullSpecRunnerConfig(steps=1, seed=113, scenario="shock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    needs = out["local_observation_needs"]
    ot_action = out["ot_action_view"]
    assert not needs.empty
    assert len(needs) == ot_action["entity_id"].nunique()
    assert needs["need_source_contract"].astype(str).str.contains("O_t_action_view", regex=False).all()
    assert not needs["action_frame_created_by_need_builder"].astype(bool).any()
    assert not needs["actionmodule_called_by_need_builder"].astype(bool).any()
    assert (needs["local_observation_need_score"].astype(float) >= 0).all()


def test_task11_action_surface_planning_rejects_direct_action_or_writeback_leakage():
    cfg = FullSpecRunnerConfig(steps=1, seed=114, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    module = ActionSurfacePlanningModule(cfg)
    graph = out["ot_native"].copy()
    # Use actual graph objects indirectly unavailable here; leakage guard triggers before graph use.
    intents = out["pressure_intent_bundle"].copy()
    intents["action_frame_illegal_hint"] = True
    with pytest.raises(ValueError):
        module.plan(
            graph_objects=out["action_affordance"].head(1),
            pressure_intents=intents,
            shadow_params={"action_intensity_cap": 0.5},
            exploration_projection=out["exploration_projection"],
            step=0,
            seed=114,
            scenario="normal",
            ot_action_view=out["ot_action_view"],
        )


def test_task11_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=115, scenario="exploration_loss")
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["action_surface_planning_module_strengthened"] is True
    assert summary["action_surface_planning_audit_rows"] == 2
    assert summary["local_observation_need_rows"] > 0
    assert summary["action_surface_planning_audit_passed"] is True
    assert summary["action_surface_planning_pre_actionframe_only"] is True
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_action_surface_planning_audit_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_local_observation_needs_RC1.csv").exists()
