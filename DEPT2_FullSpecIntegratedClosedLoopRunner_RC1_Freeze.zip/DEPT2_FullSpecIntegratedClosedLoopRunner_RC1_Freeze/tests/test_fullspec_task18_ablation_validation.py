from pathlib import Path
import json
import sys
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from validation.task18_ablation_validation import run_ablation_validation


@pytest.fixture(scope="session")
def task18_outputs(tmp_path_factory):
    out = tmp_path_factory.mktemp("task18_ablation")
    return out, run_ablation_validation(out)


def test_task18_ablation_matrix_runs(task18_outputs):
    out, outputs = task18_outputs
    matrix = outputs["matrix"]
    assert len(matrix) >= 7
    assert set(["A00_full_integrated_baseline", "A01_no_exploration_module", "A05_no_coactivation_gate_modulation"]).issubset(set(matrix["ablation_id"]))
    assert int(matrix["boundary_violation_count"].sum()) == 0
    assert not matrix["canonical_write_performed"].astype(bool).any()
    assert not matrix["world_write_performed"].astype(bool).any()
    assert not matrix["gk_writeback_performed"].astype(bool).any()


def test_task18_exploration_ablation_removes_projection(task18_outputs):
    out, outputs = task18_outputs
    matrix = outputs["matrix"].set_index("ablation_id")
    base_projection = int(matrix.loc["A00_full_integrated_baseline", "exploration_projection_rows"])
    no_exp_projection = int(matrix.loc["A01_no_exploration_module", "exploration_projection_rows"])
    assert base_projection > 0
    assert no_exp_projection == 0


def test_task18_gate_ablation_forces_allow_but_preserves_guard(task18_outputs):
    out, outputs = task18_outputs
    matrix = outputs["matrix"].set_index("ablation_id")
    gate_case = matrix.loc["A05_no_coactivation_gate_modulation"]
    assert int(gate_case["gate_allow_count"]) == int(gate_case["steps"])
    assert int(gate_case["boundary_violation_count"]) == 0
    assert "gate_modulation_absent_under_risk" in json.loads(gate_case["ablation_watch_flags_json"])


def test_task18_delta_and_interpretation_written(task18_outputs):
    out, outputs = task18_outputs
    assert not outputs["delta"].empty
    assert not outputs["interpretation"].empty
    assert (out / "fullspec_task18_ablation_matrix_RC1.csv").exists()
    assert (out / "task18_ablation_validation_summary_RC1.json").exists()
    summary = json.loads((out / "task18_ablation_validation_summary_RC1.json").read_text(encoding="utf-8"))
    assert summary["aggregate"]["all_cases_no_boundary_violation"] is True
