from pathlib import Path
import sys

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner
from dept2_fullspec_runner_rc1.modules.pressure_translation_module import PressureTranslationModule


def test_task9_pressure_translation_audit_is_emitted_and_passes():
    cfg = FullSpecRunnerConfig(steps=3, seed=91, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    audit = out["cycle_audit_row"]
    translation = out["pressure_translation_audit"]
    assert len(audit) == 3
    assert len(translation) == 3
    assert int(audit["boundary_violation_count"].sum()) == 0
    assert audit["pressure_translation_status"].eq("pass").all()
    assert audit["pressure_translation_noncompressive_passed"].astype(bool).all()
    assert audit["pressure_translation_components_preserved"].astype(bool).all()
    assert audit["pressure_translation_direction_preserved"].astype(bool).all()
    assert translation["pressure_translation_audit_status"].eq("pass").all()


def test_task9_h11_and_intents_preserve_components_without_action_compression():
    cfg = FullSpecRunnerConfig(steps=1, seed=92, scenario="relation_lock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    h11 = out["h11_local_pressure_field"]
    intents = out["pressure_intent_bundle"]
    assert not h11.empty
    assert not intents.empty
    assert h11["component_identity_preserved"].astype(bool).all()
    assert h11["noncompressive_translation"].astype(bool).all()
    assert intents["component_identity_preserved"].astype(bool).all()
    assert intents["component_direction_preserved"].astype(bool).all()
    assert not intents["compression_allowed_before_action_planner"].astype(bool).any()
    approved = {c.replace("approved_", "") for c in out["weak_pressure"].columns if c.startswith("approved_") and c != "approved_component_l1"}
    assert approved.issubset(set(h11["pressure_component"].astype(str)))
    assert approved.issubset(set(intents["pressure_component"].astype(str)))


def test_task9_pressure_translation_does_not_create_actionframe_or_call_actionmodule():
    cfg = FullSpecRunnerConfig(steps=2, seed=93, scenario="shock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    translation = out["pressure_translation_audit"]
    assert not translation["action_frame_created_by_translation"].astype(bool).any()
    assert not translation["actionmodule_called_by_translation"].astype(bool).any()
    assert not translation["translation_writeback_performed"].astype(bool).any()
    assert not translation["translation_uses_ot"].astype(bool).any()
    assert not translation["translation_uses_v8"].astype(bool).any()
    assert not translation["translation_uses_exploration"].astype(bool).any()
    assert not translation["translation_uses_action_surface"].astype(bool).any()
    assert not translation["translation_uses_action_result"].astype(bool).any()


def test_task9_pressure_translation_rejects_lower_artifact_leakage():
    cfg = FullSpecRunnerConfig(steps=1, seed=94, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    m = out["m_observation"].copy()
    weak = out["weak_pressure"].copy()
    m["ot_illegal_hint"] = 0.1
    with pytest.raises(ValueError):
        PressureTranslationModule().translate(m, weak, loop_step=0)
    weak2 = weak.copy()
    weak2["exploration_illegal_hint"] = 0.2
    with pytest.raises(ValueError):
        PressureTranslationModule().translate(out["m_observation"], weak2, loop_step=0)


def test_task9_pressure_translation_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=95, scenario="exploration_loss")
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["pressure_translation_module_strengthened"] is True
    assert summary["pressure_translation_audit_rows"] == 2
    assert summary["pressure_translation_audit_passed"] is True
    assert summary["pressure_translation_noncompressive_passed"] is True
    assert summary["pressure_translation_components_preserved"] is True
    assert summary["pressure_translation_direction_preserved"] is True
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_pressure_translation_audit_RC1.csv").exists()
