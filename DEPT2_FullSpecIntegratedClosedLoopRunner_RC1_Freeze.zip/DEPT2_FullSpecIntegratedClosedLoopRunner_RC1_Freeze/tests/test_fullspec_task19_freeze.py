from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from validation.task19_freeze_validation import run_task19_freeze_validation


def test_task19_freeze_acceptance(tmp_path: Path):
    summary = run_task19_freeze_validation(tmp_path / "task19_freeze_validation")
    assert summary["status"] == "freeze_pass"
    assert summary["all_required_checks_passed"] is True
    assert summary["task16_failed_case_count"] == 0
    assert summary["task17_fail_count"] == 0
    assert summary["task18_fail_count"] == 0
    assert summary["task17_total_boundary_violations"] == 0
    assert summary["task18_total_boundary_violations"] == 0
    assert summary["canonical_write_enabled"] is False
    assert summary["gk_writeback_enabled"] is False
    assert summary["deployment_claim_allowed"] is False


def test_task19_claim_boundary_file(tmp_path: Path):
    out = tmp_path / "task19_freeze_validation"
    summary = run_task19_freeze_validation(out)
    claim_file = Path(summary["claim_boundary_file"])
    text = claim_file.read_text(encoding="utf-8")
    assert "deployment_ready,forbidden" in text
    assert "canonical_parameter_update_enabled,forbidden" in text
    assert "limited_synthetic_pseudo_reality_integrated_closed_loop_runner_freeze__RC1,allowed" in text
