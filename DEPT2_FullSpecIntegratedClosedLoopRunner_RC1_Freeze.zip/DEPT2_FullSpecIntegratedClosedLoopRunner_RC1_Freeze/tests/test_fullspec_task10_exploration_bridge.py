from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner


def test_task10_bridge_emits_projection_and_noncompressed_sidecar():
    cfg = FullSpecRunnerConfig(steps=3, seed=1010, scenario="normal", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    projection = out["exploration_projection"]
    sidecar = out["exploration_sidecar"]
    assert not projection.empty
    assert not sidecar.empty
    assert sidecar["full_context_present"].astype(bool).all()
    assert sidecar["sidecar_is_noncompressed"].astype(bool).all()
    assert sidecar["sidecar_contains_decision"].astype(bool).all()
    assert sidecar["sidecar_contains_sandbox"].astype(bool).all()
    assert sidecar["sidecar_contains_local_audit"].astype(bool).all()
    assert projection["projection_is_thin"].astype(bool).all()
    assert not projection["projection_contains_full_sidecar_payload"].astype(bool).any()


def test_task10_projection_is_verified_and_references_sidecar():
    cfg = FullSpecRunnerConfig(steps=2, seed=1011, scenario="normal", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    projection = out["exploration_projection"]
    sidecar = out["exploration_sidecar"]
    assert not projection.empty
    assert projection["projection_source_verified"].astype(bool).all()
    assert projection["projection_source_local_audit_passed"].astype(bool).all()
    assert projection["projection_source_v8_status"].eq("pass").all()
    assert set(projection["sidecar_id"].astype(str)).issubset(set(sidecar["sidecar_id"].astype(str)))
    assert projection["projection_contract"].str.contains("thin_projection_only", regex=False).all()


def test_task10_bridge_boundary_no_sidecar_direct_to_actionmodule():
    cfg = FullSpecRunnerConfig(steps=2, seed=1012, scenario="relation_lock", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    guard = out["boundary_guard_audit"]
    rule = guard[guard["rule_id"].eq("BG11_exploration_sidecar_retained_projection_thin")]
    assert not rule.empty
    assert rule["guard_status"].eq("pass").all()
    assert out["boundary_violation_report"].empty
    assert not out["action_execution_audit"]["direct_exploration_sidecar_input_to_actionmodule"].astype(bool).any()


def test_task10_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=1013, scenario="normal", exploration_enabled=True)
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["exploration_bridge_module_integrated"] is True
    assert summary["exploration_projection_rows"] > 0
    assert summary["exploration_sidecar_rows"] > 0
    assert summary["exploration_projection_all_verified"] is True
    assert summary["exploration_projection_all_local_audit_passed"] is True
    assert summary["exploration_projection_is_thin"] is True
    assert summary["exploration_bridge_sidecar_noncompressed"] is True
    assert summary["exploration_sidecar_direct_actionmodule_input"] is False
    assert summary["boundary_violation_count"] == 0
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_exploration_projection_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_exploration_sidecar_RC1.csv").exists()
