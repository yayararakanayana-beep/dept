from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner
from dept2_fullspec_runner_rc1.modules.boundary_guard import BoundaryGuard


def test_task15_boundary_guard_audits_all_rules_each_cycle():
    cfg = FullSpecRunnerConfig(steps=3, seed=151, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    guard = out["boundary_guard_audit"]
    assert not guard.empty
    assert guard["loop_step"].nunique() == cfg.steps
    assert guard.groupby("loop_step")["rule_id"].nunique().min() >= 16
    assert guard["guard_status"].eq("pass").all()
    assert not guard[[
        "guard_writes_world",
        "guard_writes_gk",
        "guard_writes_ot",
        "guard_writes_actionframe",
        "guard_writes_canonical_parameter",
    ]].astype(bool).any().any()


def test_task15_boundary_violation_report_empty_when_all_pass():
    cfg = FullSpecRunnerConfig(steps=2, seed=152, scenario="shock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    report = out["boundary_violation_report"]
    assert list(report.columns) == [
        "run_seed", "run_scenario", "loop_step", "violation_source", "rule_id",
        "boundary_domain", "severity", "violation_detail",
        "task15_violation_report_contract",
    ]
    assert report.empty
    summary = out["boundary_guard_summary"].iloc[0]
    assert bool(summary["all_boundary_rules_passed"])
    assert bool(summary["boundary_guard_diagnostic_only"])
    assert summary["boundary_guard_status"] == "pass"


def test_task15_boundary_guard_detects_injected_upper_pressure_leak():
    guard = BoundaryGuard()
    fake_guard = pd.DataFrame([{
        "run_seed": 1,
        "run_scenario": "unit",
        "loop_step": 0,
        "rule_id": "BG07_upper_pressure_formal_gk_only",
        "boundary_domain": "upper_pressure_module",
        "invariant_jp": "上位圧はG/Kのみ",
        "expected": "pass",
        "observed": "formal_lower_leak_count=1",
        "guard_status": "fail",
        "severity": "block_on_fail",
        "source_audit_table": "upper_pressure_audit",
        "boundary_guard_contract": "Task15_unified_boundary_guard__diagnostic_only__no_runtime_writeback__RC1",
        "guard_writes_world": False,
        "guard_writes_gk": False,
        "guard_writes_ot": False,
        "guard_writes_actionframe": False,
        "guard_writes_canonical_parameter": False,
    }])
    violations = guard.validate_boundary_guard_audit(fake_guard)
    assert any("boundary_guard_rule_failed" in v for v in violations)
    report = guard.build_boundary_violation_report(fake_guard, violations)
    assert len(report) >= 1
    assert "BG07_upper_pressure_formal_gk_only" in "|".join(report["rule_id"].astype(str)) or "legacy_validation" in set(report["rule_id"])


def test_task15_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=155, scenario="exploration_loss")
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["boundary_guard_module_strengthened"] is True
    assert summary["boundary_guard_audit_rows"] >= 2 * 16
    assert summary["boundary_violation_report_rows"] == 0
    assert summary["all_boundary_rules_passed"] is True
    assert summary["boundary_guard_status"] == "pass"
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_boundary_guard_audit_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_boundary_violation_report_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_boundary_guard_summary_RC1.csv").exists()
