from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner


def test_task7_exploration_generates_candidates_and_sandbox_rows():
    cfg = FullSpecRunnerConfig(steps=3, seed=707, scenario="exploration_loss", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    candidates = out["exploration_candidates"]
    sandbox = out["exploration_sandbox"]
    decision = out["exploration_decision"]
    assert not candidates.empty
    assert not sandbox.empty
    assert not decision.empty
    assert candidates["uses_ot_exploration_view"].astype(bool).all()
    assert candidates["uses_residual_noise_log"].astype(bool).all()
    assert candidates["uses_shadow_parameter_state"].astype(bool).all()
    assert set(candidates["candidate_status"]).issubset({"ready_for_sandbox", "monitor_only"})
    assert sandbox["sandbox_projection_contract"].str.contains("no_world_writeback", regex=False).all()


def test_task7_exploration_boundary_no_writeback_or_action():
    cfg = FullSpecRunnerConfig(steps=2, seed=708, scenario="normal", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    candidates = out["exploration_candidates"]
    sandbox = out["exploration_sandbox"]
    decision = out["exploration_decision"]
    for df in [candidates, sandbox, decision]:
        assert not df.empty
    assert not candidates[[
        "exploration_generates_pressure",
        "exploration_updates_parameter_box",
        "exploration_writes_world",
        "exploration_writes_gk",
        "exploration_writes_ot",
    ]].astype(bool).any().any()
    assert not sandbox[[
        "world_writeback_performed",
        "gk_writeback_performed",
        "ot_writeback_performed",
        "parameter_update_performed",
        "action_performed",
    ]].astype(bool).any().any()
    assert not decision[[
        "unverified_candidate_can_pass",
        "exploration_generates_pressure",
        "exploration_updates_parameter_box",
        "exploration_executes_action",
    ]].astype(bool).any().any()
    assert decision["all_passed_candidates_verified"].astype(bool).all()


def test_task7_boundary_guard_allows_verified_sandbox_passes():
    cfg = FullSpecRunnerConfig(steps=2, seed=709, scenario="relation_lock", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    guard = out["boundary_guard_audit"]
    assert not guard.empty
    bg10 = guard[guard["rule_id"].eq("BG10_unverified_exploration_cannot_pass")]
    assert not bg10.empty
    assert bg10["guard_status"].eq("pass").all()
    assert out["boundary_violation_report"].empty
    assert out["cycle_audit_row"]["exploration_candidate_rows"].sum() > 0
    assert not out["cycle_audit_row"]["exploration_unverified_candidate_can_pass"].astype(bool).any()


def test_task7_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=710, scenario="exploration_loss", exploration_enabled=True)
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["exploration_module_integrated"] is True
    assert summary["exploration_candidate_rows"] > 0
    assert summary["exploration_sandbox_rows"] > 0
    assert summary["exploration_decision_rows"] > 0
    assert summary["exploration_all_passed_verified"] is True
    assert summary["exploration_unverified_candidate_can_pass"] is False
    assert summary["boundary_violation_count"] == 0
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_exploration_candidates_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_exploration_sandbox_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_exploration_decision_RC1.csv").exists()
