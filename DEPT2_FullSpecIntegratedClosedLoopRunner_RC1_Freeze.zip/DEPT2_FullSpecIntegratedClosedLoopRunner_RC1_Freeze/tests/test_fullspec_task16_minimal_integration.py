from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner
from validation.task16_minimal_integration_matrix import run_task16_matrix


def test_task16_one_step_exploration_on_minimal_contract():
    cfg = FullSpecRunnerConfig(steps=1, seed=1601, scenario="normal", exploration_enabled=True)
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(Path("/tmp/task16_pytest_one_step_on"))
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["cycle_rows"] == 1
    assert summary["action_frame_rows"] > 0
    assert summary["exploration_candidate_rows"] > 0
    assert summary["exploration_projection_rows"] > 0
    assert summary["boundary_violation_count"] == 0
    assert summary["all_sanity_checks_passed"] is True


def test_task16_five_step_exploration_on_minimal_contract():
    cfg = FullSpecRunnerConfig(steps=5, seed=1602, scenario="normal", exploration_enabled=True)
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(Path("/tmp/task16_pytest_five_step_on"))
    assert summary["cycle_rows"] == 5
    assert summary["shadow_carryover_enabled"] is True
    assert summary["shadow_commit_status_all_not_committed"] is True
    assert summary["canonical_write_performed"] is False
    assert summary["gk_writeback_performed"] is False
    assert summary["all_noise_retained"] is True
    assert summary["actionmodule_received_actionframe_only"] is True
    assert summary["all_sanity_checks_passed"] is True


def test_task16_five_step_exploration_disabled_regression():
    cfg = FullSpecRunnerConfig(steps=5, seed=1603, scenario="normal", exploration_enabled=False)
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(Path("/tmp/task16_pytest_five_step_off"))
    assert summary["cycle_rows"] == 5
    assert summary["exploration_candidate_rows"] == 0
    assert summary["exploration_projection_rows"] == 0
    assert summary["exploration_sidecar_rows"] == 5
    assert summary["exploration_status"] == "skipped_disabled"
    assert summary["boundary_violation_count"] == 0
    assert summary["action_frame_rows"] > 0
    assert summary["all_sanity_checks_passed"] is True


def test_task16_matrix_runner_passes_all_cases(tmp_path):
    aggregate = run_task16_matrix(tmp_path)
    assert aggregate["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert aggregate["status"] == "pass"
    assert aggregate["case_count"] == 3
    assert aggregate["failed_case_count"] == 0
    assert (tmp_path / "fullspec_task16_minimal_integration_matrix_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_minimal_integration_summary_RC1.json").exists()
