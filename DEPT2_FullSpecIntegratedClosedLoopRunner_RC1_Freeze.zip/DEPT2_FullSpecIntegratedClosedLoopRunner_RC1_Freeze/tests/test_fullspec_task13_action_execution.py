from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner
from dept2_fullspec_runner_rc1.modules.action_execution_module import ActionExecutionModule
import pandas as pd


def test_task14_action_execution_audit_is_emitted_and_passes():
    cfg = FullSpecRunnerConfig(steps=3, seed=131, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    audit = out["cycle_audit_row"]
    execution = out["action_execution_audit"]
    assert len(audit) == 3
    assert len(execution) == 3
    assert int(audit["boundary_violation_count"].sum()) == 0
    assert audit["action_execution_status"].eq("pass").all()
    assert execution["audit_status"].eq("pass").all()
    assert execution["actionmodule_received_actionframe_only"].astype(bool).all()
    assert execution["actionmodule_called_by_adapter"].astype(bool).all()
    assert execution["world_step_performed_by_adapter"].astype(bool).all()


def test_task14_actionmodule_gets_no_direct_core_inputs():
    cfg = FullSpecRunnerConfig(steps=2, seed=132, scenario="shock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    execution = out["action_execution_audit"]
    forbidden = [
        "direct_gk_input_to_actionmodule",
        "direct_ot_input_to_actionmodule",
        "direct_v8_input_to_actionmodule",
        "direct_exploration_sidecar_input_to_actionmodule",
        "direct_parameter_box_input_to_actionmodule",
        "canonical_parameter_write_performed",
        "gk_writeback_performed",
        "ot_writeback_performed",
    ]
    for col in forbidden:
        assert col in execution.columns
        assert not execution[col].astype(bool).any()


def test_task14_action_frame_is_built_after_gate_and_has_contract():
    cfg = FullSpecRunnerConfig(steps=1, seed=133, scenario="relation_lock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    frame = out["action_frame"]
    execution = out["action_execution_audit"]
    assert not frame.empty
    assert frame["action_frame_contract"].astype(str).str.contains("ActionFrame_is_only_input", regex=False).all()
    assert frame["coactivation_gate_applied_before_actionframe"].astype(bool).all()
    assert not frame["actionmodule_called_by_builder"].astype(bool).any()
    assert execution["action_frame_contract_present"].astype(bool).all()


def test_task14_build_action_frame_requires_gate():
    module = ActionExecutionModule()
    candidates = pd.DataFrame({"entity_id": ["E000"], "action_strength": [0.1]})
    with pytest.raises(ValueError):
        module.build_action_frame(candidates, pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame())


def test_task14_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=134, scenario="exploration_loss")
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["action_execution_module_strengthened"] is True
    assert summary["action_execution_audit_rows"] == 2
    assert summary["action_execution_audit_passed"] is True
    assert summary["actionmodule_received_actionframe_only"] is True
    assert summary["actionmodule_direct_core_input_detected"] is False
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_action_execution_audit_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_action_frame_RC1.csv").exists()
