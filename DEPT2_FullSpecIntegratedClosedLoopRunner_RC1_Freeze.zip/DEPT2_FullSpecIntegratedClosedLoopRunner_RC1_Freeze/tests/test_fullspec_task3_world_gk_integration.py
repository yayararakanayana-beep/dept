from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd
import pytest

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner
from dept2_fullspec_runner_rc1.modules.world_adapter import WorldAdapter, trace_fingerprint
from dept2_fullspec_runner_rc1.modules.gk_builder import GKBuilderModule


def test_task3_runner_world_gk_two_steps():
    cfg = FullSpecRunnerConfig(steps=2, seed=7, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    audit = out["cycle_audit_row"]
    assert len(audit) == 2
    assert int(audit["boundary_violation_count"].sum()) == 0
    assert out["world_trace_audit"].shape[0] == 2
    assert out["world_transition_audit"].shape[0] == 2
    assert out["gk_build_audit"].shape[0] == 2
    assert out["formal_packet"].shape[0] >= 2
    assert out["action_frame"].shape[0] > 0


def test_world_trace_schema_and_transition_audit():
    cfg = FullSpecRunnerConfig(steps=1, seed=8, scenario="relation_lock")
    runner = FullSpecIntegratedClosedLoopRunner(cfg)
    out = runner.run()
    world_audit = out["world_trace_audit"]
    transition = out["world_transition_audit"]
    assert world_audit["schema_valid"].eq(True).all()
    assert world_audit["world_owned_state"].eq(True).all()
    assert not world_audit["dept_internal_columns_present"].any()
    assert not world_audit["gk_written_back_to_world"].any()
    assert not transition["gk_writeback_performed"].any()
    assert not transition["ot_writeback_performed"].any()
    assert not transition["canonical_parameter_write_performed"].any()
    assert (transition["world_t_after"] - transition["world_t_before"]).eq(1).all()


def test_gk_builder_read_only_trace_and_provenance():
    cfg = FullSpecRunnerConfig(steps=1, seed=9, scenario="shock")
    world = WorldAdapter(cfg)
    trace = world.snapshot()
    fp_before = trace_fingerprint(trace)
    out = GKBuilderModule(cfg).build(trace, loop_step=0)
    fp_after = trace_fingerprint(trace)
    assert fp_before == fp_after
    gk_audit = out["gk_build_audit"]
    assert gk_audit["build_status"].eq("pass").all()
    assert not gk_audit["source_trace_mutated_by_gk_builder"].any()
    assert not gk_audit["gk_writeback_performed"].any()
    assert out["gt"]["gk_source_contract"].str.contains("no_writeback").all()
    assert out["kt"]["gk_source_contract"].str.contains("no_writeback").all()
    assert out["formal_packet"]["formal_input_source_contract"].str.contains("GK", case=False, regex=False).all()


def test_formal_packet_no_lower_leak_task3():
    cfg = FullSpecRunnerConfig(steps=1, seed=10, scenario="exploration_loss")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    formal_cols = list(out["formal_packet"].columns)
    forbidden_prefixes = ("ot_", "v8_", "exploration_", "graph_object", "action_surface", "final_gate", "action_frame")
    leaked = [c for c in formal_cols if c.startswith(forbidden_prefixes)]
    assert leaked == []
    for col in ["formal_contains_ot", "formal_contains_v8", "formal_contains_exploration", "formal_contains_action_surface"]:
        assert col in out["formal_packet"].columns
        assert not out["formal_packet"][col].any()


def test_world_adapter_rejects_malformed_trace():
    bad = {
        "entity_trace": pd.DataFrame([{"entity_id": "E001", "t": 0, "seed": 1, "scenario": "normal"}]),
        "relation_trace": pd.DataFrame([{"source": "E001", "target": "E002", "t": 0, "seed": 1, "scenario": "normal"}]),
    }
    with pytest.raises(ValueError):
        WorldAdapter.validate_trace_schema(bad)


def test_shadow_only_parameter_updates_still_hold():
    cfg = FullSpecRunnerConfig(steps=1, seed=11, scenario="shock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    updates = out["parameter_updates"]
    assert not updates.empty
    assert set(updates["parameter_update_mode"]) == {"shadow_only"}
    assert not updates["canonical_write_performed"].any()
    assert not updates["world_write_performed"].any()
    assert not updates["gk_writeback_performed"].any()
