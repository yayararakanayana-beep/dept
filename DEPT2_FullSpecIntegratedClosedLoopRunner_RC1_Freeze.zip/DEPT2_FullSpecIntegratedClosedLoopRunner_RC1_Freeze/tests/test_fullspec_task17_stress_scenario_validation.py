from pathlib import Path
import sys
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from validation.task17_stress_scenario_validation import run_stress_matrix


@pytest.fixture(scope="module")
def task17_result(tmp_path_factory):
    out = tmp_path_factory.mktemp("task17_stress_matrix")
    result = run_stress_matrix(out)
    result["out"] = out
    return result


def test_task17_stress_matrix_runs_without_boundary_violation(task17_result):
    matrix = task17_result["matrix"]
    assert len(matrix) == 7
    assert (matrix["boundary_violation_count"] == 0).all()
    assert matrix["all_sanity_checks_passed"].all()
    assert not matrix["canonical_write_performed"].any()
    assert not matrix["world_write_performed"].any()
    assert not matrix["gk_writeback_performed"].any()


def test_task17_shock_case_retains_watch_without_failure(task17_result):
    matrix = task17_result["matrix"]
    shock = matrix[matrix["case_id"] == "S05_shock_recovery_window"].iloc[0]
    assert shock["stress_case_status"] in {"pass", "pass_with_watch"}
    assert shock["boundary_violation_count"] == 0
    assert shock["max_noise_score"] > 0.0


def test_task17_exploration_off_regression_has_zero_projection_but_passes(task17_result):
    matrix = task17_result["matrix"]
    off = matrix[matrix["case_id"] == "S06_exploration_off_high_noise_regression"].iloc[0]
    assert bool(off["exploration_enabled"]) is False
    assert int(off["exploration_candidate_rows"]) == 0
    assert int(off["exploration_projection_rows"]) == 0
    assert int(off["exploration_sidecar_rows"]) >= int(off["steps"])
    assert bool(off["all_sanity_checks_passed"])


def test_task17_outputs_are_written(task17_result):
    out = task17_result["out"]
    assert (out / "fullspec_task17_stress_scenario_matrix_RC1.csv").exists()
    assert (out / "fullspec_task17_stress_metric_timeseries_RC1.csv").exists()
    assert (out / "fullspec_task17_watchlist_RC1.csv").exists()
    assert (out / "fullspec_task17_stress_validation_summary_RC1.csv").exists()
    assert (out / "task17_stress_validation_summary_RC1.json").exists()
    watch = pd.read_csv(out / "fullspec_task17_watchlist_RC1.csv")
    assert len(watch) >= 1
