from pathlib import Path
import sys

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner
from dept2_fullspec_runner_rc1.modules.parameter_shadow_box import ParameterShadowBox


def test_task6_parameter_shadow_audit_is_emitted_and_passes():
    cfg = FullSpecRunnerConfig(steps=4, seed=61, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    audit = out["cycle_audit_row"]
    shadow = out["parameter_shadow_audit"]
    assert len(audit) == 4
    assert len(shadow) == 4
    assert int(audit["boundary_violation_count"].sum()) == 0
    assert audit["parameter_shadow_status"].eq("pass").all()
    assert audit["shadow_carryover_enabled"].astype(bool).all()
    assert audit["shadow_bounded_delta_pass"].astype(bool).all()
    assert audit["shadow_rollback_ready"].astype(bool).all()
    assert audit["shadow_commit_status"].eq("not_committed").all()
    assert shadow["audit_status"].eq("pass").all()
    assert shadow["shadow_carryover_enabled"].astype(bool).all()
    assert shadow["bounded_delta_pass"].astype(bool).all()


def test_task6_parameter_shadow_never_commits_or_writes_canonical_state():
    cfg = FullSpecRunnerConfig(steps=3, seed=62, scenario="relation_lock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    updates = out["parameter_updates"]
    shadow_audit = out["parameter_shadow_audit"]
    for df in [updates, shadow_audit]:
        for col in [
            "lower_parameter_update_committed",
            "canonical_write_performed",
            "canonical_theta_written",
            "world_write_performed",
            "world_state_written",
            "gk_writeback_performed",
            "canonical_gk_written",
            "commit_gate_passed",
        ]:
            assert col in df.columns
            assert not df[col].astype(bool).any(), col
    assert updates["parameter_update_mode"].eq("shadow_only").all()
    assert updates["commit_status"].eq("not_committed").all()
    assert updates["rollback_ready"].astype(bool).all()


def test_task6_shadow_carryover_is_continuous_between_cycles():
    cfg = FullSpecRunnerConfig(steps=5, seed=63, scenario="shock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    shadow = out["parameter_shadow_audit"].sort_values("loop_step")
    assert shadow["previous_shadow_fingerprint_matches_last_cycle"].astype(bool).all()
    # After the first cycle, the previous fingerprint must equal the prior cycle's new fingerprint.
    new_fps = list(shadow["new_shadow_fingerprint"])
    prev_fps = list(shadow["previous_shadow_fingerprint"])
    for i in range(1, len(shadow)):
        assert prev_fps[i] == new_fps[i - 1]
    assert shadow["new_shadow_fingerprint"].astype(str).str.len().gt(0).all()


def test_task6_parameter_shadow_rejects_lower_artifact_leakage():
    cfg = FullSpecRunnerConfig(steps=1, seed=64, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    formal = out["formal_packet"].copy()
    h11 = out["h11_local_pressure_field"].copy()
    formal["ot_illegal_direct_input"] = 0.5
    with pytest.raises(ValueError):
        ParameterShadowBox().update_shadow(formal, h11, loop_step=0)
    h11["exploration_illegal_hint"] = 0.1
    with pytest.raises(ValueError):
        ParameterShadowBox().update_shadow(out["formal_packet"], h11, loop_step=0)


def test_task6_parameter_shadow_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=65, scenario="exploration_loss")
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    # Task11 keeps Task6 parameter-shadow guarantees while the package-level task name advances.
    assert summary["parameter_shadow_box_strengthened"] is True
    assert summary["parameter_shadow_box_strengthened"] is True
    assert summary["parameter_shadow_audit_rows"] == 2
    assert summary["parameter_shadow_audit_passed"] is True
    assert summary["shadow_carryover_enabled"] is True
    assert summary["shadow_commit_status_all_not_committed"] is True
    assert summary["canonical_write_performed"] is False
    assert summary["world_write_performed"] is False
    assert summary["gk_writeback_performed"] is False
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_parameter_shadow_audit_RC1.csv").exists()
