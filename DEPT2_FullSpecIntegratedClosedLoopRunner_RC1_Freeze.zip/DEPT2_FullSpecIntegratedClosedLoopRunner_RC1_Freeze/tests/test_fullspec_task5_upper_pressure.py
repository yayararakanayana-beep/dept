from pathlib import Path
import sys

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner
from dept2_fullspec_runner_rc1.modules.upper_pressure_module import UpperPressureModule


def test_task5_upper_pressure_audit_is_emitted_and_passes():
    cfg = FullSpecRunnerConfig(steps=3, seed=31, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    audit = out["cycle_audit_row"]
    upper = out["upper_pressure_audit"]
    assert len(audit) == 3
    assert len(upper) == 3
    assert int(audit["boundary_violation_count"].sum()) == 0
    assert audit["upper_input_is_gk_only"].all()
    assert audit["upper_audit_status"].eq("pass").all()
    assert upper["formal_input_is_gk_only"].all()
    assert upper["audit_status"].eq("pass").all()
    assert upper["formal_lower_leak_count"].sum() == 0
    assert upper["m_lower_leak_count"].sum() == 0
    assert upper["pressure_lower_leak_count"].sum() == 0


def test_task5_m_and_pressure_contracts_exclude_lower_artifacts():
    cfg = FullSpecRunnerConfig(steps=1, seed=32, scenario="shock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    m = out["m_observation"]
    p = out["weak_pressure"]
    formal = out["formal_packet"]
    forbidden_prefixes = ("ot_", "v8_", "exploration_", "graph_object", "action_surface", "action_", "final_gate", "coactivation_")
    assert [c for c in formal.columns if c.startswith(forbidden_prefixes)] == []
    assert m["m_source_contract"].str.contains("formal_GK_only", regex=False).all()
    assert p["weak_pressure_contract"].str.contains("M_from_formal_GK_only", regex=False).all()
    for col in ["m_uses_ot", "m_uses_v8", "m_uses_exploration", "m_uses_action_surface", "m_uses_action_result", "m_writeback_performed"]:
        assert not m[col].astype(bool).any()
    for col in ["pressure_uses_ot", "pressure_uses_v8", "pressure_uses_exploration", "pressure_uses_action_surface", "pressure_uses_action_result", "pressure_writeback_performed"]:
        assert not p[col].astype(bool).any()


def test_task5_upper_pressure_rejects_ot_or_exploration_leakage():
    cfg = FullSpecRunnerConfig(steps=1, seed=33, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    leaked = out["formal_packet"].copy()
    leaked["ot_illegal_direct_input"] = 0.42
    with pytest.raises(ValueError):
        UpperPressureModule().compute(leaked, loop_step=0)
    leaked2 = out["formal_packet"].copy()
    leaked2["exploration_illegal_hint"] = 0.13
    with pytest.raises(ValueError):
        UpperPressureModule().compute(leaked2, loop_step=0)


def test_task5_upper_pressure_has_pressure_components_and_audit_provenance():
    cfg = FullSpecRunnerConfig(steps=2, seed=34, scenario="relation_lock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    upper = out["upper_pressure_audit"]
    p = out["weak_pressure"]
    approved_cols = [c for c in p.columns if c.startswith("approved_") and c != "approved_component_l1"]
    assert len(approved_cols) >= 10
    assert "formal_packet_fingerprint" in upper.columns
    assert upper["formal_packet_fingerprint"].astype(str).str.len().gt(0).all()
    assert upper["approved_pressure_component_count"].min() >= 10
    assert (upper["approved_pressure_l1_sum"] >= 0).all()
    assert not upper["truth_used_for_m_observation"].any()
    assert not upper["truth_used_for_pressure_candidate"].any()
