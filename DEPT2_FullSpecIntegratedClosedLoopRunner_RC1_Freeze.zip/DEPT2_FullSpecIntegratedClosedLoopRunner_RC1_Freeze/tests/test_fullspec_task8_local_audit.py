from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner


def test_task8_exploration_and_action_local_audits_exist_and_pass():
    cfg = FullSpecRunnerConfig(steps=3, seed=808, scenario="exploration_loss", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    exp = out["exploration_local_audit"]
    act = out["action_local_audit"]
    assert not exp.empty
    assert not act.empty
    assert exp["local_audit_role"].eq("exploration_v8_audit").all()
    assert act["local_audit_role"].eq("action_v8_check").all()
    assert exp["v8_support_status"].eq("pass").all()
    assert act["v8_support_status"].eq("pass").all()
    assert exp["local_audit_contract"].str.contains("not_GK_generator", regex=False).all()
    assert act["local_audit_contract"].str.contains("not_GK_generator", regex=False).all()


def test_task8_local_audit_boundary_no_writeback_or_core_role():
    cfg = FullSpecRunnerConfig(steps=2, seed=809, scenario="normal", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    for name in ["exploration_local_audit", "action_local_audit"]:
        df = out[name]
        assert not df.empty
        forbidden = [
            "v8_is_gk_generator",
            "v8_is_upper_formal_input",
            "v8_generates_pressure",
            "v8_updates_parameter_box",
            "v8_calls_actionmodule",
            "v8_writes_world",
            "v8_writes_gk",
            "v8_writes_ot",
            "v8_writes_canonical_parameter",
            "local_audit_writeback_performed",
        ]
        assert not df[[c for c in forbidden if c in df.columns]].astype(bool).any().any()


def test_task8_boundary_guard_has_local_audit_rule():
    cfg = FullSpecRunnerConfig(steps=2, seed=810, scenario="relation_lock", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    guard = out["boundary_guard_audit"]
    rule = guard[guard["rule_id"].eq("BG10b_local_audit_v8_boundary")]
    assert not rule.empty
    assert rule["guard_status"].eq("pass").all()
    assert out["boundary_violation_report"].empty


def test_task8_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=811, scenario="exploration_loss", exploration_enabled=True)
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["local_audit_module_integrated"] is True
    assert summary["exploration_local_audit_rows"] > 0
    assert summary["action_local_audit_rows"] > 0
    assert summary["exploration_v8_audit_passed"] is True
    assert summary["action_v8_check_passed"] is True
    assert summary["local_audit_no_writeback"] is True
    assert summary["boundary_violation_count"] == 0
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_exploration_local_audit_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_action_local_audit_RC1.csv").exists()
