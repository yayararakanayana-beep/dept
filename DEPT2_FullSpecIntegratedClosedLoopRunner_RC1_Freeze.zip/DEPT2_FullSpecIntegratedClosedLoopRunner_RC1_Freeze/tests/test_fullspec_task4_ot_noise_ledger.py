from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner


def test_task4_ot_views_and_noise_ledger_are_emitted():
    cfg = FullSpecRunnerConfig(steps=2, seed=21, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    audit = out["cycle_audit_row"]
    assert len(audit) == 2
    assert int(audit["boundary_violation_count"].sum()) == 0
    assert out["ot_native"].shape[0] > 0
    assert out["ot_action_view"].shape[0] == out["ot_native"].shape[0]
    assert out["ot_exploration_view"].shape[0] == out["ot_native"].shape[0]
    assert out["residual_noise_log"].shape[0] == out["ot_native"].shape[0]
    assert out["ot_observation_audit"].shape[0] == 2
    assert out["residual_noise_ledger_audit"].shape[0] == 2


def test_task4_ot_is_not_gk_generator_or_formal_input():
    cfg = FullSpecRunnerConfig(steps=1, seed=22, scenario="exploration_loss")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    ot = out["ot_native"]
    formal = out["formal_packet"]
    ot_audit = out["ot_observation_audit"]
    assert ot["ot_contract"].str.contains("not_GK_generator", regex=False).all()
    assert not ot["ot_gk_generation_performed"].any()
    assert not ot["ot_upper_formal_input_performed"].any()
    assert not ot["ot_action_module_direct_input"].any()
    assert not ot["ot_writeback_performed"].any()
    assert not ot_audit["ot_is_gk_generator"].any()
    assert not ot_audit["ot_used_as_upper_formal_input"].any()
    forbidden_prefixes = ("ot_", "v8_", "exploration_", "graph_object", "action_surface", "final_gate", "action_frame")
    assert [c for c in formal.columns if c.startswith(forbidden_prefixes)] == []


def test_task4_residual_noise_retains_low_and_unclassified_noise():
    cfg = FullSpecRunnerConfig(steps=3, seed=23, scenario="shock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    log = out["residual_noise_log"]
    ledger = out["residual_noise_ledger_audit"]
    assert not log.empty
    assert log["noise_retained"].all()
    assert not log["written_back_to_gk"].any()
    assert not log["written_back_to_world"].any()
    assert not log["used_as_upper_formal_input"].any()
    assert set(log["noise_status"]).issubset({
        "persistent_unresolved_noise",
        "active_unresolved_noise",
        "retained_monitored_noise",
        "retained_low_noise",
    })
    assert ledger["all_noise_retained"].all()
    assert not ledger["unclassified_noise_discarded"].any()
    assert ledger["ledger_available_for_exploration"].all()


def test_task4_ot_action_view_flows_to_planning_but_not_actionmodule_directly():
    cfg = FullSpecRunnerConfig(steps=1, seed=24, scenario="relation_lock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    affordance = out["action_affordance"]
    candidates = out["action_candidates"]
    frame = out["action_frame"]
    assert "ot_action_view_used" in affordance.columns
    assert affordance["ot_action_view_used"].all()
    assert "ot_action_view_used" in candidates.columns
    assert candidates["ot_action_view_used"].all()
    assert "ot_direct_actionmodule_input" in candidates.columns
    assert not candidates["ot_direct_actionmodule_input"].any()
    if not frame.empty:
        assert not frame["reads_ot_directly"].any()
