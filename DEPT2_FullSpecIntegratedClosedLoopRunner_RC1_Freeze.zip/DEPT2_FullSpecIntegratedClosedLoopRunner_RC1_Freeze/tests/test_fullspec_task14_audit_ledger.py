from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner


EXPECTED_MODULES = {
    "world_adapter",
    "gk_builder",
    "ot_observation_module",
    "upper_pressure_module",
    "parameter_shadow_box",
    "exploration_module",
    "local_audit_module",
    "pressure_translation_module",
    "action_surface_planning_module",
    "exploration_bridge_module",
    "coactivation_gate_module",
    "action_execution_module",
    "audit_ledger_module",
}


def test_task14_unified_audit_ledger_indexes_all_modules_per_cycle():
    cfg = FullSpecRunnerConfig(steps=3, seed=141, scenario="normal")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    ledger = out["unified_audit_ledger"]
    assert len(ledger) == cfg.steps * len(EXPECTED_MODULES)
    assert set(ledger["module_name"]) == EXPECTED_MODULES
    assert ledger["boundary_ok"].astype(bool).all()
    assert ledger["module_audit_passed"].astype(bool).all()
    assert ledger["task14_ledger_contract"].astype(str).str.contains("per_cycle_per_module", regex=False).all()


def test_task14_artifact_trace_index_covers_key_outputs():
    cfg = FullSpecRunnerConfig(steps=2, seed=142, scenario="shock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    index = out["artifact_trace_index"]
    names = set(index["artifact_name"])
    for required in [
        "cycle_audit_row",
        "world_trace_audit",
        "gk_build_audit",
        "ot_observation_audit",
        "residual_noise_log",
        "upper_pressure_audit",
        "pressure_translation_audit",
        "parameter_shadow_audit",
        "action_surface_planning_audit",
        "action_execution_audit",
        "unified_audit_ledger",
    ]:
        assert required in names
    assert (index["rows"] >= 0).all()
    assert index["task14_trace_contract"].astype(str).str.contains("causal_review", regex=False).all()


def test_task14_module_dependency_audit_preserves_direction_and_boundaries():
    cfg = FullSpecRunnerConfig(steps=2, seed=143, scenario="relation_lock")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    dep = out["module_dependency_audit"]
    assert not dep.empty
    assert dep["dependency_direction_ok"].astype(bool).all()
    assert not dep["reverse_core_dependency_detected"].astype(bool).any()
    assert not dep["direct_actionmodule_core_access_detected"].astype(bool).any()
    assert not dep["canonical_write_detected"].astype(bool).any()
    assert dep["task14_dependency_contract"].astype(str).str.contains("ordered_module_dependency_audit", regex=False).all()


def test_task14_audit_ledger_summary_passes_and_does_not_mutate_runtime_state():
    cfg = FullSpecRunnerConfig(steps=3, seed=144, scenario="exploration_loss")
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    summary = out["audit_ledger_summary"]
    assert len(summary) == 1
    row = summary.iloc[0]
    assert bool(row["all_modules_indexed_per_cycle"])
    assert bool(row["all_artifacts_indexed"])
    assert bool(row["dependency_audit_passed"])
    assert not bool(row["audit_ledger_writeback_performed"])
    assert not bool(row["audit_ledger_mutates_runtime_state"])
    assert row["audit_ledger_status"] == "pass"


def test_task14_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=145, scenario="normal")
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["audit_ledger_module_strengthened"] is True
    assert summary["unified_audit_ledger_rows"] == 2 * len(EXPECTED_MODULES)
    assert summary["all_modules_indexed_per_cycle"] is True
    assert summary["all_artifacts_indexed"] is True
    assert summary["dependency_audit_passed"] is True
    assert summary["audit_ledger_status"] == "pass"
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_unified_audit_ledger_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_artifact_trace_index_RC1.csv").exists()
    assert (tmp_path / "fullspec_task16_module_dependency_audit_RC1.csv").exists()
