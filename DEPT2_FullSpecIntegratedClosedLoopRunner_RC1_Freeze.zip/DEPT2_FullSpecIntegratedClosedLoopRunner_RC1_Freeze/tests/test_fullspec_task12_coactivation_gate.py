from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner
from dept2_fullspec_runner_rc1.modules.boundary_guard import BoundaryGuard


def test_task12_coactivation_gate_emits_auditable_decision():
    cfg = FullSpecRunnerConfig(steps=3, seed=1212, scenario="normal", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    gate = out["coactivation_gate"]
    assert not gate.empty
    assert gate["coactivation_gate_decision"].isin({"allow", "dampen", "defer", "block", "monitor_only"}).all()
    assert gate["coactivation_gate_audit_status"].eq("pass").all()
    assert gate["gate_required_before_actionframe"].astype(bool).all()
    assert gate["gate_applies_to_action_frame"].astype(bool).all()
    assert gate["coactivation_risk_score"].between(0.0, 1.0).all()
    assert gate["gate_dampening_factor"].between(0.0, 1.0).all()


def test_task12_coactivation_gate_no_writeback_or_actionmodule_call():
    cfg = FullSpecRunnerConfig(steps=2, seed=1213, scenario="relation_lock", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    gate = out["coactivation_gate"]
    forbidden = [
        "action_frame_created_by_gate",
        "actionmodule_called_by_gate",
        "parameter_box_updated_by_gate",
        "world_write_performed_by_gate",
        "gk_writeback_performed_by_gate",
        "ot_writeback_performed_by_gate",
        "canonical_parameter_write_by_gate",
        "sidecar_direct_actionmodule_input_by_gate",
    ]
    assert not gate[forbidden].astype(bool).any().any()
    assert out["boundary_violation_report"].empty


def test_task12_boundary_guard_rule_covers_gate():
    cfg = FullSpecRunnerConfig(steps=2, seed=1214, scenario="shock", exploration_enabled=True)
    out = FullSpecIntegratedClosedLoopRunner(cfg).run()
    guard = out["boundary_guard_audit"]
    rule = guard[guard["rule_id"].eq("BG13_coactivation_gate_before_actionframe")]
    assert not rule.empty
    assert rule["guard_status"].eq("pass").all()
    assert rule["observed"].str.contains("risk=", regex=False).all()


def test_task12_boundary_guard_detects_gate_writeback_violation():
    guard = BoundaryGuard()
    fake_gate = pd.DataFrame([{
        "coactivation_gate_decision": "allow",
        "gate_reason": "unit",
        "coactivation_risk_score": 0.1,
        "pressure_component_score": 0.1,
        "exploration_component_score": 0.1,
        "action_component_score": 0.1,
        "local_risk_component_score": 0.1,
        "noise_component_score": 0.1,
        "shadow_component_score": 0.1,
        "gate_required_before_actionframe": True,
        "gate_applies_to_action_frame": True,
        "gate_dampening_factor": 1.0,
        "coactivation_gate_audit_status": "pass",
        "action_frame_created_by_gate": False,
        "actionmodule_called_by_gate": False,
        "parameter_box_updated_by_gate": False,
        "world_write_performed_by_gate": True,
        "gk_writeback_performed_by_gate": False,
        "ot_writeback_performed_by_gate": False,
        "canonical_parameter_write_by_gate": False,
        "sidecar_direct_actionmodule_input_by_gate": False,
        "coactivation_gate_contract": "Task12_same_step_coactivation_gate__pre_ActionFrame__allow_dampen_defer_block_monitor_only__no_writeback__RC1",
    }])
    violations = guard.validate_coactivation_gate(fake_gate)
    assert any("world_write_performed_by_gate" in v for v in violations)


def test_task12_summary_written(tmp_path):
    cfg = FullSpecRunnerConfig(steps=2, seed=1215, scenario="exploration_loss", exploration_enabled=True)
    summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(tmp_path)
    assert summary["task"] == "Task16_MinimalIntegrationTest_RC1"
    assert summary["coactivation_gate_module_strengthened"] is True
    assert summary["coactivation_gate_rows"] == 2
    assert summary["coactivation_gate_audit_passed"] is True
    assert summary["coactivation_gate_required_before_actionframe"] is True
    assert summary["coactivation_gate_no_writeback"] is True
    assert summary["coactivation_gate_actionframe_created_by_gate"] is False
    assert summary["coactivation_gate_actionmodule_called_by_gate"] is False
    assert summary["boundary_violation_count"] == 0
    assert summary["all_sanity_checks_passed"] is True
    assert (tmp_path / "fullspec_task16_coactivation_gate_RC1.csv").exists()
