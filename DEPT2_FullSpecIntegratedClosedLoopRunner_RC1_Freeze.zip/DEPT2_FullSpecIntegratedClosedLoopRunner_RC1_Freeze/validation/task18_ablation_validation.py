"""Task18 ablation validation for FullSpec Integrated Closed Loop Runner RC1.

Task18 compares the integrated Task17 runner against controlled ablations.
The goal is diagnostic attribution, not performance superiority:
  - which modules contribute to exploration projection, noise visibility,
    coactivation dampening, action-frame strength, and boundary retention;
  - which removals are safe-but-weaker versus boundary-risky;
  - what should be watched before RC1 freeze.

All ablations keep hard boundary contracts intact unless the ablation is
explicitly marked as a boundary-risk diagnostic.  RC1 does not claim deployment
safety, real-world readiness, or solved combined interference.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple
import json
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner.fullspec_integrated_closed_loop_runner import FullSpecIntegratedClosedLoopRunner
from dept2_fullspec_runner_rc1.modules.ot_observation_module import OtObservationModule
from dept2_fullspec_runner_rc1.modules.local_audit_module import LocalAuditModule
from dept2_fullspec_runner_rc1.modules.exploration_bridge_module import ExplorationBridgeModule
from dept2_fullspec_runner_rc1.modules.coactivation_gate_module import CoactivationGateModule
from dept2_fullspec_runner_rc1.modules.parameter_shadow_box import ParameterShadowBox


def _num(df: pd.DataFrame | None, col: str, default: float = 0.0) -> pd.Series:
    if df is None or df.empty or col not in df.columns:
        return pd.Series([], dtype=float)
    return pd.to_numeric(df[col], errors="coerce").fillna(default).astype(float)


def _max(df: pd.DataFrame | None, col: str, default: float = 0.0) -> float:
    s = _num(df, col, default)
    return float(s.max()) if len(s) else float(default)


def _mean(df: pd.DataFrame | None, col: str, default: float = 0.0) -> float:
    s = _num(df, col, default)
    return float(s.mean()) if len(s) else float(default)


def _sum(df: pd.DataFrame | None, col: str, default: float = 0.0) -> float:
    s = _num(df, col, default)
    return float(s.sum()) if len(s) else float(default)


def _count_values(df: pd.DataFrame | None, col: str) -> dict:
    if df is None or df.empty or col not in df.columns:
        return {}
    return {str(k): int(v) for k, v in df[col].astype(str).value_counts().sort_index().items()}


def _last(df: pd.DataFrame | None, col: str, default=None):
    if df is None or df.empty or col not in df.columns:
        return default
    return df[col].iloc[-1]


class NoiseLedgerAblatedOtModule(OtObservationModule):
    """Keep O_t views, but remove residual/noise ledger signal strength.

    Rows are retained so the no-discard contract remains visible.  Scores are
    zeroed and statuses are marked ablated, which lets Task18 ask whether the
    retained noise ledger contributes to exploration/gate behaviour without
    creating a boundary violation.
    """

    def build(self, trace, gt, kt) -> dict[str, pd.DataFrame]:  # type: ignore[override]
        out = super().build(trace, gt, kt)
        noise = out.get("residual_noise_log", pd.DataFrame()).copy()
        if not noise.empty:
            for col in ["ot_noise_score", "noise_delta", "residual_delta", "ot_residual_score", "ot_unresolved_score", "ot_ambiguity_score"]:
                if col in noise.columns:
                    noise[col] = 0.0
            noise["noise_status"] = "ablated_retained_zero_signal"
            noise["noise_kind"] = "ablation_zeroed_noise_signal"
            noise["noise_retained"] = True
            noise["noise_retention_contract"] = "Task18_noise_signal_ablation__rows_retained_zero_signal__RC1"
            noise["task18_ablation_applied"] = "no_residual_noise_ledger_signal"
        out["residual_noise_log"] = noise
        ledger = out.get("residual_noise_ledger_audit", pd.DataFrame()).copy()
        if not ledger.empty:
            for col in ["active_noise_rows", "persistent_noise_rows", "unresolved_noise_rows"]:
                if col in ledger.columns:
                    ledger[col] = 0
            for col in ["max_noise_score", "mean_noise_score", "max_residual_delta", "max_noise_delta"]:
                if col in ledger.columns:
                    ledger[col] = 0.0
            ledger["task18_ablation_applied"] = "no_residual_noise_ledger_signal"
            ledger["all_noise_retained"] = True
            ledger["unclassified_noise_discarded"] = False
        out["residual_noise_ledger_audit"] = ledger
        audit = out.get("ot_observation_audit", pd.DataFrame()).copy()
        if not audit.empty:
            audit["task18_ablation_applied"] = "no_residual_noise_ledger_signal"
            audit["all_noise_retained"] = True
        out["ot_observation_audit"] = audit
        return out


class LocalAuditAblatedModule(LocalAuditModule):
    """Return contract-valid but non-informative local audits.

    This preserves the local-audit boundary while removing v8's positive local
    confirmation signal.  Exploration projection should drop because bridge
    requires local_audit_passed=True for projection eligibility.
    """

    def _rows_for(self, source: pd.DataFrame | None, role: str) -> pd.DataFrame:
        if source is None or source.empty:
            rows = [{"local_audit_role": role, "zero_source_audit_row": True}]
        else:
            rows = []
            key = "candidate_axis_id" if "candidate_axis_id" in source.columns else None
            for i, (_, r) in enumerate(source.iterrows()):
                row = {
                    "local_audit_role": role,
                    "zero_source_audit_row": False,
                    "entity_id": str(r.get("entity_id", "")),
                    "graph_object_id": str(r.get("graph_object_id", f"GO_ABL_{i}")),
                    "ot_id": str(r.get("ot_id", "")),
                    "axis_type": str(r.get("axis_type", "ablated_local_audit")),
                    "action_channel": str(r.get("action_channel", "ablated_local_audit")),
                    "target_need": float(pd.to_numeric(pd.Series([r.get("target_need", r.get("pre_sandbox_score", 0.0))]), errors="coerce").fillna(0.0).iloc[0]),
                }
                if key:
                    row["candidate_axis_id"] = str(r.get("candidate_axis_id", ""))
                    row["exploration_candidate_id"] = str(r.get("candidate_axis_id", ""))
                rows.append(row)
        out = pd.DataFrame(rows)
        out["local_audit_stage"] = "task18_v8_local_audit_ablation"
        out["local_audit_contract"] = "Task8_v8_local_audit_only__not_GK_generator__not_upper_formal_input__no_writeback__RC1"
        out["v8_support_status"] = "pass"
        out["source_rows_audited"] = 0 if source is None else int(len(source))
        out["source_fingerprint"] = "task18_local_audit_signal_ablation"
        out["v8_requested"] = False
        out["v8_confidence"] = 0.0
        out["v8_conflict"] = 0.0
        out["v8_unresolved"] = 0.0
        out["v8_is_gk_generator"] = False
        out["v8_is_upper_formal_input"] = False
        out["v8_generates_pressure"] = False
        out["v8_updates_parameter_box"] = False
        out["v8_calls_actionmodule"] = False
        out["v8_writes_world"] = False
        out["v8_writes_gk"] = False
        out["v8_writes_ot"] = False
        out["v8_writes_canonical_parameter"] = False
        out["local_audit_writeback_performed"] = False
        out["local_audit_passed"] = False
        out["task18_ablation_applied"] = "no_local_audit_signal"
        if role == "exploration_v8_audit":
            out["exploration_candidate_local_audit"] = True
            out["exploration_projection_created_by_local_audit"] = False
            out["exploration_action_created_by_local_audit"] = False
            out["sidecar_compression_by_local_audit"] = False
        else:
            out["action_candidate_local_audit"] = True
            out["action_frame_created_by_local_audit"] = False
            out["actionmodule_direct_input_from_local_audit"] = False
        return out

    def audit_exploration(self, exploration_candidates, ot_exploration_view, params):  # type: ignore[override]
        return self._rows_for(exploration_candidates, "exploration_v8_audit")

    def audit_action(self, candidates, graph_objects, params):  # type: ignore[override]
        return self._rows_for(candidates, "action_v8_check")


class BridgeProjectionAblatedModule(ExplorationBridgeModule):
    """Keep non-compressed sidecar, but disable action-readable projection."""

    def project(self, exploration_decision, exploration_sandbox, exploration_local_audit):  # type: ignore[override]
        base = super().project(exploration_decision, exploration_sandbox, exploration_local_audit)
        sidecar = base.get("exploration_sidecar", pd.DataFrame()).copy()
        if not sidecar.empty:
            sidecar["eligible_for_action_projection"] = False
            sidecar["bridge_status"] = "task18_projection_ablation_sidecar_retained"
            sidecar["task18_ablation_applied"] = "no_exploration_bridge_projection"
            sidecar["full_context_present"] = True
            sidecar["sidecar_is_noncompressed"] = True
            sidecar["sidecar_direct_actionmodule_input"] = False
        return {"exploration_projection": self._empty_projection(), "exploration_sidecar": sidecar}


class GateModulationAblatedModule(CoactivationGateModule):
    """Compute real coactivation signals, then force allow/no dampening.

    This keeps the pre-ActionFrame gate call and audit contract, but removes the
    RC1 modulation effect.  The diagnostic compares action-frame strength and
    risk visibility against the full gate.
    """

    def evaluate(self, *args, **kwargs):  # type: ignore[override]
        out = super().evaluate(*args, **kwargs).copy()
        out["original_coactivation_gate_decision"] = out["coactivation_gate_decision"]
        out["original_gate_dampening_factor"] = out["gate_dampening_factor"]
        out["coactivation_gate_decision"] = "allow"
        out["gate_reason"] = "task18_gate_modulation_ablation__forced_allow_for_diagnostic"
        out["gate_dampening_factor"] = 1.0
        out["gate_prevents_actionframe_when_block_or_defer"] = False
        out["allow_like_decision"] = True
        out["dampen_like_decision"] = False
        out["defer_like_decision"] = False
        out["block_like_decision"] = False
        out["monitor_only_decision"] = False
        out["task18_ablation_applied"] = "no_coactivation_gate_modulation"
        return out


class FrozenParameterShadowBox(ParameterShadowBox):
    """Emit shadow-only audit but freeze all parameter deltas at zero."""

    def __init__(self):
        super().__init__()
        self._frozen_params = dict(self.box.current_params())
        self._frozen_fp = "task18frozen0000"

    def current_params(self) -> dict:  # type: ignore[override]
        return dict(self._frozen_params)

    def update_shadow(self, formal_packet, h11_local_pressure_field, *, loop_step=None):  # type: ignore[override]
        out = super().update_shadow(formal_packet, h11_local_pressure_field, loop_step=loop_step)
        # Restore emitted values to frozen, zero-delta shadow while preserving the
        # required shadow-only no-commit contract.
        current = out["shadow_parameter_state"].copy()
        if not current.empty:
            for name, value in self._frozen_params.items():
                mask = current["parameter_name"].astype(str).eq(str(name))
                current.loc[mask, "shadow_theta"] = float(value)
                current.loc[mask, "shadow_theta_previous"] = float(value)
                current.loc[mask, "shadow_theta_delta_from_previous"] = 0.0
            current["shadow_fingerprint"] = self._frozen_fp
            current["previous_shadow_fingerprint"] = self._frozen_fp
        updates = out["parameter_updates"].copy()
        if not updates.empty:
            for col in ["theta_before", "theta_after"]:
                if col in updates.columns and "parameter_name" in updates.columns:
                    updates[col] = updates["parameter_name"].map(lambda n: float(self._frozen_params.get(str(n), 0.0)))
            if "theta_delta" in updates.columns:
                updates["theta_delta"] = 0.0
            updates["shadow_previous_fingerprint"] = self._frozen_fp
            updates["shadow_next_fingerprint"] = self._frozen_fp
            updates["task18_ablation_applied"] = "no_parameter_shadow_delta"
        audit = out["parameter_shadow_audit"].copy()
        if not audit.empty:
            audit["previous_shadow_fingerprint"] = self._frozen_fp
            audit["new_shadow_fingerprint"] = self._frozen_fp
            audit["previous_shadow_fingerprint_matches_last_cycle"] = True
            audit["updated_parameter_rows"] = 0
            audit["max_abs_theta_delta"] = 0.0
            audit["total_abs_theta_delta"] = 0.0
            audit["bounded_delta_pass"] = True
            audit["rollback_ready"] = True
            audit["commit_status"] = "not_committed"
            audit["audit_status"] = "pass"
            audit["task18_ablation_applied"] = "no_parameter_shadow_delta"
        return {
            "parameter_registry": out["parameter_registry"],
            "parameter_updates": updates,
            "shadow_parameter_state": current,
            "parameter_shadow_audit": audit,
        }


ABLATION_CASES: List[dict] = [
    {
        "ablation_id": "A00_full_integrated_baseline",
        "removed_module": "none",
        "ablation_family": "baseline",
        "interpretation_jp": "全モジュール有効。Task18の比較基準。",
        "cfg": dict(steps=8, seed=1800, scenario="relation_lock", n_entities=20, noise_scale=0.040, drift_scale=0.014, action_coupling=0.070, exploration_enabled=True),
        "patches": [],
    },
    {
        "ablation_id": "A01_no_exploration_module",
        "removed_module": "exploration_module",
        "ablation_family": "exploration_off",
        "interpretation_jp": "探索候補生成を無効化。基本閉ループだけで動くか、探索projection消失の影響を見る。",
        "cfg": dict(steps=8, seed=1801, scenario="relation_lock", n_entities=20, noise_scale=0.040, drift_scale=0.014, action_coupling=0.070, exploration_enabled=False),
        "patches": [],
    },
    {
        "ablation_id": "A02_no_residual_noise_ledger_signal",
        "removed_module": "residual_noise_ledger_signal",
        "ablation_family": "noise_ledger_ablation",
        "interpretation_jp": "ノイズ行は保持するが信号強度をゼロ化。未分類ノイズ台帳の寄与を見る。",
        "cfg": dict(steps=8, seed=1802, scenario="shock", n_entities=20, noise_scale=0.050, drift_scale=0.014, action_coupling=0.070, exploration_enabled=True),
        "patches": ["noise_ledger_zero_signal"],
    },
    {
        "ablation_id": "A03_no_local_audit_signal",
        "removed_module": "local_audit_module_signal",
        "ablation_family": "local_audit_ablation",
        "interpretation_jp": "v8局所監査の確認信号を無効化。探索projectionと同時発火riskへの寄与を見る。",
        "cfg": dict(steps=8, seed=1803, scenario="relation_lock", n_entities=20, noise_scale=0.040, drift_scale=0.014, action_coupling=0.070, exploration_enabled=True),
        "patches": ["local_audit_zero_signal"],
    },
    {
        "ablation_id": "A04_no_exploration_bridge_projection",
        "removed_module": "exploration_bridge_projection",
        "ablation_family": "bridge_projection_ablation",
        "interpretation_jp": "sidecarは残すが作用側projectionを無効化。探索情報の作用側寄与を見る。",
        "cfg": dict(steps=8, seed=1804, scenario="relation_lock", n_entities=20, noise_scale=0.040, drift_scale=0.014, action_coupling=0.070, exploration_enabled=True),
        "patches": ["bridge_no_projection"],
    },
    {
        "ablation_id": "A05_no_coactivation_gate_modulation",
        "removed_module": "coactivation_gate_modulation",
        "ablation_family": "gate_modulation_ablation",
        "interpretation_jp": "gate自体は呼ぶが常にallowへ固定。dampen/defer/blockによる抑制寄与を見る。",
        "cfg": dict(steps=8, seed=1805, scenario="relation_lock", n_entities=24, noise_scale=0.045, drift_scale=0.016, action_coupling=0.090, exploration_enabled=True),
        "patches": ["gate_force_allow"],
    },
    {
        "ablation_id": "A06_no_parameter_shadow_delta",
        "removed_module": "parameter_shadow_delta",
        "ablation_family": "shadow_delta_ablation",
        "interpretation_jp": "shadow carryoverの枠は残し、deltaだけゼロ化。仮パラメーター更新の寄与を見る。",
        "cfg": dict(steps=8, seed=1806, scenario="relation_lock", n_entities=20, noise_scale=0.040, drift_scale=0.014, action_coupling=0.070, exploration_enabled=True),
        "patches": ["shadow_delta_zero"],
    },
]


def build_runner(case: dict) -> FullSpecIntegratedClosedLoopRunner:
    cfg_dict = dict(case["cfg"])
    cfg_dict["output_prefix"] = f"fullspec_task18_{case['ablation_id']}"
    runner = FullSpecIntegratedClosedLoopRunner(FullSpecRunnerConfig(**cfg_dict))
    patches = set(case.get("patches", []))
    if "noise_ledger_zero_signal" in patches:
        runner.ot_observation_module = NoiseLedgerAblatedOtModule()
    if "local_audit_zero_signal" in patches:
        runner.local_audit_module = LocalAuditAblatedModule()
    if "bridge_no_projection" in patches:
        runner.exploration_bridge_module = BridgeProjectionAblatedModule()
    if "gate_force_allow" in patches:
        runner.coactivation_gate_module = GateModulationAblatedModule()
    if "shadow_delta_zero" in patches:
        runner.parameter_shadow_box = FrozenParameterShadowBox()
    return runner


def summarize_outputs(case: dict, outputs: Dict[str, pd.DataFrame]) -> dict:
    cycle = outputs.get("cycle_audit_row", pd.DataFrame())
    gate = outputs.get("coactivation_gate", pd.DataFrame())
    decision = outputs.get("exploration_decision", pd.DataFrame())
    projection = outputs.get("exploration_projection", pd.DataFrame())
    sidecar = outputs.get("exploration_sidecar", pd.DataFrame())
    boundary = outputs.get("boundary_violation_report", pd.DataFrame())
    action_frame = outputs.get("action_frame", pd.DataFrame())
    action_candidates = outputs.get("action_candidates", pd.DataFrame())
    shadow_audit = outputs.get("parameter_shadow_audit", pd.DataFrame())
    action_local_audit = outputs.get("action_local_audit", pd.DataFrame())
    exploration_local_audit = outputs.get("exploration_local_audit", pd.DataFrame())

    boundary_count = int(cycle["boundary_violation_count"].sum()) if not cycle.empty and "boundary_violation_count" in cycle.columns else int(len(boundary))
    gate_counts = _count_values(cycle, "gate_decision") or _count_values(gate, "coactivation_gate_decision")
    baseline_safe = bool(boundary_count == 0 and not cycle.empty and len(cycle) == int(case["cfg"]["steps"]))

    row = {
        "ablation_id": case["ablation_id"],
        "removed_module": case["removed_module"],
        "ablation_family": case["ablation_family"],
        "interpretation_jp": case["interpretation_jp"],
        "scenario": str(case["cfg"]["scenario"]),
        "seed": int(case["cfg"]["seed"]),
        "steps": int(case["cfg"]["steps"]),
        "exploration_enabled": bool(case["cfg"].get("exploration_enabled", True)),
        "cycle_rows": int(len(cycle)),
        "boundary_violation_count": boundary_count,
        "boundary_violation_report_rows": int(len(boundary)),
        "action_candidate_rows": int(len(action_candidates)),
        "action_frame_rows": int(len(action_frame)),
        "mean_action_frame_strength": _mean(action_frame, "action_strength", 0.0),
        "max_action_frame_strength": _max(action_frame, "action_strength", 0.0),
        "exploration_candidate_rows": int(len(outputs.get("exploration_candidates", pd.DataFrame()))),
        "exploration_projection_rows": int(len(projection)),
        "exploration_sidecar_rows": int(len(sidecar)),
        "exploration_passed_count_max": int(_max(decision, "passed_count", 0)),
        "exploration_unverified_candidate_can_pass": bool(decision.get("unverified_candidate_can_pass", pd.Series([False])).astype(bool).any()) if not decision.empty and "unverified_candidate_can_pass" in decision.columns else False,
        "exploration_local_audit_rows": int(len(exploration_local_audit)),
        "action_local_audit_rows": int(len(action_local_audit)),
        "action_local_audit_passed_rows": int(action_local_audit.get("local_audit_passed", pd.Series([], dtype=bool)).astype(bool).sum()) if not action_local_audit.empty and "local_audit_passed" in action_local_audit.columns else 0,
        "max_noise_score": _max(cycle, "max_noise_score", 0.0),
        "max_active_noise_rows": int(_max(cycle, "active_noise_rows", 0)),
        "max_local_observation_need": _max(cycle, "max_local_observation_need", 0.0),
        "max_coactivation_risk_score": max(_max(cycle, "coactivation_risk_score", 0.0), _max(gate, "coactivation_risk_score", 0.0)),
        "mean_coactivation_risk_score": _mean(cycle, "coactivation_risk_score", 0.0),
        "gate_decision_counts_json": json.dumps(gate_counts, ensure_ascii=False, sort_keys=True),
        "gate_allow_count": int(gate_counts.get("allow", 0)),
        "gate_dampen_count": int(gate_counts.get("dampen", 0)),
        "gate_defer_count": int(gate_counts.get("defer", 0)),
        "gate_block_count": int(gate_counts.get("block", 0)),
        "max_shadow_total_abs_delta": _max(cycle, "shadow_total_abs_delta", _max(shadow_audit, "total_abs_theta_delta", 0.0)),
        "canonical_write_performed": bool(shadow_audit.get("canonical_write_performed", pd.Series([False])).astype(bool).any()) if not shadow_audit.empty and "canonical_write_performed" in shadow_audit.columns else False,
        "world_write_performed": bool(shadow_audit.get("world_write_performed", pd.Series([False])).astype(bool).any()) if not shadow_audit.empty and "world_write_performed" in shadow_audit.columns else False,
        "gk_writeback_performed": bool(shadow_audit.get("gk_writeback_performed", pd.Series([False])).astype(bool).any()) if not shadow_audit.empty and "gk_writeback_performed" in shadow_audit.columns else False,
        "final_world_uncertainty": float(_last(cycle, "world_mean_uncertainty", 0.0) or 0.0),
        "final_world_exploration": float(_last(cycle, "world_mean_exploration", 0.0) or 0.0),
        "final_world_relation_lock": float(_last(cycle, "world_mean_relation_lock", 0.0) or 0.0),
        "all_sanity_checks_passed": baseline_safe,
        "claim_scope": "Task18_ablation_diagnostic_only__synthetic_pseudo_reality__no_deployment_or_safety_claim__RC1",
    }
    watch = []
    if row["boundary_violation_count"] > 0:
        watch.append("boundary_violation")
    if row["exploration_unverified_candidate_can_pass"]:
        watch.append("unverified_exploration_leak")
    if row["exploration_enabled"] and row["exploration_projection_rows"] == 0:
        watch.append("exploration_projection_removed_or_absent")
    if row["max_coactivation_risk_score"] >= 0.36 and row["gate_dampen_count"] == 0 and row["gate_defer_count"] == 0 and row["gate_block_count"] == 0:
        watch.append("gate_modulation_absent_under_risk")
    if row["max_noise_score"] == 0 and row["removed_module"] == "residual_noise_ledger_signal":
        watch.append("noise_visibility_removed")
    if row["removed_module"] == "local_audit_module_signal" and row["action_local_audit_passed_rows"] == 0:
        watch.append("local_audit_confirmation_removed")
    if row["removed_module"] == "parameter_shadow_delta" and row["max_shadow_total_abs_delta"] == 0:
        watch.append("shadow_delta_removed")
    if not row["all_sanity_checks_passed"]:
        watch.append("sanity_check_failed")
    if "boundary_violation" in watch or "unverified_exploration_leak" in watch or "sanity_check_failed" in watch:
        status = "fail"
    elif watch:
        status = "pass_with_ablation_effect"
    else:
        status = "pass"
    row["ablation_status"] = status
    row["ablation_watch_flags_json"] = json.dumps(watch, ensure_ascii=False)
    row["watch_flag_count"] = len(watch)
    return row


def build_delta_matrix(matrix: pd.DataFrame) -> pd.DataFrame:
    if matrix.empty:
        return pd.DataFrame()
    base = matrix[matrix["ablation_id"].eq("A00_full_integrated_baseline")]
    if base.empty:
        return pd.DataFrame()
    b = base.iloc[0]
    metrics = [
        "exploration_candidate_rows", "exploration_projection_rows", "action_frame_rows",
        "mean_action_frame_strength", "max_coactivation_risk_score", "max_noise_score",
        "max_shadow_total_abs_delta", "final_world_uncertainty", "final_world_exploration", "final_world_relation_lock",
    ]
    rows = []
    for _, r in matrix.iterrows():
        if r["ablation_id"] == "A00_full_integrated_baseline":
            continue
        out = {
            "ablation_id": r["ablation_id"],
            "removed_module": r["removed_module"],
            "ablation_family": r["ablation_family"],
        }
        for m in metrics:
            out[f"{m}_baseline"] = float(b.get(m, 0.0))
            out[f"{m}_ablated"] = float(r.get(m, 0.0))
            out[f"{m}_delta_vs_baseline"] = float(r.get(m, 0.0)) - float(b.get(m, 0.0))
        rows.append(out)
    return pd.DataFrame(rows)


def build_interpretation(matrix: pd.DataFrame, delta: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, r in matrix.iterrows():
        aid = r["ablation_id"]
        if aid == "A00_full_integrated_baseline":
            rows.append({
                "ablation_id": aid,
                "interpretation_level": "baseline",
                "finding_jp": "全モジュール有効の比較基準。境界違反なしで通るかを確認する。",
                "rc1_decision_jp": "保持。Task19 freezeの基準線に使う。",
            })
            continue
        flags = json.loads(r.get("ablation_watch_flags_json", "[]"))
        finding = []
        decision = ""
        if "exploration_projection_removed_or_absent" in flags:
            finding.append("探索projectionが消失または無効化され、探索から作用候補への寄与が落ちた。")
        if "noise_visibility_removed" in flags:
            finding.append("ノイズ台帳の信号を消すと、未分類ノイズの可視性が落ちる。")
        if "local_audit_confirmation_removed" in flags:
            finding.append("v8局所確認を外すと、探索projection適格性と作用候補確認が弱くなる。")
        if "gate_modulation_absent_under_risk" in flags:
            finding.append("同時発火リスクがあるのにgate調整が働かない状態が見える。")
        if "shadow_delta_removed" in flags:
            finding.append("shadow deltaを消すと、仮パラメーター更新の遅延寄与を見られなくなる。")
        if not finding:
            finding.append("境界違反なし。差分は限定的だが、部品寄与はdelta matrixで確認対象。")
        if r["ablation_status"] == "fail":
            decision = "この除去は境界リスクを伴うため、RC1構成から外さない。"
        elif r["ablation_status"] == "pass_with_ablation_effect":
            decision = "境界は保てるが機能寄与が落ちる。RC1では保持し、後続で閾値・強度調整対象。"
        else:
            decision = "RC1では寄与小。保持/簡略化はTask19前に再確認。"
        rows.append({
            "ablation_id": aid,
            "interpretation_level": "diagnostic",
            "finding_jp": " ".join(finding),
            "rc1_decision_jp": decision,
        })
    return pd.DataFrame(rows)


def run_ablation_validation(out_dir: Path) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    case_root = out_dir / "ablation_outputs"
    case_root.mkdir(parents=True, exist_ok=True)
    summaries: List[dict] = []

    for case in ABLATION_CASES:
        runner = build_runner(case)
        outputs = runner.run()
        case_dir = case_root / case["ablation_id"]
        case_dir.mkdir(parents=True, exist_ok=True)
        for table_name in [
            "cycle_audit_row", "boundary_guard_summary", "boundary_violation_report",
            "exploration_decision", "exploration_projection", "exploration_sidecar",
            "exploration_local_audit", "action_local_audit", "coactivation_gate",
            "parameter_shadow_audit", "action_frame", "residual_noise_ledger_audit",
        ]:
            outputs.get(table_name, pd.DataFrame()).to_csv(
                case_dir / f"fullspec_task18_{case['ablation_id']}_{table_name}_RC1.csv", index=False
            )
        summaries.append(summarize_outputs(case, outputs))

    matrix = pd.DataFrame(summaries)
    delta = build_delta_matrix(matrix)
    interpretation = build_interpretation(matrix, delta)
    aggregate = pd.DataFrame([{
        "task": "Task18_AblationValidation_RC1",
        "ablation_case_count": int(len(matrix)),
        "pass_count": int((matrix["ablation_status"] == "pass").sum()),
        "pass_with_ablation_effect_count": int((matrix["ablation_status"] == "pass_with_ablation_effect").sum()),
        "fail_count": int((matrix["ablation_status"] == "fail").sum()),
        "total_boundary_violations": int(matrix["boundary_violation_count"].sum()),
        "all_cases_no_boundary_violation": bool((matrix["boundary_violation_count"] == 0).all()),
        "all_cases_no_canonical_write": bool(not matrix["canonical_write_performed"].astype(bool).any()),
        "all_cases_no_world_shadow_write": bool(not matrix["world_write_performed"].astype(bool).any()),
        "all_cases_no_gk_writeback": bool(not matrix["gk_writeback_performed"].astype(bool).any()),
        "ablation_effect_cases": int((matrix["ablation_status"] == "pass_with_ablation_effect").sum()),
        "rc1_claim_scope": "ablation_diagnostic_only__no_superiority_no_deployment_no_safety_proof__RC1",
        "recommended_next_task": "Task19_RC1_freeze_after_review_or_optional_Task18b_if_needed",
    }])

    matrix.to_csv(out_dir / "fullspec_task18_ablation_matrix_RC1.csv", index=False)
    delta.to_csv(out_dir / "fullspec_task18_ablation_delta_vs_baseline_RC1.csv", index=False)
    interpretation.to_csv(out_dir / "fullspec_task18_ablation_interpretation_RC1.csv", index=False)
    aggregate.to_csv(out_dir / "fullspec_task18_ablation_summary_RC1.csv", index=False)
    (out_dir / "task18_ablation_validation_summary_RC1.json").write_text(json.dumps({
        "task": "Task18_AblationValidation_RC1",
        "status": "completed",
        "ablation_matrix_rows": int(len(matrix)),
        "delta_rows": int(len(delta)),
        "interpretation_rows": int(len(interpretation)),
        "aggregate": aggregate.iloc[0].to_dict(),
        "cases": summaries,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"matrix": matrix, "delta": delta, "interpretation": interpretation, "aggregate": aggregate}


if __name__ == "__main__":
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "task18_ablation_validation"
    outputs = run_ablation_validation(out)
    print(outputs["aggregate"].to_string(index=False))
