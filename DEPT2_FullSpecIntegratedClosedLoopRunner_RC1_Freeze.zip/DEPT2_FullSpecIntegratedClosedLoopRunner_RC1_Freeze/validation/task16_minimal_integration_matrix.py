"""Task16 minimal integration matrix for the FullSpec runner.

This validation is intentionally small.  It verifies that the fully wired
runner survives the minimal RC1 integration contract before stress and ablation:
  - one-step exploration-on run;
  - five-step exploration-on run;
  - five-step exploration-off regression run.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import sys
from typing import Any

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner import FullSpecIntegratedClosedLoopRunner


@dataclass(frozen=True)
class Task16Case:
    case_id: str
    steps: int
    seed: int
    scenario: str = "normal"
    exploration_enabled: bool = True


TASK16_CASES = [
    Task16Case("one_step_exploration_on", steps=1, seed=1601, exploration_enabled=True),
    Task16Case("five_step_exploration_on", steps=5, seed=1602, exploration_enabled=True),
    Task16Case("five_step_exploration_off", steps=5, seed=1603, exploration_enabled=False),
]


def _case_pass(summary: dict[str, Any], case: Task16Case) -> tuple[bool, list[str]]:
    failures: list[str] = []
    required_true = [
        "all_sanity_checks_passed",
        "upper_input_is_gk_only",
        "upper_pressure_audit_passed",
        "parameter_shadow_audit_passed",
        "shadow_carryover_enabled",
        "shadow_commit_status_all_not_committed",
        "all_noise_retained",
        "action_execution_audit_passed",
        "actionmodule_received_actionframe_only",
        "coactivation_gate_audit_passed",
        "coactivation_gate_required_before_actionframe",
        "coactivation_gate_no_writeback",
        "all_boundary_rules_passed",
        "all_modules_indexed_per_cycle",
        "all_artifacts_indexed",
        "dependency_audit_passed",
    ]
    for key in required_true:
        if not bool(summary.get(key, False)):
            failures.append(f"{key}=false_or_missing")
    required_false = [
        "canonical_write_performed",
        "world_write_performed",
        "gk_writeback_performed",
        "actionmodule_direct_core_input_detected",
        "exploration_sidecar_direct_actionmodule_input",
        "coactivation_gate_actionframe_created_by_gate",
        "coactivation_gate_actionmodule_called_by_gate",
    ]
    for key in required_false:
        if bool(summary.get(key, False)):
            failures.append(f"{key}=true")
    if int(summary.get("steps", -1)) != int(case.steps):
        failures.append(f"steps_mismatch:{summary.get('steps')}!={case.steps}")
    if int(summary.get("cycle_rows", -1)) != int(case.steps):
        failures.append(f"cycle_rows_mismatch:{summary.get('cycle_rows')}!={case.steps}")
    if int(summary.get("boundary_violation_count", -1)) != 0:
        failures.append(f"boundary_violation_count={summary.get('boundary_violation_count')}")
    if int(summary.get("action_frame_rows", 0)) <= 0:
        failures.append("action_frame_rows<=0")
    if int(summary.get("residual_noise_rows", 0)) <= 0:
        failures.append("residual_noise_rows<=0")
    if case.exploration_enabled:
        if int(summary.get("exploration_candidate_rows", 0)) <= 0:
            failures.append("exploration_candidate_rows<=0")
        if int(summary.get("exploration_projection_rows", 0)) <= 0:
            failures.append("exploration_projection_rows<=0")
        if not bool(summary.get("exploration_all_passed_verified", False)):
            failures.append("exploration_all_passed_verified=false")
        if bool(summary.get("exploration_unverified_candidate_can_pass", True)):
            failures.append("exploration_unverified_candidate_can_pass=true")
    else:
        if int(summary.get("exploration_candidate_rows", -1)) != 0:
            failures.append(f"exploration_candidate_rows_not_zero:{summary.get('exploration_candidate_rows')}")
        if int(summary.get("exploration_projection_rows", -1)) != 0:
            failures.append(f"exploration_projection_rows_not_zero:{summary.get('exploration_projection_rows')}")
        if int(summary.get("exploration_sidecar_rows", -1)) != int(case.steps):
            failures.append(f"exploration_sidecar_rows_mismatch:{summary.get('exploration_sidecar_rows')}!={case.steps}")
        if str(summary.get("exploration_status")) != "skipped_disabled":
            failures.append(f"exploration_status_not_skipped_disabled:{summary.get('exploration_status')}")
    return len(failures) == 0, failures


def run_task16_matrix(out_dir: Path | str) -> dict[str, Any]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    case_summaries = []
    for case in TASK16_CASES:
        case_dir = out_dir / case.case_id
        cfg = FullSpecRunnerConfig(
            steps=case.steps,
            seed=case.seed,
            scenario=case.scenario,
            exploration_enabled=case.exploration_enabled,
            output_prefix=f"fullspec_task16_{case.case_id}",
        )
        summary = FullSpecIntegratedClosedLoopRunner(cfg).write_outputs(case_dir)
        passed, failures = _case_pass(summary, case)
        row = {
            "case_id": case.case_id,
            "steps": case.steps,
            "seed": case.seed,
            "scenario": case.scenario,
            "exploration_enabled": case.exploration_enabled,
            "case_status": "pass" if passed else "fail",
            "failure_count": len(failures),
            "failure_reasons": "|".join(failures),
            "cycle_rows": int(summary.get("cycle_rows", -1)),
            "action_frame_rows": int(summary.get("action_frame_rows", 0)),
            "residual_noise_rows": int(summary.get("residual_noise_rows", 0)),
            "exploration_candidate_rows": int(summary.get("exploration_candidate_rows", 0)),
            "exploration_projection_rows": int(summary.get("exploration_projection_rows", 0)),
            "exploration_sidecar_rows": int(summary.get("exploration_sidecar_rows", 0)),
            "coactivation_gate_decisions": ",".join(map(str, summary.get("coactivation_gate_decisions", []))),
            "boundary_violation_count": int(summary.get("boundary_violation_count", -1)),
            "all_sanity_checks_passed": bool(summary.get("all_sanity_checks_passed", False)),
            "summary_file": str(case_dir / f"fullspec_task16_{case.case_id}_summary_RC1.json"),
        }
        rows.append(row)
        case_summaries.append(summary)
    matrix = pd.DataFrame(rows)
    matrix_path = out_dir / "fullspec_task16_minimal_integration_matrix_RC1.csv"
    matrix.to_csv(matrix_path, index=False)
    aggregate = {
        "task": "Task16_MinimalIntegrationTest_RC1",
        "status": "pass" if matrix["case_status"].eq("pass").all() else "fail",
        "case_count": int(len(matrix)),
        "passed_case_count": int(matrix["case_status"].eq("pass").sum()),
        "failed_case_count": int(matrix["case_status"].eq("fail").sum()),
        "cases": rows,
        "matrix_file": str(matrix_path),
        "minimal_integration_contract": "1step_on__5step_on__5step_off__boundary_clean__shadow_only__ActionFrame_only__RC1",
        "known_scope_limits": [
            "Task16 is a minimal integration test, not stress validation.",
            "Exploration-disabled mode validates boundary regression only; it intentionally emits no exploration projection.",
            "Combined interference remains a later Task17/Task18 validation concern.",
        ],
    }
    aggregate_path = out_dir / "fullspec_task16_minimal_integration_summary_RC1.json"
    aggregate_path.write_text(json.dumps(aggregate, indent=2, ensure_ascii=False), encoding="utf-8")
    return aggregate


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "task16_minimal_matrix"
    print(json.dumps(run_task16_matrix(target), indent=2, ensure_ascii=False))
