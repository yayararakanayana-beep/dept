"""Task19 RC1 freeze validation for the FullSpec Integrated Closed Loop Runner.

Default mode is freeze-review mode: it validates the already generated Task16,
Task17, and Task18 RC1 artifacts included in this package.  This avoids making
RC1 freeze depend on a long full rerun in constrained environments.

Use --full-rerun to regenerate Task16/17/18 acceptance artifacts from code.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import json
import shutil
import sys
from typing import Any

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from validation.task16_minimal_integration_matrix import run_task16_matrix
from validation.task17_stress_scenario_validation import run_stress_matrix
from validation.task18_ablation_validation import run_ablation_validation


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _as_bool(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        return v.lower() in {"true", "1", "yes", "pass"}
    return bool(v)


def _safe_int(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except Exception:
        return default


def _existing_task_summaries() -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    t16 = _load_json(ROOT / "results" / "task16_minimal_matrix" / "fullspec_task16_minimal_integration_summary_RC1.json")
    t17 = _load_json(ROOT / "results" / "task17_stress_matrix" / "task17_stress_validation_summary_RC1.json")
    t18 = _load_json(ROOT / "results" / "task18_ablation_validation" / "task18_ablation_validation_summary_RC1.json")
    return t16, t17, t18


def _full_rerun_task_summaries(out_dir: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    t16 = run_task16_matrix(out_dir / "task16_acceptance")
    t17 = run_stress_matrix(out_dir / "task17_acceptance")
    t18 = run_ablation_validation(out_dir / "task18_acceptance")
    return t16, t17, t18


def _aggregate_task17(stress: dict[str, Any]) -> dict[str, Any]:
    agg = stress.get("aggregate", stress)
    return {
        "case_count": _safe_int(agg.get("case_count", stress.get("scenario_matrix_rows", 0))),
        "fail_count": _safe_int(agg.get("fail_count", 0)),
        "pass_with_watch_count": _safe_int(agg.get("pass_with_watch_count", 0)),
        "total_boundary_violations": _safe_int(agg.get("total_boundary_violations", 0)),
        "all_cases_no_boundary_violation": _as_bool(agg.get("all_cases_no_boundary_violation", False)),
        "all_cases_no_canonical_write": _as_bool(agg.get("all_cases_no_canonical_write", False)),
        "all_cases_no_world_shadow_write": _as_bool(agg.get("all_cases_no_world_shadow_write", False)),
        "all_cases_no_gk_writeback": _as_bool(agg.get("all_cases_no_gk_writeback", False)),
    }


def _aggregate_task18(ablation: dict[str, Any]) -> dict[str, Any]:
    agg = ablation.get("aggregate", ablation)
    return {
        "case_count": _safe_int(agg.get("ablation_case_count", ablation.get("ablation_matrix_rows", 0))),
        "fail_count": _safe_int(agg.get("fail_count", 0)),
        "pass_with_ablation_effect_count": _safe_int(agg.get("pass_with_ablation_effect_count", 0)),
        "total_boundary_violations": _safe_int(agg.get("total_boundary_violations", 0)),
        "all_cases_no_boundary_violation": _as_bool(agg.get("all_cases_no_boundary_violation", False)),
        "all_cases_no_canonical_write": _as_bool(agg.get("all_cases_no_canonical_write", False)),
        "all_cases_no_world_shadow_write": _as_bool(agg.get("all_cases_no_world_shadow_write", False)),
        "all_cases_no_gk_writeback": _as_bool(agg.get("all_cases_no_gk_writeback", False)),
    }


def _write_reference_copy(src: Path, dst: Path) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.exists():
        shutil.copy2(src, dst)
        return str(dst)
    return str(src)


def run_task19_freeze_validation(out_dir: Path | str, full_rerun: bool = False) -> dict[str, Any]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if full_rerun:
        task16, task17, task18 = _full_rerun_task_summaries(out_dir)
        evidence_mode = "full_rerun"
    else:
        task16, task17, task18 = _existing_task_summaries()
        evidence_mode = "included_artifact_review"
        _write_reference_copy(
            ROOT / "results" / "task16_minimal_matrix" / "fullspec_task16_minimal_integration_summary_RC1.json",
            out_dir / "included_task16_minimal_integration_summary_RC1.json",
        )
        _write_reference_copy(
            ROOT / "results" / "task17_stress_matrix" / "task17_stress_validation_summary_RC1.json",
            out_dir / "included_task17_stress_validation_summary_RC1.json",
        )
        _write_reference_copy(
            ROOT / "results" / "task18_ablation_validation" / "task18_ablation_validation_summary_RC1.json",
            out_dir / "included_task18_ablation_validation_summary_RC1.json",
        )

    t17 = _aggregate_task17(task17)
    t18 = _aggregate_task18(task18)

    required_checks = [
        ("task16_status_pass", task16.get("status") == "pass"),
        ("task16_all_cases_pass", _safe_int(task16.get("failed_case_count", 1)) == 0),
        ("task17_no_fail", t17["fail_count"] == 0),
        ("task17_boundary_clean", t17["total_boundary_violations"] == 0 and t17["all_cases_no_boundary_violation"]),
        ("task17_no_canonical_write", t17["all_cases_no_canonical_write"]),
        ("task17_no_world_shadow_write", t17["all_cases_no_world_shadow_write"]),
        ("task17_no_gk_writeback", t17["all_cases_no_gk_writeback"]),
        ("task18_no_fail", t18["fail_count"] == 0),
        ("task18_boundary_clean", t18["total_boundary_violations"] == 0 and t18["all_cases_no_boundary_violation"]),
        ("task18_no_canonical_write", t18["all_cases_no_canonical_write"]),
        ("task18_no_world_shadow_write", t18["all_cases_no_world_shadow_write"]),
        ("task18_no_gk_writeback", t18["all_cases_no_gk_writeback"]),
    ]
    rows = [{"check_id": k, "passed": bool(v)} for k, v in required_checks]
    checks_df = pd.DataFrame(rows)
    checks_path = out_dir / "fullspec_task19_freeze_acceptance_checks_RC1.csv"
    checks_df.to_csv(checks_path, index=False)

    allowed_claim = "limited_synthetic_pseudo_reality_integrated_closed_loop_runner_freeze__RC1"
    forbidden_claims = [
        "deployment_ready",
        "real_world_safety_proven",
        "combined_interference_solved",
        "canonical_parameter_update_enabled",
        "gk_writeback_enabled",
        "external_benchmark_superiority",
    ]
    claims_path = out_dir / "fullspec_task19_claim_boundary_RC1.csv"
    pd.DataFrame([{"claim": allowed_claim, "status": "allowed"}] + [
        {"claim": c, "status": "forbidden"} for c in forbidden_claims
    ]).to_csv(claims_path, index=False)

    summary = {
        "task": "Task19_FullSpecIntegratedClosedLoopRunner_RC1_Freeze",
        "status": "freeze_pass" if checks_df["passed"].all() else "freeze_fail",
        "freeze_version": "RC1",
        "evidence_mode": evidence_mode,
        "task16_status": task16.get("status"),
        "task16_case_count": _safe_int(task16.get("case_count", 0)),
        "task16_failed_case_count": _safe_int(task16.get("failed_case_count", 0)),
        "task17_case_count": t17["case_count"],
        "task17_fail_count": t17["fail_count"],
        "task17_pass_with_watch_count": t17["pass_with_watch_count"],
        "task17_total_boundary_violations": t17["total_boundary_violations"],
        "task18_case_count": t18["case_count"],
        "task18_fail_count": t18["fail_count"],
        "task18_pass_with_ablation_effect_count": t18["pass_with_ablation_effect_count"],
        "task18_total_boundary_violations": t18["total_boundary_violations"],
        "all_required_checks_passed": bool(checks_df["passed"].all()),
        "canonical_write_enabled": False,
        "gk_writeback_enabled": False,
        "deployment_claim_allowed": False,
        "allowed_claim_scope": allowed_claim,
        "forbidden_claims": forbidden_claims,
        "acceptance_checks_file": str(checks_path),
        "claim_boundary_file": str(claims_path),
        "recommended_next": "Task20_commit_proposal_design_or_Task20b_watch_deepening_before_any_canonical_update",
    }
    summary_path = out_dir / "task19_freeze_validation_summary_RC1.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    pd.DataFrame([summary]).to_csv(out_dir / "fullspec_task19_freeze_summary_RC1.csv", index=False)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("out_dir", nargs="?", default=str(ROOT / "results" / "task19_freeze_validation"))
    parser.add_argument("--full-rerun", action="store_true", help="Regenerate Task16/17/18 acceptance outputs before freeze review. This can take longer.")
    args = parser.parse_args()
    print(json.dumps(run_task19_freeze_validation(Path(args.out_dir), full_rerun=args.full_rerun), indent=2, ensure_ascii=False))
