"""Task17 stress / scenario validation for FullSpec Integrated Closed Loop Runner RC1.

Task17 does not claim deployment safety or superiority.  It runs the already
integrated Task12/Task16 runner across stress-like synthetic settings and
summarizes where the RC1 loop remains stable, where it only passes with watch
flags, and what should be carried into Task18 ablation and later freeze review.
"""
from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Dict, Iterable, List
import json
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dept2_fullspec_runner_rc1.contracts import FullSpecRunnerConfig
from dept2_fullspec_runner_rc1.runner.fullspec_integrated_closed_loop_runner import FullSpecIntegratedClosedLoopRunner


def _max(df: pd.DataFrame, col: str, default: float = 0.0) -> float:
    if df is None or df.empty or col not in df.columns:
        return float(default)
    return float(pd.to_numeric(df[col], errors="coerce").fillna(default).max())


def _mean(df: pd.DataFrame, col: str, default: float = 0.0) -> float:
    if df is None or df.empty or col not in df.columns:
        return float(default)
    return float(pd.to_numeric(df[col], errors="coerce").fillna(default).mean())


def _last(df: pd.DataFrame, col: str, default=None):
    if df is None or df.empty or col not in df.columns:
        return default
    return df[col].iloc[-1]


def _count_values(df: pd.DataFrame, col: str) -> dict:
    if df is None or df.empty or col not in df.columns:
        return {}
    return {str(k): int(v) for k, v in df[col].astype(str).value_counts().sort_index().items()}


SCENARIOS: List[dict] = [
    {
        "case_id": "S00_baseline_normal",
        "stress_family": "baseline",
        "reason": "最小統合後の基準線。stress判定の比較対象。",
        "cfg": dict(steps=6, seed=1700, scenario="normal", n_entities=18, noise_scale=0.018, drift_scale=0.006, action_coupling=0.045, exploration_enabled=True),
    },
    {
        "case_id": "S01_high_noise_residual_growth",
        "stress_family": "residual_noise_growth",
        "reason": "未分類ノイズ・残差増大時にO_t/noise ledger/explorationが落ちないか確認。",
        "cfg": dict(steps=8, seed=1701, scenario="normal", n_entities=18, noise_scale=0.060, drift_scale=0.016, action_coupling=0.045, exploration_enabled=True),
    },
    {
        "case_id": "S02_exploration_loss_overconvergence",
        "stress_family": "overconvergence_exploration_loss",
        "reason": "探索低下・関係固定化方向のdriftで、探索候補とshadowが安全境界内に留まるか確認。",
        "cfg": dict(steps=10, seed=1702, scenario="exploration_loss", n_entities=18, noise_scale=0.026, drift_scale=0.012, action_coupling=0.050, exploration_enabled=True),
    },
    {
        "case_id": "S03_relation_lock_pressure",
        "stress_family": "relation_lock",
        "reason": "relation_lock/couplingが高い系で、作用候補・gate・境界guardが破綻しないか確認。",
        "cfg": dict(steps=10, seed=1703, scenario="relation_lock", n_entities=18, noise_scale=0.030, drift_scale=0.012, action_coupling=0.050, exploration_enabled=True),
    },
    {
        "case_id": "S04_dense_coactivation_pressure",
        "stress_family": "same_step_coactivation",
        "reason": "候補数・作用密度・noiseを増やして、同時発火門がwatch/defer/block相当を監査できるか確認。",
        "cfg": dict(steps=8, seed=1704, scenario="relation_lock", n_entities=24, noise_scale=0.040, drift_scale=0.014, action_coupling=0.080, exploration_enabled=True),
    },
    {
        "case_id": "S05_shock_recovery_window",
        "stress_family": "shock_recovery",
        "reason": "PseudoReality既定shock_time=18を跨ぎ、外乱後に境界が維持されるか確認。",
        "cfg": dict(steps=20, seed=1705, scenario="shock", n_entities=18, noise_scale=0.026, drift_scale=0.008, action_coupling=0.050, exploration_enabled=True),
    },
    {
        "case_id": "S06_exploration_off_high_noise_regression",
        "stress_family": "exploration_off_regression",
        "reason": "探索offでもzero-source監査と基本閉ループが壊れないか確認。",
        "cfg": dict(steps=8, seed=1706, scenario="normal", n_entities=18, noise_scale=0.050, drift_scale=0.014, action_coupling=0.045, exploration_enabled=False),
    },
]


def classify_watch(summary: dict) -> tuple[str, List[str]]:
    watch: List[str] = []
    if summary["boundary_violation_count"] > 0:
        watch.append("boundary_violation")
    if summary["max_noise_score"] >= 0.72 or summary["max_active_noise_rows"] >= 6:
        watch.append("residual_noise_high")
    if summary["max_coactivation_risk_score"] >= 0.64:
        watch.append("coactivation_defer_zone")
    elif summary["max_coactivation_risk_score"] >= 0.36:
        watch.append("coactivation_dampen_zone")
    if summary["max_local_observation_need"] >= 0.62:
        watch.append("local_observation_need_high")
    if summary["max_shadow_total_abs_delta"] >= 0.60:
        watch.append("shadow_delta_high")
    if summary["exploration_unverified_candidate_can_pass"]:
        watch.append("unverified_exploration_leak")
    if summary["exploration_enabled"] and summary["exploration_projection_rows"] == 0:
        watch.append("exploration_projection_absent")
    if summary["gate_defer_count"] > 0 or summary["gate_block_count"] > 0:
        watch.append("gate_restrictive_decision_present")
    if not summary["all_sanity_checks_passed"]:
        watch.append("sanity_check_failed")

    if "boundary_violation" in watch or "unverified_exploration_leak" in watch or "sanity_check_failed" in watch:
        status = "fail"
    elif watch:
        status = "pass_with_watch"
    else:
        status = "pass"
    return status, watch


def summarize_case(case: dict, outputs: Dict[str, pd.DataFrame]) -> dict:
    cycle = outputs.get("cycle_audit_row", pd.DataFrame())
    gate = outputs.get("coactivation_gate", pd.DataFrame())
    decision = outputs.get("exploration_decision", pd.DataFrame())
    projection = outputs.get("exploration_projection", pd.DataFrame())
    sidecar = outputs.get("exploration_sidecar", pd.DataFrame())
    boundary = outputs.get("boundary_violation_report", pd.DataFrame())
    action_frame = outputs.get("action_frame", pd.DataFrame())
    shadow = outputs.get("parameter_shadow_audit", pd.DataFrame())
    local_needs = outputs.get("local_observation_needs", pd.DataFrame())

    cfg = case["cfg"]
    boundary_count = int(cycle["boundary_violation_count"].sum()) if not cycle.empty and "boundary_violation_count" in cycle.columns else int(len(boundary))
    all_sanity = bool(
        not cycle.empty
        and len(cycle) == int(cfg["steps"])
        and boundary_count == 0
        and not outputs.get("world_transition_audit", pd.DataFrame()).empty
        and not outputs.get("gk_build_audit", pd.DataFrame()).empty
        and not outputs.get("ot_observation_audit", pd.DataFrame()).empty
        and not outputs.get("upper_pressure_audit", pd.DataFrame()).empty
        and not outputs.get("action_execution_audit", pd.DataFrame()).empty
        and not outputs.get("boundary_guard_summary", pd.DataFrame()).empty
    )
    # Exploration-off is valid with zero projection, but sidecar should retain per-cycle zero-source rows.
    if cfg.get("exploration_enabled", True):
        all_sanity = all_sanity and len(projection) > 0 and len(sidecar) > 0
    else:
        all_sanity = all_sanity and len(sidecar) >= int(cfg["steps"])

    gate_counts = _count_values(cycle, "gate_decision") or _count_values(gate, "coactivation_gate_decision")
    summary = {
        "case_id": case["case_id"],
        "stress_family": case["stress_family"],
        "reason_jp": case["reason"],
        "scenario": cfg["scenario"],
        "seed": int(cfg["seed"]),
        "steps": int(cfg["steps"]),
        "n_entities": int(cfg["n_entities"]),
        "noise_scale": float(cfg["noise_scale"]),
        "drift_scale": float(cfg["drift_scale"]),
        "action_coupling": float(cfg["action_coupling"]),
        "exploration_enabled": bool(cfg["exploration_enabled"]),
        "cycle_rows": int(len(cycle)),
        "action_frame_rows": int(len(action_frame)),
        "exploration_candidate_rows": int(len(outputs.get("exploration_candidates", pd.DataFrame()))),
        "exploration_sandbox_rows": int(len(outputs.get("exploration_sandbox", pd.DataFrame()))),
        "exploration_projection_rows": int(len(projection)),
        "exploration_sidecar_rows": int(len(sidecar)),
        "exploration_passed_count_max": int(_max(decision, "passed_count", 0)),
        "exploration_watch_count_max": int(_max(decision, "watch_count", 0)),
        "exploration_blocked_count_max": int(_max(decision, "blocked_count", 0)),
        "exploration_unverified_candidate_can_pass": bool(decision.get("unverified_candidate_can_pass", pd.Series([False])).astype(bool).any()) if not decision.empty and "unverified_candidate_can_pass" in decision.columns else False,
        "max_noise_score": _max(cycle, "max_noise_score", 0.0),
        "mean_noise_score": _mean(cycle, "max_noise_score", 0.0),
        "max_active_noise_rows": int(_max(cycle, "active_noise_rows", 0)),
        "max_persistent_noise_rows": int(_max(cycle, "persistent_noise_rows", 0)),
        "max_exploration_gap": _max(cycle, "max_exploration_gap", 0.0),
        "max_local_observation_need": _max(cycle, "max_local_observation_need", 0.0),
        "max_coactivation_risk_score": max(_max(cycle, "coactivation_risk_score", 0.0), _max(gate, "coactivation_risk_score", 0.0)),
        "mean_coactivation_risk_score": _mean(cycle, "coactivation_risk_score", 0.0),
        "gate_decision_counts_json": json.dumps(gate_counts, ensure_ascii=False, sort_keys=True),
        "gate_allow_count": int(gate_counts.get("allow", 0)),
        "gate_dampen_count": int(gate_counts.get("dampen", 0)),
        "gate_defer_count": int(gate_counts.get("defer", 0)),
        "gate_block_count": int(gate_counts.get("block", 0)),
        "gate_monitor_only_count": int(gate_counts.get("monitor_only", 0)),
        "max_shadow_total_abs_delta": _max(cycle, "shadow_total_abs_delta", _max(shadow, "total_abs_theta_delta", 0.0)),
        "canonical_write_performed": bool(shadow.get("canonical_write_performed", pd.Series([False])).astype(bool).any()) if not shadow.empty and "canonical_write_performed" in shadow.columns else False,
        "world_write_performed": bool(shadow.get("world_write_performed", pd.Series([False])).astype(bool).any()) if not shadow.empty and "world_write_performed" in shadow.columns else False,
        "gk_writeback_performed": bool(shadow.get("gk_writeback_performed", pd.Series([False])).astype(bool).any()) if not shadow.empty and "gk_writeback_performed" in shadow.columns else False,
        "final_world_uncertainty": float(_last(cycle, "world_mean_uncertainty", 0.0) or 0.0),
        "final_world_exploration": float(_last(cycle, "world_mean_exploration", 0.0) or 0.0),
        "final_world_relation_lock": float(_last(cycle, "world_mean_relation_lock", 0.0) or 0.0),
        "boundary_violation_count": boundary_count,
        "boundary_violation_report_rows": int(len(boundary)),
        "all_sanity_checks_passed": all_sanity,
        "stress_validation_claim_scope": "synthetic_pseudo_reality_stress_diagnostic_only__not_deployment_safety__RC1",
    }
    status, watch = classify_watch(summary)
    summary["stress_case_status"] = status
    summary["watch_flags_json"] = json.dumps(watch, ensure_ascii=False)
    summary["watch_flag_count"] = len(watch)
    return summary


def build_timeseries(case: dict, outputs: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    cycle = outputs.get("cycle_audit_row", pd.DataFrame()).copy()
    if cycle.empty:
        return pd.DataFrame()
    keep = [c for c in [
        "loop_step", "world_t", "world_mean_uncertainty", "world_mean_exploration", "world_mean_relation_lock",
        "max_noise_score", "active_noise_rows", "persistent_noise_rows", "max_exploration_gap",
        "upper_pressure_l1", "shadow_total_abs_delta", "exploration_candidate_rows", "exploration_projection_rows",
        "max_local_observation_need", "gate_decision", "coactivation_risk_score", "action_frame_rows", "boundary_violation_count",
    ] if c in cycle.columns]
    ts = cycle[keep].copy()
    ts.insert(0, "case_id", case["case_id"])
    ts.insert(1, "stress_family", case["stress_family"])
    return ts


def build_watchlist(summaries: List[dict]) -> pd.DataFrame:
    rows = []
    for s in summaries:
        flags = json.loads(s.get("watch_flags_json", "[]"))
        if not flags:
            rows.append({
                "case_id": s["case_id"], "stress_family": s["stress_family"], "watch_flag": "none",
                "severity": "none", "suggested_next_action_jp": "現時点では追加watchなし。Task18で通常ablation対象にする。",
            })
            continue
        for f in flags:
            severity = "fail" if f in {"boundary_violation", "unverified_exploration_leak", "sanity_check_failed"} else "watch"
            suggestion = {
                "residual_noise_high": "Task18でnoise ledgerなし/探索なし比較を行い、未分類ノイズが作用候補に過剰反映されていないか見る。",
                "coactivation_dampen_zone": "同時発火門は働いている。Task17ではwatch、Task18でgateなし比較を行う。",
                "coactivation_defer_zone": "defer領域に入るため、gate閾値・作用候補強度・探索projectionの寄与を分けて確認する。",
                "local_observation_need_high": "Task18でlocal auditなし比較を行い、局所観測要求が妥当か確認する。",
                "shadow_delta_high": "shadow更新が強いため、後続の本更新フェーズではcommit gate対象にする。",
                "gate_restrictive_decision_present": "gateが制限判断を出している。挙動自体は正常だが、作用不足とのトレードオフを後続で見る。",
                "exploration_projection_absent": "探索onなのにprojectionがない。候補生成・sandbox・local auditのどこで落ちたかを見る。",
            }.get(f, "Task18またはTask17bで原因分解する。")
            rows.append({
                "case_id": s["case_id"],
                "stress_family": s["stress_family"],
                "watch_flag": f,
                "severity": severity,
                "suggested_next_action_jp": suggestion,
            })
    return pd.DataFrame(rows)


def run_stress_matrix(out_dir: Path) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    case_root = out_dir / "scenario_outputs"
    case_root.mkdir(parents=True, exist_ok=True)
    summaries: List[dict] = []
    timeseries: List[pd.DataFrame] = []

    for case in SCENARIOS:
        cfg_dict = dict(case["cfg"])
        cfg_dict["output_prefix"] = f"fullspec_task17_{case['case_id']}"
        cfg = FullSpecRunnerConfig(**cfg_dict)
        runner = FullSpecIntegratedClosedLoopRunner(cfg)
        outputs = runner.run()
        case_dir = case_root / case["case_id"]
        case_dir.mkdir(parents=True, exist_ok=True)
        # Task17 keeps per-case outputs deliberately compact.  Full per-module
        # dumps are already covered by Task16; here we persist only stress-
        # relevant audit tables so the package remains light and rerunnable.
        for table_name in [
            "cycle_audit_row",
            "coactivation_gate",
            "exploration_decision",
            "exploration_projection",
            "residual_noise_ledger_audit",
            "boundary_guard_summary",
            "boundary_violation_report",
        ]:
            df = outputs.get(table_name, pd.DataFrame())
            df.to_csv(case_dir / f"fullspec_task17_{case['case_id']}_{table_name}_RC1.csv", index=False)
        summaries.append(summarize_case(case, outputs))
        ts = build_timeseries(case, outputs)
        if not ts.empty:
            timeseries.append(ts)

    matrix = pd.DataFrame(summaries)
    ts_df = pd.concat(timeseries, ignore_index=True) if timeseries else pd.DataFrame()
    watch = build_watchlist(summaries)
    aggregate = pd.DataFrame([{
        "task": "Task17_StressScenarioValidation_RC1",
        "case_count": int(len(matrix)),
        "pass_count": int((matrix["stress_case_status"] == "pass").sum()),
        "pass_with_watch_count": int((matrix["stress_case_status"] == "pass_with_watch").sum()),
        "fail_count": int((matrix["stress_case_status"] == "fail").sum()),
        "total_boundary_violations": int(matrix["boundary_violation_count"].sum()),
        "all_cases_no_boundary_violation": bool((matrix["boundary_violation_count"] == 0).all()),
        "all_cases_no_canonical_write": bool(not matrix["canonical_write_performed"].astype(bool).any()),
        "all_cases_no_world_shadow_write": bool(not matrix["world_write_performed"].astype(bool).any()),
        "all_cases_no_gk_writeback": bool(not matrix["gk_writeback_performed"].astype(bool).any()),
        "max_observed_noise_score": float(matrix["max_noise_score"].max()) if not matrix.empty else 0.0,
        "max_observed_coactivation_risk": float(matrix["max_coactivation_risk_score"].max()) if not matrix.empty else 0.0,
        "rc1_claim_scope": "stress_diagnostic_only__no_real_world_safety_or_deployment_claim__RC1",
        "recommended_next_task": "Task18_ablation_validation",
    }])

    matrix.to_csv(out_dir / "fullspec_task17_stress_scenario_matrix_RC1.csv", index=False)
    ts_df.to_csv(out_dir / "fullspec_task17_stress_metric_timeseries_RC1.csv", index=False)
    watch.to_csv(out_dir / "fullspec_task17_watchlist_RC1.csv", index=False)
    aggregate.to_csv(out_dir / "fullspec_task17_stress_validation_summary_RC1.csv", index=False)
    (out_dir / "task17_stress_validation_summary_RC1.json").write_text(json.dumps({
        "task": "Task17_StressScenarioValidation_RC1",
        "status": "completed",
        "scenario_matrix_rows": int(len(matrix)),
        "timeseries_rows": int(len(ts_df)),
        "watchlist_rows": int(len(watch)),
        "aggregate": aggregate.iloc[0].to_dict(),
        "cases": summaries,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"matrix": matrix, "timeseries": ts_df, "watchlist": watch, "aggregate": aggregate}


if __name__ == "__main__":
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "task17_stress_matrix"
    outputs = run_stress_matrix(out)
    print(outputs["aggregate"].to_string(index=False))
