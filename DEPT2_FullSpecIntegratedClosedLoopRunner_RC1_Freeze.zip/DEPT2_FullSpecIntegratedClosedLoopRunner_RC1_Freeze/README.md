# DEPT2 FullSpec Integrated Closed Loop Runner RC1 Freeze

このパッケージは、Task2〜Task18で構築・検証した **DEPT2 FullSpec Integrated Closed Loop Runner** の RC1 freeze 版です。

目的は、限定的な疑似現実上で、以下を1本の閉ループとして再実行・監査できる状態に固定することです。

```text
PseudoReality
→ world_adapter
→ gk_builder
→ O_t observation / residual noise ledger
→ upper pressure
→ parameter shadow box
→ pressure translation
→ exploration module
→ local audit
→ exploration bridge
→ action surface planning
→ coactivation gate
→ action execution
→ audit ledger / boundary guard
→ PseudoReality next step
```

## Freeze status

- status: `RC1 freeze`
- scope: `synthetic pseudo-reality closed-loop validation runner`
- parameter update: `shadow only`
- canonical write: `forbidden`
- G/K writeback: `forbidden`
- ActionModule input: `ActionFrame only`
- deployment claim: `not allowed`

## 実行方法

最小実行:

```bash
python runner/run_fullspec_integrated_closed_loop_runner_rc1.py --steps 3 --seed 42 --scenario normal --out results/task19_smoke
```

Freeze acceptance validation:

```bash
python validation/task19_freeze_validation.py results/task19_freeze_validation
```

テスト:

```bash
pytest -q tests/test_fullspec_task19_freeze.py
```

## 主要な検証結果

Task19では以下をfreeze条件として確認します。

- Task16 minimal integration: pass
- Task17 stress / scenario validation: no fail, all cases pass_with_watch, boundary violation 0
- Task18 ablation validation: no fail, boundary violation 0
- canonical write 0
- world write by shadow 0
- G/K writeback 0
- boundary guard pass

## 主な文書

- `docs/TASK19_FULLSPEC_INTEGRATED_CLOSED_LOOP_RUNNER_RC1_FREEZE.md`
- `docs/RC1_CLAIM_BOUNDARY_TASK19.md`
- `docs/TASK19_FREEZE_CHECKLIST_RC1.md`
- `docs/MODULE_BOUNDARY_CONTRACT_TASK19_RC1.md`

## 注意

このRC1は、疑似現実上の統合検証runnerです。現実投入可能性、安全性証明、外部ベンチマーク優位性、combined interference solved、本パラメーター更新可能性は主張しません。
