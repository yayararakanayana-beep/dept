# Pressure Outcome Alignment Audit RC2b Report

## 0. Position

This report records **PressureOutcomeAlignmentAudit_RC2b**.

RC2b runs after:

```text
DiagnosticActionTranslationPolicy_RC1
```

Its purpose is to check whether the validation policy fixed the coverage
bottleneck found in RC2, while keeping a strict boundary:

```text
new diagnostic actions have not yet been re-run through pseudo-reality
```

Therefore RC2b separates:

```text
coverage fixed
vs
true outcome attribution still pending
```

## 1. Execution Summary

```json
{
  "task": "PressureOutcomeAlignmentAudit_RC2b",
  "status": "completed",
  "semantic_rows": 220,
  "semantic_effect_count": 14,
  "policy_plan_rate": 1.0,
  "policy_action_rate": 1.0,
  "original_plan_rate": 0.2909090909090909,
  "original_action_rate": 0.09090909090909091,
  "coverage_delta_plan": 0.7090909090909091,
  "coverage_delta_action": 0.9090909090909091,
  "observed_existing_action_attribution_rate": 0.09090909090909091,
  "outcome_pending_rate": 0.9090909090909091,
  "existing_action_alignment_rate": 0.031818181818181815,
  "coverage_fixed_outcome_pending_rate": 0.9090909090909091,
  "mean_prior_alignment_score": 0.35700757575757575,
  "outcome_attribution_status": [
    {
      "outcome_attribution_status": "diagnostic_action_created_outcome_pending",
      "rc2b_alignment_verdict": "coverage_fixed_outcome_pending",
      "rows": 200,
      "semantic_effects": 14,
      "mean_prior_alignment_score": 0.35104166666666664,
      "total_diagnostic_action_mass": 1.6982758002061196
    },
    {
      "outcome_attribution_status": "observed_existing_action_attribution",
      "rc2b_alignment_verdict": "coverage_fixed_no_prior_outcome_row",
      "rows": 4,
      "semantic_effects": 1,
      "mean_prior_alignment_score": NaN,
      "total_diagnostic_action_mass": 6.558007699710265
    },
    {
      "outcome_attribution_status": "observed_existing_action_attribution",
      "rc2b_alignment_verdict": "existing_action_aligned",
      "rows": 7,
      "semantic_effects": 2,
      "mean_prior_alignment_score": 0.8095238095238094,
      "total_diagnostic_action_mass": 13.69130606569292
    },
    {
      "outcome_attribution_status": "observed_existing_action_attribution",
      "rc2b_alignment_verdict": "existing_action_misaligned",
      "rows": 9,
      "semantic_effects": 3,
      "mean_prior_alignment_score": 0.1111111111111111,
      "total_diagnostic_action_mass": 4.997145763207634
    }
  ],
  "readiness_summary": [
    {
      "semantic_effect": "adoption_barrier_relief",
      "intent_family": "adoption_opening",
      "rows": 20,
      "original_plan_rate": 0.05,
      "original_action_rate": 0.05,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 0.95,
      "existing_observed_action_rate": 0.05,
      "mean_prior_alignment_score": 0.3333333333333333,
      "diagnostic_action_primitive": "diagnostic_adoption_opening_probe",
      "diagnostic_primitive_sequence": "adoption_opening_probe -> buffer_observe -> report",
      "diagnostic_action_channel": "exploration_injection",
      "diagnostic_action_mass": 1.0058133285512036,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "commitment_strength_down",
      "intent_family": "commitment_relief",
      "rows": 20,
      "original_plan_rate": 0.05,
      "original_action_rate": 0.05,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 0.95,
      "existing_observed_action_rate": 0.05,
      "mean_prior_alignment_score": 0.4583333333333333,
      "diagnostic_action_primitive": "diagnostic_commitment_relief_probe",
      "diagnostic_primitive_sequence": "commitment_relief -> peripheral_observe",
      "diagnostic_action_channel": "exploration_injection",
      "diagnostic_action_mass": 0.4276070344157062,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "diagnostic_resolution_down",
      "intent_family": "observation_cost_saving",
      "rows": 20,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.41666666666666663,
      "diagnostic_action_primitive": "diagnostic_observation_saving_probe",
      "diagnostic_primitive_sequence": "lighter_observation -> report",
      "diagnostic_action_channel": "uncertainty_probe",
      "diagnostic_action_mass": 0.18357636476249198,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_down",
      "intent_family": "exploration_restraint",
      "rows": 5,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.41666666666666663,
      "diagnostic_action_primitive": "diagnostic_exploration_restraint",
      "diagnostic_primitive_sequence": "exploration_restraint -> observe",
      "diagnostic_action_channel": "buffer_increase",
      "diagnostic_action_mass": 0.03,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_up",
      "intent_family": "exploration_attempt",
      "rows": 15,
      "original_plan_rate": 0.3333333333333333,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.25,
      "diagnostic_action_primitive": "diagnostic_exploration_attempt",
      "diagnostic_primitive_sequence": "exploration_attempt -> observe -> report",
      "diagnostic_action_channel": "exploration_injection",
      "diagnostic_action_mass": 0.1109473204693982,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "hysteresis_guard_down",
      "intent_family": "switching_flexibility",
      "rows": 20,
      "original_plan_rate": 0.85,
      "original_action_rate": 0.85,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 0.15,
      "existing_observed_action_rate": 0.85,
      "mean_prior_alignment_score": 0.41666666666666663,
      "diagnostic_action_primitive": "diagnostic_switching_flexibility",
      "diagnostic_primitive_sequence": "switching_flexibility -> observe",
      "diagnostic_action_channel": "coupling_relief",
      "diagnostic_action_mass": 24.110106859323448,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "intensity_cap_brake",
      "intent_family": "safety_cap",
      "rows": 20,
      "original_plan_rate": 1.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.6041666666666666,
      "diagnostic_action_primitive": "buffer_first",
      "diagnostic_primitive_sequence": "buffer -> replan",
      "diagnostic_action_channel": "buffer_increase",
      "diagnostic_action_mass": 0.1896,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "rollback_guard_down",
      "intent_family": "safety_relaxation",
      "rows": 20,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.41666666666666663,
      "diagnostic_action_primitive": "diagnostic_rollback_relaxation_probe",
      "diagnostic_primitive_sequence": "rollback_relaxation -> observe",
      "diagnostic_action_channel": "buffer_increase",
      "diagnostic_action_mass": 0.1846937285476302,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "sandbox_probe_entry_down",
      "intent_family": "probe_restraint",
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.1875,
      "diagnostic_action_primitive": "diagnostic_probe_restraint",
      "diagnostic_primitive_sequence": "probe_restraint -> observe",
      "diagnostic_action_channel": "buffer_increase",
      "diagnostic_action_mass": 0.06,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "sandbox_probe_entry_up",
      "intent_family": "exploration_observation",
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.041666666666666664,
      "diagnostic_action_primitive": "diagnostic_sandbox_probe",
      "diagnostic_primitive_sequence": "sandbox_probe -> observe -> report",
      "diagnostic_action_channel": "exploration_injection",
      "diagnostic_action_mass": 0.0632230101249339,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "sensitivity_opening",
      "intent_family": "response_opening",
      "rows": 20,
      "original_plan_rate": 1.0,
      "original_action_rate": 0.05,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 0.95,
      "existing_observed_action_rate": 0.05,
      "mean_prior_alignment_score": 0.3333333333333333,
      "diagnostic_action_primitive": "diagnostic_sensitivity_opening",
      "diagnostic_primitive_sequence": "sensitivity_opening -> observe -> report",
      "diagnostic_action_channel": "coupling_relief",
      "diagnostic_action_mass": 0.2670985848329881,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "update_access_opening",
      "intent_family": "temporal_opening",
      "rows": 20,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.3333333333333333,
      "diagnostic_action_primitive": "diagnostic_update_access_probe",
      "diagnostic_primitive_sequence": "update_access_probe -> observe -> report",
      "diagnostic_action_channel": "uncertainty_probe",
      "diagnostic_action_mass": 0.1896,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "update_frequency_down",
      "intent_family": "update_restraint",
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.375,
      "diagnostic_action_primitive": "diagnostic_update_restraint",
      "diagnostic_primitive_sequence": "update_restraint -> observe",
      "diagnostic_action_channel": "buffer_increase",
      "diagnostic_action_mass": 0.0616145947450928,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    },
    {
      "semantic_effect": "update_frequency_up",
      "intent_family": "update_opening",
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "outcome_pending_rate": 1.0,
      "existing_observed_action_rate": 0.0,
      "mean_prior_alignment_score": 0.041666666666666664,
      "diagnostic_action_primitive": "diagnostic_update_opening",
      "diagnostic_primitive_sequence": "update_opening -> observe -> report",
      "diagnostic_action_channel": "uncertainty_probe",
      "diagnostic_action_mass": 0.0608545030440428,
      "readiness_verdict": "ready_for_closed_loop_rerun"
    }
  ],
  "diagnostic_policy_summary_status": "completed",
  "dept_pressure_tuning_readiness": "not_ready_outcome_pending_requires_diagnostic_closed_loop_rerun",
  "next_recommended_task": "DiagnosticClosedLoopRerun_RC1",
  "rc2b_interpretation": "Coverage is fixed by policy; true outcome alignment requires rerunning pseudo-reality with diagnostic actions.",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/pressure_outcome_alignment_rc2b_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "rc2b_semantic_policy_alignment": "pressure_outcome_alignment_rc2b_semantic_policy_alignment.csv",
    "rc2b_coverage_delta": "pressure_outcome_alignment_rc2b_coverage_delta.csv",
    "rc2b_outcome_attribution_status": "pressure_outcome_alignment_rc2b_outcome_attribution_status.csv",
    "rc2b_diagnostic_action_readiness": "pressure_outcome_alignment_rc2b_diagnostic_action_readiness.csv",
    "rc2b_next_closed_loop_requirements": "pressure_outcome_alignment_rc2b_next_closed_loop_requirements.csv"
  },
  "boundary_note": "RC2b confirms diagnostic action coverage, but newly rescued actions require closed-loop rerun for true outcome attribution."
}
```

Focused test status:

```text
test_pressure_outcome_alignment_audit_rc2b.py: 2 passed
```

## 2. Main Result

Coverage is fixed:

```text
original_plan_rate = 0.291
policy_plan_rate = 1.000

original_action_rate = 0.091
policy_action_rate = 1.000
```

But true outcome attribution is still pending for newly rescued actions:

```text
observed_existing_action_attribution_rate = 0.091
outcome_pending_rate = 0.909
```

## 3. Coverage Delta

```text
                                   metric  before_policy  after_policy    delta                                                                   interpretation
                    semantic_to_plan_rate       0.290909      1.000000 0.709091                             diagnostic policy fixes plan coverage for validation
                      plan_to_action_rate       0.090909      1.000000 0.909091                      diagnostic policy fixes weak-action survival for validation
observed_existing_action_attribution_rate       0.090909      0.090909 0.000000     actual observed outcome attribution does not improve until closed-loop rerun
                     outcome_pending_rate       0.000000      0.909091 0.909091 new diagnostic actions require pseudo-reality rerun for true outcome measurement
```

Interpretation:

```text
DiagnosticActionTranslationPolicy_RC1 fixes the syntactic/trace coverage problem.
It does not yet prove that the new diagnostic actions caused the desired outcomes.
```

## 4. Outcome Attribution Status

```text
               outcome_attribution_status              rc2b_alignment_verdict  rows  semantic_effects  mean_prior_alignment_score  total_diagnostic_action_mass
diagnostic_action_created_outcome_pending      coverage_fixed_outcome_pending   200                14                    0.351042                      1.698276
     observed_existing_action_attribution coverage_fixed_no_prior_outcome_row     4                 1                         NaN                      6.558008
     observed_existing_action_attribution             existing_action_aligned     7                 2                    0.809524                     13.691306
     observed_existing_action_attribution          existing_action_misaligned     9                 3                    0.111111                      4.997146
```

Most rows are now:

```text
coverage_fixed_outcome_pending
```

This is expected and correct.

It means:

```text
semantic_effect now has diagnostic action coverage,
but we need a closed-loop rerun to observe the actual pseudo-reality outcome.
```

## 5. Diagnostic Action Readiness

```text
                   semantic_effect           intent_family  rows  original_plan_rate  original_action_rate  policy_plan_rate  policy_action_rate  outcome_pending_rate  existing_observed_action_rate  mean_prior_alignment_score          diagnostic_action_primitive                      diagnostic_primitive_sequence diagnostic_action_channel  diagnostic_action_mass           readiness_verdict
           adoption_barrier_relief        adoption_opening    20            0.050000                  0.05               1.0                 1.0                  0.95                           0.05                    0.333333    diagnostic_adoption_opening_probe adoption_opening_probe -> buffer_observe -> report     exploration_injection                1.005813 ready_for_closed_loop_rerun
          commitment_strength_down       commitment_relief    20            0.050000                  0.05               1.0                 1.0                  0.95                           0.05                    0.458333   diagnostic_commitment_relief_probe            commitment_relief -> peripheral_observe     exploration_injection                0.427607 ready_for_closed_loop_rerun
        diagnostic_resolution_down observation_cost_saving    20            0.000000                  0.00               1.0                 1.0                  1.00                           0.00                    0.416667  diagnostic_observation_saving_probe                      lighter_observation -> report         uncertainty_probe                0.183576 ready_for_closed_loop_rerun
exploration_attempt_frequency_down   exploration_restraint     5            0.000000                  0.00               1.0                 1.0                  1.00                           0.00                    0.416667     diagnostic_exploration_restraint                   exploration_restraint -> observe           buffer_increase                0.030000 ready_for_closed_loop_rerun
  exploration_attempt_frequency_up     exploration_attempt    15            0.333333                  0.00               1.0                 1.0                  1.00                           0.00                    0.250000       diagnostic_exploration_attempt           exploration_attempt -> observe -> report     exploration_injection                0.110947 ready_for_closed_loop_rerun
             hysteresis_guard_down   switching_flexibility    20            0.850000                  0.85               1.0                 1.0                  0.15                           0.85                    0.416667     diagnostic_switching_flexibility                   switching_flexibility -> observe           coupling_relief               24.110107 ready_for_closed_loop_rerun
               intensity_cap_brake              safety_cap    20            1.000000                  0.00               1.0                 1.0                  1.00                           0.00                    0.604167                         buffer_first                                   buffer -> replan           buffer_increase                0.189600 ready_for_closed_loop_rerun
               rollback_guard_down       safety_relaxation    20            0.000000                  0.00               1.0                 1.0                  1.00                           0.00                    0.416667 diagnostic_rollback_relaxation_probe                     rollback_relaxation -> observe           buffer_increase                0.184694 ready_for_closed_loop_rerun
          sandbox_probe_entry_down         probe_restraint    10            0.000000                  0.00               1.0                 1.0                  1.00                           0.00                    0.187500           diagnostic_probe_restraint                         probe_restraint -> observe           buffer_increase                0.060000 ready_for_closed_loop_rerun
            sandbox_probe_entry_up exploration_observation    10            0.000000                  0.00               1.0                 1.0                  1.00                           0.00                    0.041667             diagnostic_sandbox_probe                 sandbox_probe -> observe -> report     exploration_injection                0.063223 ready_for_closed_loop_rerun
               sensitivity_opening        response_opening    20            1.000000                  0.05               1.0                 1.0                  0.95                           0.05                    0.333333       diagnostic_sensitivity_opening           sensitivity_opening -> observe -> report           coupling_relief                0.267099 ready_for_closed_loop_rerun
             update_access_opening        temporal_opening    20            0.000000                  0.00               1.0                 1.0                  1.00                           0.00                    0.333333       diagnostic_update_access_probe           update_access_probe -> observe -> report         uncertainty_probe                0.189600 ready_for_closed_loop_rerun
             update_frequency_down        update_restraint    10            0.000000                  0.00               1.0                 1.0                  1.00                           0.00                    0.375000          diagnostic_update_restraint                        update_restraint -> observe           buffer_increase                0.061615 ready_for_closed_loop_rerun
               update_frequency_up          update_opening    10            0.000000                  0.00               1.0                 1.0                  1.00                           0.00                    0.041667            diagnostic_update_opening                update_opening -> observe -> report         uncertainty_probe                0.060855 ready_for_closed_loop_rerun
```

Every semantic effect is now ready for a diagnostic closed-loop rerun.

## 6. Next Closed-Loop Requirements

```text
                                       requirement                                                                                                                 reason                                                                              success_metric  priority
          rerun_closed_loop_with_diagnostic_policy New weak diagnostic actions were created after the original pseudo-reality trace; their outcomes are not yet observed.    outcome_pending_rate should become observed_existing_action_attribution_rate after rerun         1
preserve semantic trace ids through pseudo-reality                                         Outcome must be attributable to semantic_effect / diagnostic_action_primitive. each diagnostic action row carries semantic_effect, primitive, action_channel, and trace id         1
                   compare RC2 vs RC2b after rerun                                              Coverage is fixed now; alignment must be tested with actual new outcomes.                 semantic alignment pass rate under diagnostic rerun; not just coverage rate         2
                     do not tune DEPT pressure yet                                                   Coverage is fixed syntactically, but outcome attribution is pending.               DEPT tuning readiness remains false until diagnostic rerun confirms alignment         2
```

## 7. Correct Interpretation

RC2b confirms:

```text
1. RC2 sign-only issue remains fixed.
2. Diagnostic policy fixes semantic/action survival.
3. Every semantic effect now has weak diagnostic action coverage.
4. The system is ready for a diagnostic closed-loop rerun.
```

RC2b does not confirm:

```text
1. new diagnostic actions improved outcome
2. pressure-outcome alignment is now solved
3. DEPT pressure tuning is ready
```

## 8. Next Task

The natural next task is:

```text
DiagnosticClosedLoopRerun_RC1
```

Purpose:

```text
actually run pseudo-reality with the diagnostic action frame,
then measure semantic_effect / diagnostic_action / outcome alignment.
```

After that, if `coupling_relief -> staged_unlock` remains weak, proceed to:

```text
CouplingReliefStagedUnlockRepair_RC1
```
