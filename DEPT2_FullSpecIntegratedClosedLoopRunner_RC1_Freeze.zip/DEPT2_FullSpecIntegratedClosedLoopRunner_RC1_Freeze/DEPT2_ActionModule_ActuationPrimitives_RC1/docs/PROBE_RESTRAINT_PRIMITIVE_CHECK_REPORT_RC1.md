# Probe Restraint Primitive Check Report RC1

## 0. Position

This report records **ProbeRestraintPrimitiveCheck_RC1**.

It follows:

```text
ExpectedEffectContractPatch_RC1
```

The remaining ambiguity was:

```text
sandbox_probe_entry_down
```

The patched contract passes because the current action behaves like
buffer-style stabilization.  
This check asks whether that is enough, or whether a direct probe-restraint
primitive is needed.

## 1. Contract Basis

```text
         semantic_effect                      old_contract                        patched_contract                                                                             contract_issue                                            probe_check_contract
sandbox_probe_entry_down exploration:-1;overconvergence:+1 conflict:-1;m_overall:+1;uncertainty:-1 patched stabilization contract aligns, but direct probe-restraint expression was ambiguous ProbeRestraintPrimitiveCheck_RC1__old_vs_patched_contract_basis
```

## 2. Execution Summary

```json
{
  "task": "ProbeRestraintPrimitiveCheck_RC1",
  "status": "completed",
  "semantic_effect": "sandbox_probe_entry_down",
  "variant_count": 3,
  "variant_action_rows": 30,
  "alignment_rows": 30,
  "best_old_contract_variant": "hybrid_probe_restraint",
  "best_old_contract_score": 1.0,
  "best_patched_contract_variant": "current_buffer_style",
  "best_patched_contract_score": 1.0,
  "policy_recommendation": "add_direct_probe_restraint_primitive",
  "policy_reason": "direct variant expresses old sandbox/probe restraint semantics better than current buffer-style mapping",
  "decision": {
    "recommendation": "add_direct_probe_restraint_primitive",
    "reason": "direct variant expresses old sandbox/probe restraint semantics better than current buffer-style mapping",
    "priority": 1,
    "current_old_contract_score": 0.0,
    "direct_old_contract_score": 1.0,
    "hybrid_old_contract_score": 1.0,
    "current_patched_contract_score": 1.0,
    "direct_patched_contract_score": 0.0,
    "hybrid_patched_contract_score": 0.3333333333333333,
    "next_task_if_adopted": "ProbeRestraintPrimitivePatch_RC1"
  },
  "variant_summary": [
    {
      "probe_variant": "hybrid_probe_restraint",
      "rows": 10,
      "action_primitive": "diagnostic_probe_restraint_hybrid_v1",
      "action_channel": "diagnostic_probe_restraint_hybrid",
      "mean_action_mass": 0.006,
      "old_contract_pass_rate": 1.0,
      "old_contract_mean_score": 1.0,
      "patched_contract_pass_rate": 0.0,
      "patched_contract_mean_score": 0.3333333333333333,
      "mean_delta_conflict": 0.0,
      "mean_delta_uncertainty": -3.7499999999912604e-06,
      "mean_delta_exploration": -1.1249999999984883e-05,
      "mean_delta_overconvergence": 9.37499999999411e-06,
      "mean_delta_m_overall": -1.1999999999989797e-05
    },
    {
      "probe_variant": "direct_probe_restraint",
      "rows": 10,
      "action_primitive": "diagnostic_probe_restraint_direct_v1",
      "action_channel": "diagnostic_probe_restraint_direct",
      "mean_action_mass": 0.006,
      "old_contract_pass_rate": 1.0,
      "old_contract_mean_score": 1.0,
      "patched_contract_pass_rate": 0.0,
      "patched_contract_mean_score": 0.0,
      "mean_delta_conflict": 2.0624999999996342e-06,
      "mean_delta_uncertainty": 1.4999999999931734e-06,
      "mean_delta_exploration": -1.4999999999992797e-05,
      "mean_delta_overconvergence": 1.349999999999546e-05,
      "mean_delta_m_overall": -2.231250000005458e-05
    },
    {
      "probe_variant": "current_buffer_style",
      "rows": 10,
      "action_primitive": "diagnostic_probe_restraint",
      "action_channel": "buffer_increase",
      "mean_action_mass": 0.006,
      "old_contract_pass_rate": 0.0,
      "old_contract_mean_score": 0.0,
      "patched_contract_pass_rate": 1.0,
      "patched_contract_mean_score": 1.0,
      "mean_delta_conflict": -1.5000000000264802e-06,
      "mean_delta_uncertainty": -2.249999999998087e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 1.6500000000019276e-05
    }
  ],
  "primary_conclusion": "Probe-restraint ambiguity is resolved by comparing buffer-style, direct, and hybrid variants against old and patched contracts.",
  "dept_pressure_tuning_readiness": "not_ready_sequence_repair_still_required",
  "next_recommended_task": "ProbeRestraintPrimitivePatch_RC1",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/probe_restraint_primitive_check_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "probe_restraint_variant_action_frame": "probe_restraint_variant_action_frame_RC1.csv",
    "probe_restraint_variant_alignment": "probe_restraint_variant_alignment_RC1.csv",
    "probe_restraint_variant_summary": "probe_restraint_variant_summary_RC1.csv",
    "probe_restraint_contract_basis": "probe_restraint_contract_basis_RC1.csv",
    "probe_restraint_policy_decision": "probe_restraint_policy_decision_RC1.csv"
  }
}
```

Focused test status:

```text
test_probe_restraint_primitive_check.py: 3 passed
```

## 3. Variant Summary

```text
         probe_variant  rows                     action_primitive                    action_channel  mean_action_mass  old_contract_pass_rate  old_contract_mean_score  patched_contract_pass_rate  patched_contract_mean_score  mean_delta_conflict  mean_delta_uncertainty  mean_delta_exploration  mean_delta_overconvergence  mean_delta_m_overall
hybrid_probe_restraint    10 diagnostic_probe_restraint_hybrid_v1 diagnostic_probe_restraint_hybrid             0.006                     1.0                      1.0                         0.0                     0.333333             0.000000               -0.000004               -0.000011                    0.000009             -0.000012
direct_probe_restraint    10 diagnostic_probe_restraint_direct_v1 diagnostic_probe_restraint_direct             0.006                     1.0                      1.0                         0.0                     0.000000             0.000002                0.000001               -0.000015                    0.000013             -0.000022
  current_buffer_style    10           diagnostic_probe_restraint                   buffer_increase             0.006                     0.0                      0.0                         1.0                     1.000000            -0.000002               -0.000002                0.000000                    0.000000              0.000017
```

## 4. Interpretation

Three variants were compared:

```text
current_buffer_style:
  current diagnostic_probe_restraint / buffer_increase

direct_probe_restraint:
  direct diagnostic_probe_restraint_direct_v1

hybrid_probe_restraint:
  stabilizing + direct probe restraint compromise
```

Result:

```text
old probe-restraint contract:
  direct_probe_restraint and hybrid_probe_restraint pass

patched stabilization contract:
  current_buffer_style passes
```

So the ambiguity is real.

The current buffer-style mapping is valid as a stabilization behavior, but it
does not express the old sandbox/probe restraint semantics.

## 5. Policy Decision

```text
                      recommendation                                                                                                  reason  priority  current_old_contract_score  direct_old_contract_score  hybrid_old_contract_score  current_patched_contract_score  direct_patched_contract_score  hybrid_patched_contract_score             next_task_if_adopted
add_direct_probe_restraint_primitive direct variant expresses old sandbox/probe restraint semantics better than current buffer-style mapping         1                         0.0                        1.0                        1.0                             1.0                            0.0                       0.333333 ProbeRestraintPrimitivePatch_RC1
```

Recommended decision:

```text
add_direct_probe_restraint_primitive
```

Reason:

```text
direct variant expresses old sandbox/probe restraint semantics better than current buffer-style mapping
```

## 6. Boundary

This task does not mean H-DEPT pressure tuning is ready.

It only says:

```text
sandbox_probe_entry_down should not be represented only by buffer_increase
if we want direct probe-restraint semantics.
```

## 7. Next Recommended Task

```text
ProbeRestraintPrimitivePatch_RC1
```

Purpose:

```text
Add a direct probe-restraint primitive/channel for sandbox_probe_entry_down,
while retaining buffer-style stabilization as a separate contract/behavior.
```

After that, proceed to:

```text
CouplingReliefStagedUnlockRepair_RC1
```
