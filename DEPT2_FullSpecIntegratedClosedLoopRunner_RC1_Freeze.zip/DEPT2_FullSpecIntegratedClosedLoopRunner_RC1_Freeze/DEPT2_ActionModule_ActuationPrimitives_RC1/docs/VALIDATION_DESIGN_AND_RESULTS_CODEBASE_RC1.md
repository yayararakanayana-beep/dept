# VALIDATION_DESIGN_AND_RESULTS_CODEBASE_RC1

## Positioning

RC1 freezes a separated execution baseline for future closed-loop validation.

The objective is not to prove performance. The objective is to make the next experiments clean:

- pseudo reality can be changed independently.
- action module can be changed independently.
- DEPT2/H-DEPT integrated system has a stable reference implementation.
- H-DEPT formal input remains G_t/K_t_global only.

## Execution

Command:

```bash
python runner/run_closed_loop_codebase_rc1.py --steps 30 --seeds 42,43 --scenarios normal,exploration_loss,relation_lock,shock --out results
```

## Outputs

- `gt_global_RC1.csv`
- `kt_global_RC1.csv`
- `formal_gtkt_packets_RC1.csv`
- `m_observation_RC1.csv`
- `pressure_candidates_RC1.csv`
- `h11_local_pressure_field_RC1.csv`
- `parameter_registry_RC1.csv`
- `parameter_updates_RC1.csv`
- `graph_objects_audit_RC1.csv`
- `action_surface_candidates_RC1.csv`
- `v8_support_audit_RC1.csv`
- `final_gate_audit_RC1.csv`
- `action_module_frames_RC1.csv`
- `closed_loop_metrics_RC1.csv`
- `scenario_delta_summary_RC1.csv`
- `validation_summary.json`

## Sanity checks

| Check | Result |
|---|---:|
| Formal input has no lower-side leakage | True |
| Formal packets | 240 |
| H11 pressure field rows | 29040 |
| ActionSurface rows | 6442 |
| Final gate rows | 6442 |
| Parameter registry rows | 12 |
| Max theta delta within registry | True |
| All sanity checks passed | True |

## Observed baseline behavior

| Metric | Value |
|---|---:|
| Mean start conflict | 0.322269 |
| Mean end conflict | 0.418607 |
| Mean conflict delta | 0.096338 |
| Max abs theta delta | 0.025000 |

Conflict increased in this baseline smoke run. This is useful rather than embarrassing: it indicates that the pseudo reality/action module/parameter pseudo-functions are not tuned yet. RC1 exposes the work area for the next validation phase.

## Interpretation

RC1 passes as a **codebase separation and contract validation**.
It does not pass or fail as a performance validation, because that was not the objective.

## Next recommended experiments

1. Create alternative pseudo reality scenarios.
2. Vary action module mapping and gains.
3. Compare fixed lower parameters vs parameter governance box.
4. Add ablation modes: no v8, no parameter box, no H11-local high-fidelity reception.
5. Only after the system stops behaving arbitrarily, move to more serious performance comparison.
