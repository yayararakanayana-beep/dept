# Pressure Outcome Alignment Audit Report RC2

## 0. Position

This report records **PressureOutcomeAlignmentAudit_RC2**.

RC1 compared:

```text
approved pressure sign
vs
observed outcome
```

RC2 corrects that by making the primary comparison:

```text
semantic_effect
vs
observed outcome
```

and:

```text
primitive / sequence
vs
observed outcome
```

The approved pressure sign is retained only as a secondary diagnostic signal.

## 1. Execution Summary

```json
{
  "task": "PressureOutcomeAlignmentAudit_RC2",
  "status": "completed",
  "semantic_primary_rows": 176,
  "primitive_primary_rows": 19,
  "semantic_alignment_rate": 0.4147727272727273,
  "semantic_mean_alignment_score": 0.35700757575757575,
  "semantic_to_plan_present_rate": 0.2840909090909091,
  "plan_to_action_present_rate": 0.09090909090909091,
  "primitive_alignment_rate": 0.42105263157894735,
  "primitive_mean_alignment_score": 0.42105263157894735,
  "chain_coverage_rows": 4,
  "weakest_semantic_effects": [
    {
      "semantic_effect": "sandbox_probe_entry_up",
      "intent_family": "exploration_observation",
      "rows": 8,
      "mean_alignment_score": 0.041666666666666664,
      "alignment_pass_rate": 0.0,
      "semantic_to_plan_present_rate": 0.0,
      "plan_to_action_present_rate": 0.0,
      "mean_action_mass": 0.0,
      "dominant_verdict": "semantic_misaligned_not_planned"
    },
    {
      "semantic_effect": "update_frequency_up",
      "intent_family": "update_opening",
      "rows": 8,
      "mean_alignment_score": 0.041666666666666664,
      "alignment_pass_rate": 0.0,
      "semantic_to_plan_present_rate": 0.0,
      "plan_to_action_present_rate": 0.0,
      "mean_action_mass": 0.0,
      "dominant_verdict": "semantic_misaligned_not_planned"
    },
    {
      "semantic_effect": "update_frequency_down",
      "intent_family": "update_restraint",
      "rows": 8,
      "mean_alignment_score": 0.375,
      "alignment_pass_rate": 0.125,
      "semantic_to_plan_present_rate": 0.0,
      "plan_to_action_present_rate": 0.0,
      "mean_action_mass": 0.0,
      "dominant_verdict": "semantic_misaligned_not_planned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_down",
      "intent_family": "exploration_restraint",
      "rows": 4,
      "mean_alignment_score": 0.41666666666666663,
      "alignment_pass_rate": 0.25,
      "semantic_to_plan_present_rate": 0.0,
      "plan_to_action_present_rate": 0.0,
      "mean_action_mass": 0.0,
      "dominant_verdict": "semantic_misaligned_not_planned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_up",
      "intent_family": "exploration_attempt",
      "rows": 12,
      "mean_alignment_score": 0.25,
      "alignment_pass_rate": 0.3333333333333333,
      "semantic_to_plan_present_rate": 0.25,
      "plan_to_action_present_rate": 0.0,
      "mean_action_mass": 0.0,
      "dominant_verdict": "semantic_misaligned_not_planned"
    },
    {
      "semantic_effect": "sandbox_probe_entry_down",
      "intent_family": "probe_restraint",
      "rows": 8,
      "mean_alignment_score": 0.1875,
      "alignment_pass_rate": 0.375,
      "semantic_to_plan_present_rate": 0.0,
      "plan_to_action_present_rate": 0.0,
      "mean_action_mass": 0.0,
      "dominant_verdict": "semantic_misaligned_not_planned"
    },
    {
      "semantic_effect": "update_access_opening",
      "intent_family": "temporal_opening",
      "rows": 16,
      "mean_alignment_score": 0.3333333333333333,
      "alignment_pass_rate": 0.4375,
      "semantic_to_plan_present_rate": 0.0,
      "plan_to_action_present_rate": 0.0,
      "mean_action_mass": 0.0,
      "dominant_verdict": "semantic_misaligned_not_planned"
    },
    {
      "semantic_effect": "adoption_barrier_relief",
      "intent_family": "adoption_opening",
      "rows": 16,
      "mean_alignment_score": 0.3333333333333333,
      "alignment_pass_rate": 0.4375,
      "semantic_to_plan_present_rate": 0.0625,
      "plan_to_action_present_rate": 0.0625,
      "mean_action_mass": 0.05157583303445023,
      "dominant_verdict": "semantic_misaligned_not_planned"
    }
  ],
  "weakest_primitives": [
    {
      "action_primitive": "coupling_relief_first",
      "primitive_sequence": "coupling_relief -> staged_unlock",
      "action_channel": "coupling_relief",
      "rows": 4,
      "mean_alignment_score": 0.08333333333333333,
      "alignment_pass_rate": 0.0,
      "total_action_rows": 15,
      "total_action_mass": 1.4174488801214489,
      "dominant_verdict": "primitive_misaligned_despite_action"
    },
    {
      "action_primitive": "buffer_first",
      "primitive_sequence": "buffer -> coupling_relief -> staged_unlock",
      "action_channel": "buffer_increase",
      "rows": 3,
      "mean_alignment_score": 0.4444444444444444,
      "alignment_pass_rate": 0.3333333333333333,
      "total_action_rows": 4,
      "total_action_mass": 0.45020115478385203,
      "dominant_verdict": "primitive_misaligned_despite_action"
    },
    {
      "action_primitive": "coupling_relief_first",
      "primitive_sequence": "coupling_relief -> observe",
      "action_channel": "coupling_relief",
      "rows": 8,
      "mean_alignment_score": 0.5,
      "alignment_pass_rate": 0.5,
      "total_action_rows": 92,
      "total_action_mass": 12.612325196508923,
      "dominant_verdict": "primitive_misaligned_despite_action"
    },
    {
      "action_primitive": "buffer_first",
      "primitive_sequence": "buffer -> replan",
      "action_channel": "buffer_increase",
      "rows": 4,
      "mean_alignment_score": 0.5833333333333333,
      "alignment_pass_rate": 0.75,
      "total_action_rows": 37,
      "total_action_mass": 4.208476597486328,
      "dominant_verdict": "primitive_aligned_and_actuated"
    }
  ],
  "review_items": [
    {
      "review_item": "semantic_primary_alignment",
      "value": 0.4147727272727273,
      "interpretation": "semantic effect vs outcome pass rate",
      "rc2_status": "mixed"
    },
    {
      "review_item": "semantic_to_plan_coverage",
      "value": 0.2840909090909091,
      "interpretation": "share of semantic effects that survive into planning",
      "rc2_status": "coverage_bottleneck"
    },
    {
      "review_item": "plan_to_action_coverage",
      "value": 0.09090909090909091,
      "interpretation": "share of semantic effects that survive to actual action",
      "rc2_status": "major_action_bottleneck"
    },
    {
      "review_item": "primitive_primary_alignment",
      "value": 0.42105263157894735,
      "interpretation": "actuated primitive/sequence vs outcome pass rate",
      "rc2_status": "mixed"
    }
  ],
  "dept_pressure_tuning_readiness": "not_ready_action_coverage_bottleneck",
  "primary_alignment_basis": "semantic_effect_and_primitive_sequence",
  "secondary_diagnostic_basis": "approved_pressure_sign_only_for_sign_semantics_not_direct_outcome",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/pressure_outcome_alignment_rc2_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "pressure_outcome_alignment_rc2_semantic_primary": "pressure_outcome_alignment_rc2_semantic_primary.csv",
    "pressure_outcome_alignment_rc2_primitive_primary": "pressure_outcome_alignment_rc2_primitive_primary.csv",
    "pressure_outcome_alignment_rc2_chain_coverage": "pressure_outcome_alignment_rc2_chain_coverage.csv",
    "pressure_outcome_alignment_rc2_semantic_summary": "pressure_outcome_alignment_rc2_semantic_summary.csv",
    "pressure_outcome_alignment_rc2_primitive_summary": "pressure_outcome_alignment_rc2_primitive_summary.csv",
    "pressure_outcome_alignment_rc2_review": "pressure_outcome_alignment_rc2_review.csv"
  }
}
```

Focused Task test status:

```text
test_pressure_outcome_alignment_audit_rc2.py: 3 passed
```

## 2. Main Result

RC2 confirms the core diagnosis from Task A.

```text
semantic_alignment_rate = 0.414773
semantic_mean_alignment_score = 0.357008
semantic_to_plan_present_rate = 0.284091
plan_to_action_present_rate = 0.090909
primitive_alignment_rate = 0.421053
primitive_mean_alignment_score = 0.421053
```

Interpretation:

```text
pressure sign -> semantic_effect:
  no longer treated as direct outcome direction

semantic_effect -> outcome:
  mixed

semantic_effect -> actual action:
  major bottleneck

primitive / sequence -> outcome:
  mixed
```

Therefore DEPT-side pressure tuning is still premature.

## 3. Tuning Readiness

```text
dept_pressure_tuning_readiness = not_ready_action_coverage_bottleneck
```

Reason:

```text
Only 0.091 of semantic effects survive into actual action.
```

So the current bottleneck is not primarily pressure generation.  
It is semantic-effect survival and primitive/action outcome calibration.

## 4. Semantic Summary

```text
                   semantic_effect           intent_family  rows  mean_alignment_score  alignment_pass_rate  semantic_to_plan_present_rate  plan_to_action_present_rate  mean_action_mass                         dominant_verdict
            sandbox_probe_entry_up exploration_observation     8              0.041667             0.000000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned
               update_frequency_up          update_opening     8              0.041667             0.000000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned
             update_frequency_down        update_restraint     8              0.375000             0.125000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned
exploration_attempt_frequency_down   exploration_restraint     4              0.416667             0.250000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned
  exploration_attempt_frequency_up     exploration_attempt    12              0.250000             0.333333                         0.2500                       0.0000          0.000000          semantic_misaligned_not_planned
          sandbox_probe_entry_down         probe_restraint     8              0.187500             0.375000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned
             update_access_opening        temporal_opening    16              0.333333             0.437500                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned
           adoption_barrier_relief        adoption_opening    16              0.333333             0.437500                         0.0625                       0.0625          0.051576          semantic_misaligned_not_planned
               sensitivity_opening        response_opening    16              0.333333             0.437500                         1.0000                       0.0625          0.005435 semantic_misaligned_planned_not_actuated
             hysteresis_guard_down   switching_flexibility    16              0.416667             0.437500                         0.8125                       0.8125          1.095464       semantic_misaligned_despite_action
        diagnostic_resolution_down observation_cost_saving    16              0.416667             0.500000                         0.0000                       0.0000          0.000000        semantic_aligned_but_unattributed
               rollback_guard_down       safety_relaxation    16              0.416667             0.500000                         0.0000                       0.0000          0.000000        semantic_aligned_but_unattributed
          commitment_strength_down       commitment_relief    16              0.458333             0.500000                         0.0625                       0.0625          0.015553        semantic_aligned_but_unattributed
               intensity_cap_brake              safety_cap    16              0.604167             0.750000                         1.0000                       0.0000          0.000000    semantic_aligned_planned_not_actuated
```

Weakest semantic effects:

```text
sandbox_probe_entry_up
update_frequency_up
update_frequency_down
exploration_attempt_frequency_down
exploration_attempt_frequency_up
sandbox_probe_entry_down
update_access_opening
adoption_barrier_relief
```

The pattern is clear:

```text
exploration / sandbox / update opening effects are weak or not actuated enough.
```

## 5. Primitive Summary

```text
     action_primitive                         primitive_sequence  action_channel  rows  mean_alignment_score  alignment_pass_rate  total_action_rows  total_action_mass                    dominant_verdict
coupling_relief_first           coupling_relief -> staged_unlock coupling_relief     4              0.083333             0.000000                 15           1.417449 primitive_misaligned_despite_action
         buffer_first buffer -> coupling_relief -> staged_unlock buffer_increase     3              0.444444             0.333333                  4           0.450201 primitive_misaligned_despite_action
coupling_relief_first                 coupling_relief -> observe coupling_relief     8              0.500000             0.500000                 92          12.612325 primitive_misaligned_despite_action
         buffer_first                           buffer -> replan buffer_increase     4              0.583333             0.750000                 37           4.208477      primitive_aligned_and_actuated
```

Current primitive coverage is still narrow:

```text
buffer_first
coupling_relief_first
```

This means RC2 cannot yet judge all primitive families equally.  
The next validation should use logs from the broader ActionModuleExecutionPolicy_RC2 path
or rerun the audit on a richer closed-loop trace.

## 6. Chain Coverage

```text
    run_scenario  semantic_chain_rows  unique_semantic_effects  semantic_to_plan_present_rate  plan_to_action_present_rate  total_planned_rows  total_action_rows  total_action_mass
exploration_loss                   76                       11                       0.526316                     0.065789               540.0               30.0           2.979848
          normal                   75                       11                       0.466667                     0.066667               540.0               90.0          13.523000
   relation_lock                   90                       11                       0.555556                     0.100000               540.0               30.0           3.069489
           shock                   65                       11                       0.384615                     0.076923               540.0               51.0           5.674122
```

Key bottleneck:

```text
semantic_to_plan_present_rate ≈ 0.284
plan_to_action_present_rate ≈ 0.091
```

So many semantic effects exist, but most do not survive to real action.

## 7. Review

```text
                review_item    value                                          interpretation              rc2_status
 semantic_primary_alignment 0.414773                    semantic effect vs outcome pass rate                   mixed
  semantic_to_plan_coverage 0.284091    share of semantic effects that survive into planning     coverage_bottleneck
    plan_to_action_coverage 0.090909 share of semantic effects that survive to actual action major_action_bottleneck
primitive_primary_alignment 0.421053        actuated primitive/sequence vs outcome pass rate                   mixed
```

## 8. Meaning

This is now much clearer than RC1:

```text
RC1:
  pressure sign vs outcome looked inverted

Task A:
  pressure sign -> semantic_effect was valid

RC2:
  semantic_effect -> plan/action/outcome is the real bottleneck
```

Therefore the proper correction is not:

```text
change DEPT pressure generation
```

but:

```text
improve semantic-effect survival into action
calibrate primitive expected outcomes
rerun alignment on richer RC2 closed-loop logs
```

## 9. Recommended Next Task

Recommended next task:

```text
SemanticEffectActionSurvivalAudit_RC1
```

Purpose:

```text
Identify which semantic_effects are repeatedly dropped,
why they fail to reach action,
and whether the loss is due to planner selection, final gate, execution policy,
primitive availability, or weak action coupling.
```

Alternative:

```text
PressureOutcomeAlignmentAudit_RC2b
```

using richer logs from the ActionModuleExecutionPolicy_RC2 / ClosedLoopTranslationValidation_RC1
path, if those files are reattached or restored in the same package.
