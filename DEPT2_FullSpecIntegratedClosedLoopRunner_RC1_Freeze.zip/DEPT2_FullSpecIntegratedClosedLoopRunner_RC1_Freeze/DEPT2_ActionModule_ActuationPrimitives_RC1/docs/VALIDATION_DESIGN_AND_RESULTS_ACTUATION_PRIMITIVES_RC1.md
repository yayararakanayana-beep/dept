# Validation Design and Results: ActionModule Actuation Primitives RC1

## 1. Purpose

The purpose of this RC1 is to test whether an environment-specific actuation primitive layer can reduce the crudeness of the previous action module.

The previous non-compressed pressure translation fixed an earlier problem: upper pressure was no longer prematurely collapsed before the action module. However, the action module still mapped planned routes too directly into action channels. This made it hard to distinguish between:

- bad route choice
- bad actuation method
- bad timing
- bad scope
- bad strength

This package introduces primitive-level actuation.

## 2. Validation scope

This is a 5-step smoke/stress validation against the same pseudo reality environment.

Scenarios:

- normal
- exploration_loss
- relation_lock
- shock

Seed:

- 42

This is intentionally not a performance proof.

## 3. Sanity checks

All sanity checks passed.

- Formal H-DEPT input contains no lower artifact leakage.
- Pressure intent annotation remains non-compressive.
- ActionSurface still has no pressure-compression columns.
- ActionPlanner remains the first compression point.
- Primitive library exists and is used.
- Multiple primitives and sequences appear in planned actions.
- exploration_loss still produces planned and actuated actions.

## 4. Main results

Compared with the previous non-compressed translation RC1 over the same 5-step smoke condition:

| Scenario | Baseline conflict delta | Primitive conflict delta | Change |
|---|---:|---:|---:|
| exploration_loss | +0.008208 | +0.007257 | -0.000951 |
| normal | -0.003733 | -0.009331 | -0.005598 |
| relation_lock | +0.025403 | +0.025604 | +0.000201 |
| shock | +0.008400 | +0.003085 | -0.005316 |

Interpretation:

- The primitive layer improves or slightly improves normal, shock, and exploration_loss in this short smoke test.
- relation_lock is not materially improved yet.
- This suggests relation_lock needs a deeper stateful staged mechanism, not only primitive substitution.

## 5. Actuated primitives

Actually actuated primitive mass concentrated as follows:

- normal: coupling_relief_first
- exploration_loss: coupling_relief_first
- relation_lock: coupling_relief_first + buffer_first
- shock: buffer_first

This confirms that the module no longer blindly injects exploration into locked or shocked states.

## 6. Important limitation

The current pseudo reality system consumes only a simple action frame:

```text
entity_id, action_channel, action_strength, direction
```

Therefore the primitive layer is represented through safer substitutions and metadata, but not yet through full multi-step scheduled actions. For example, `buffer -> coupling_relief -> staged_unlock` is described in the action frame metadata, but the next-step scheduler is not yet fully implemented.

## 7. Conclusion

ActionModule_ActuationPrimitives_RC1 is valid as a structural improvement.

It establishes that:

- action methods should not be a direct route-to-channel mapping;
- relation_lock and shock require different actuation shapes;
- relation_lock remains the hardest case;
- the next step should add a stateful primitive scheduler/rollback monitor for staged actions.
