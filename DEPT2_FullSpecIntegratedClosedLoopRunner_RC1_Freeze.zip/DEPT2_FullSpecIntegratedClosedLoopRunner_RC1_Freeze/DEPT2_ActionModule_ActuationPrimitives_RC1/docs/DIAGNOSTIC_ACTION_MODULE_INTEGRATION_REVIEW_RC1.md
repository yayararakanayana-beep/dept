# Diagnostic Action Module Integration Review RC1

## 0. Position

`DiagnosticActionModuleIntegrationReview_RC1` reviews the validation action
module after the repair chain:

```text
DiagnosticActionTranslationPolicy_RC1
PressureOutcomeAlignmentAudit_RC2b
DiagnosticClosedLoopRerun_RC1
DiagnosticPrimitiveMappingRepair_RC1
ExpectedEffectContractPatch_RC1
ProbeRestraintPrimitivePatch_RC1
CouplingReliefStagedUnlockRepair_RC1
```

## 1. Scope

This is an integration review, not a new repair.

It checks:

```text
coverage
action delivery
primitive mapping
expected-effect contracts
probe-restraint role split
staged unlock sequence repair
readiness for integrated diagnostic closed-loop
```

## 2. Boundary

This task does not:

```text
- tune H-DEPT pressure
- claim deployment safety
- change the upper DEPT/H-DEPT input contract
```

## 3. Outputs

```text
results/diagnostic_action_module_integration_milestones_RC1.csv
results/diagnostic_action_module_integration_metrics_RC1.csv
results/diagnostic_action_module_integration_readiness_RC1.csv
results/diagnostic_action_module_integration_risks_RC1.csv
results/diagnostic_action_module_integration_next_plan_RC1.csv
results/diagnostic_action_module_integration_review_summary_RC1.json
```
