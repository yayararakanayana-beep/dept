# Diagnostic Closed Loop Rerun Report RC1

## 0. Position

This report records **DiagnosticClosedLoopRerun_RC1**.

It follows:

```text
DiagnosticActionTranslationPolicy_RC1
PressureOutcomeAlignmentAudit_RC2b
```

RC2b showed:

```text
coverage fixed
outcome attribution pending
```

This task performs the missing step:

```text
weak diagnostic actions
→ pseudo-reality
→ observed outcome
```

## 1. Execution Summary

```json
{
  "task": "DiagnosticClosedLoopRerun_RC1",
  "status": "completed",
  "combined_trace_rows": 20,
  "applied_action_rows": 220,
  "isolated_alignment_rows": 220,
  "semantic_effect_count": 14,
  "scenario_count": 4,
  "mean_isolated_alignment_score": 0.5606060606060606,
  "isolated_alignment_pass_rate": 0.6136363636363636,
  "mean_isolated_action_mass": 0.008581253637300543,
  "combined_mean_delta_conflict": -8.431601654194376e-05,
  "combined_mean_delta_uncertainty": -8.673612454528079e-05,
  "combined_mean_delta_exploration": 0.00023424795641133062,
  "combined_mean_delta_m_overall": 0.0005939086876483868,
  "semantic_summary": [
    {
      "semantic_effect": "diagnostic_resolution_down",
      "intent_family": "observation_cost_saving",
      "rows": 20,
      "mean_alignment_score": 0.0,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.009178818238124598,
      "action_primitives": "diagnostic_observation_saving_probe",
      "action_channels": "uncertainty_probe",
      "mean_delta_conflict": -3.1552187693628665e-06,
      "mean_delta_uncertainty": -1.2620875077432037e-05,
      "mean_delta_exploration": 4.5894091190601395e-06,
      "mean_delta_overconvergence": -2.2947045595359677e-06,
      "mean_delta_m_overall": 7.744627888428556e-06,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "rollback_guard_down",
      "intent_family": "safety_relaxation",
      "rows": 20,
      "mean_alignment_score": 0.0,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.00923468642738151,
      "action_primitives": "diagnostic_rollback_relaxation_probe",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -2.3086716068515533e-06,
      "mean_delta_uncertainty": -3.4630074102759423e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 2.5395387675297697e-05,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "sandbox_probe_entry_down",
      "intent_family": "probe_restraint",
      "rows": 10,
      "mean_alignment_score": 0.0,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.006,
      "action_primitives": "diagnostic_probe_restraint",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -1.5000000000264802e-06,
      "mean_delta_uncertainty": -2.249999999998087e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 1.6500000000019276e-05,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_down",
      "intent_family": "exploration_restraint",
      "rows": 5,
      "mean_alignment_score": 0.3333333333333333,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.006,
      "action_primitives": "diagnostic_exploration_restraint",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -1.500000000020929e-06,
      "mean_delta_uncertainty": -2.25000000001474e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 1.6500000000041482e-05,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "sensitivity_opening",
      "intent_family": "response_opening",
      "rows": 20,
      "mean_alignment_score": 0.3333333333333333,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.009456811823750324,
      "action_primitives": "diagnostic_sensitivity_opening",
      "action_channels": "coupling_relief",
      "mean_delta_conflict": -8.570235715293917e-06,
      "mean_delta_uncertainty": 0.0,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -1.7140471430559732e-05,
      "mean_delta_m_overall": 8.570235715299468e-06,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "update_frequency_down",
      "intent_family": "update_restraint",
      "rows": 10,
      "mean_alignment_score": 0.3333333333333333,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.00616145947450928,
      "action_primitives": "diagnostic_update_restraint",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -1.5403648686518335e-06,
      "mean_delta_uncertainty": -2.3105473029416677e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 1.694401355494257e-05,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "hysteresis_guard_down",
      "intent_family": "switching_flexibility",
      "rows": 20,
      "mean_alignment_score": 0.6666666666666666,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.009363586398186593,
      "action_primitives": "diagnostic_switching_flexibility",
      "action_channels": "coupling_relief",
      "mean_delta_conflict": -8.485750173370388e-06,
      "mean_delta_uncertainty": 0.0,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -1.697150034671753e-05,
      "mean_delta_m_overall": 8.48575017337594e-06,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "intensity_cap_brake",
      "intent_family": "safety_cap",
      "rows": 20,
      "mean_alignment_score": 0.6666666666666666,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.009479999999999999,
      "action_primitives": "buffer_first",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -2.3700000000098643e-06,
      "mean_delta_uncertainty": -3.5550000000078573e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 2.607000000000581e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "update_access_opening",
      "intent_family": "temporal_opening",
      "rows": 20,
      "mean_alignment_score": 0.6666666666666666,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.009479999999999999,
      "action_primitives": "diagnostic_update_access_probe",
      "action_channels": "uncertainty_probe",
      "mean_delta_conflict": -3.258750000015298e-06,
      "mean_delta_uncertainty": -1.303500000001956e-05,
      "mean_delta_exploration": 4.7399999999933605e-06,
      "mean_delta_overconvergence": -2.3700000000022313e-06,
      "mean_delta_m_overall": 7.998750000004495e-06,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "update_frequency_up",
      "intent_family": "update_opening",
      "rows": 10,
      "mean_alignment_score": 0.6666666666666666,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.0060854503044042805,
      "action_primitives": "diagnostic_update_opening",
      "action_channels": "uncertainty_probe",
      "mean_delta_conflict": -2.0918735421648904e-06,
      "mean_delta_uncertainty": -8.367494168570743e-06,
      "mean_delta_exploration": 3.04272515219417e-06,
      "mean_delta_overconvergence": -1.5213625761234529e-06,
      "mean_delta_m_overall": 5.1345986943562846e-06,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "adoption_barrier_relief",
      "intent_family": "adoption_opening",
      "rows": 20,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.009479999999999999,
      "action_primitives": "diagnostic_adoption_opening_probe",
      "action_channels": "exploration_injection",
      "mean_delta_conflict": 8.887499999721271e-07,
      "mean_delta_uncertainty": 3.5549999999967553e-06,
      "mean_delta_exploration": 2.3700000000002887e-05,
      "mean_delta_overconvergence": -1.6590000000003824e-05,
      "mean_delta_m_overall": 3.2291250000038296e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "commitment_strength_down",
      "intent_family": "commitment_relief",
      "rows": 20,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.00938791570368957,
      "action_primitives": "diagnostic_commitment_relief_probe",
      "action_channels": "exploration_injection",
      "mean_delta_conflict": 8.801170971906025e-07,
      "mean_delta_uncertainty": 3.520468388876208e-06,
      "mean_delta_exploration": 2.346978925922144e-05,
      "mean_delta_overconvergence": -1.642885248146139e-05,
      "mean_delta_m_overall": 3.1977587865728016e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_up",
      "intent_family": "exploration_attempt",
      "rows": 15,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.007396488031293213,
      "action_primitives": "diagnostic_exploration_attempt",
      "action_channels": "exploration_injection",
      "mean_delta_conflict": 6.934207528989471e-07,
      "mean_delta_uncertainty": 2.773683011714212e-06,
      "mean_delta_exploration": 1.8491220078239076e-05,
      "mean_delta_overconvergence": -1.2943854054774569e-05,
      "mean_delta_m_overall": 2.5194287356596532e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "sandbox_probe_entry_up",
      "intent_family": "exploration_observation",
      "rows": 10,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.006322301012493391,
      "action_primitives": "diagnostic_sandbox_probe",
      "action_channels": "exploration_injection",
      "mean_delta_conflict": 5.927157199048239e-07,
      "mean_delta_uncertainty": 2.3708628796637043e-06,
      "mean_delta_exploration": 1.580575253121441e-05,
      "mean_delta_overconvergence": -1.1064026771867574e-05,
      "mean_delta_m_overall": 2.1535337823808122e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    }
  ],
  "scenario_summary": [
    {
      "run_scenario": "exploration_loss",
      "combined_steps": 5,
      "combined_mean_action_mass": 0.09689126573067638,
      "combined_mean_delta_conflict": -8.06216767245127e-05,
      "combined_mean_delta_uncertainty": -8.400135466096748e-05,
      "combined_mean_delta_exploration": 0.0002862415092779125,
      "combined_mean_delta_m_overall": 0.000605760514310072,
      "isolated_rows": 55,
      "isolated_alignment_pass_rate": 0.7272727272727273,
      "isolated_mean_alignment_score": 0.6363636363636364,
      "isolated_mean_action_mass": 0.008808296884606945
    },
    {
      "run_scenario": "normal",
      "combined_steps": 5,
      "combined_mean_action_mass": 0.09406282968714315,
      "combined_mean_delta_conflict": -9.274019760389108e-05,
      "combined_mean_delta_uncertainty": -9.726147535873419e-05,
      "combined_mean_delta_exploration": 0.00016894977684532851,
      "combined_mean_delta_m_overall": 0.0005950872346767166,
      "isolated_rows": 55,
      "isolated_alignment_pass_rate": 0.45454545454545453,
      "isolated_mean_alignment_score": 0.45454545454545453,
      "isolated_mean_action_mass": 0.008551166335194833
    },
    {
      "run_scenario": "relation_lock",
      "combined_steps": 5,
      "combined_mean_action_mass": 0.0939268064154752,
      "combined_mean_delta_conflict": -7.934061531735814e-05,
      "combined_mean_delta_uncertainty": -8.440885278218068e-05,
      "combined_mean_delta_exploration": 0.0002703354325845453,
      "combined_mean_delta_m_overall": 0.000579309995654076,
      "isolated_rows": 55,
      "isolated_alignment_pass_rate": 0.7272727272727273,
      "isolated_mean_alignment_score": 0.6363636363636364,
      "isolated_mean_action_mass": 0.008538800583225018
    },
    {
      "run_scenario": "shock",
      "combined_steps": 5,
      "combined_mean_action_mass": 0.09269425820792918,
      "combined_mean_delta_conflict": -8.456157652201313e-05,
      "combined_mean_delta_uncertainty": -8.12728153792408e-05,
      "combined_mean_delta_exploration": 0.00021146510693753617,
      "combined_mean_delta_m_overall": 0.0005954770059526826,
      "isolated_rows": 55,
      "isolated_alignment_pass_rate": 0.5454545454545454,
      "isolated_mean_alignment_score": 0.5151515151515151,
      "isolated_mean_action_mass": 0.008426750746175379
    }
  ],
  "weakest_semantic_effects": [
    {
      "semantic_effect": "diagnostic_resolution_down",
      "intent_family": "observation_cost_saving",
      "rows": 20,
      "mean_alignment_score": 0.0,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.009178818238124598,
      "action_primitives": "diagnostic_observation_saving_probe",
      "action_channels": "uncertainty_probe",
      "mean_delta_conflict": -3.1552187693628665e-06,
      "mean_delta_uncertainty": -1.2620875077432037e-05,
      "mean_delta_exploration": 4.5894091190601395e-06,
      "mean_delta_overconvergence": -2.2947045595359677e-06,
      "mean_delta_m_overall": 7.744627888428556e-06,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "rollback_guard_down",
      "intent_family": "safety_relaxation",
      "rows": 20,
      "mean_alignment_score": 0.0,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.00923468642738151,
      "action_primitives": "diagnostic_rollback_relaxation_probe",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -2.3086716068515533e-06,
      "mean_delta_uncertainty": -3.4630074102759423e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 2.5395387675297697e-05,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "sandbox_probe_entry_down",
      "intent_family": "probe_restraint",
      "rows": 10,
      "mean_alignment_score": 0.0,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.006,
      "action_primitives": "diagnostic_probe_restraint",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -1.5000000000264802e-06,
      "mean_delta_uncertainty": -2.249999999998087e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 1.6500000000019276e-05,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_down",
      "intent_family": "exploration_restraint",
      "rows": 5,
      "mean_alignment_score": 0.3333333333333333,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.006,
      "action_primitives": "diagnostic_exploration_restraint",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -1.500000000020929e-06,
      "mean_delta_uncertainty": -2.25000000001474e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 1.6500000000041482e-05,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "sensitivity_opening",
      "intent_family": "response_opening",
      "rows": 20,
      "mean_alignment_score": 0.3333333333333333,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.009456811823750324,
      "action_primitives": "diagnostic_sensitivity_opening",
      "action_channels": "coupling_relief",
      "mean_delta_conflict": -8.570235715293917e-06,
      "mean_delta_uncertainty": 0.0,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -1.7140471430559732e-05,
      "mean_delta_m_overall": 8.570235715299468e-06,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    },
    {
      "semantic_effect": "update_frequency_down",
      "intent_family": "update_restraint",
      "rows": 10,
      "mean_alignment_score": 0.3333333333333333,
      "alignment_pass_rate": 0.0,
      "mean_action_mass": 0.00616145947450928,
      "action_primitives": "diagnostic_update_restraint",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -1.5403648686518335e-06,
      "mean_delta_uncertainty": -2.3105473029416677e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 1.694401355494257e-05,
      "dominant_verdict": "diagnostic_semantic_misaligned"
    }
  ],
  "strongest_semantic_effects": [
    {
      "semantic_effect": "adoption_barrier_relief",
      "intent_family": "adoption_opening",
      "rows": 20,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.009479999999999999,
      "action_primitives": "diagnostic_adoption_opening_probe",
      "action_channels": "exploration_injection",
      "mean_delta_conflict": 8.887499999721271e-07,
      "mean_delta_uncertainty": 3.5549999999967553e-06,
      "mean_delta_exploration": 2.3700000000002887e-05,
      "mean_delta_overconvergence": -1.6590000000003824e-05,
      "mean_delta_m_overall": 3.2291250000038296e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "commitment_strength_down",
      "intent_family": "commitment_relief",
      "rows": 20,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.00938791570368957,
      "action_primitives": "diagnostic_commitment_relief_probe",
      "action_channels": "exploration_injection",
      "mean_delta_conflict": 8.801170971906025e-07,
      "mean_delta_uncertainty": 3.520468388876208e-06,
      "mean_delta_exploration": 2.346978925922144e-05,
      "mean_delta_overconvergence": -1.642885248146139e-05,
      "mean_delta_m_overall": 3.1977587865728016e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_up",
      "intent_family": "exploration_attempt",
      "rows": 15,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.007396488031293213,
      "action_primitives": "diagnostic_exploration_attempt",
      "action_channels": "exploration_injection",
      "mean_delta_conflict": 6.934207528989471e-07,
      "mean_delta_uncertainty": 2.773683011714212e-06,
      "mean_delta_exploration": 1.8491220078239076e-05,
      "mean_delta_overconvergence": -1.2943854054774569e-05,
      "mean_delta_m_overall": 2.5194287356596532e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "sandbox_probe_entry_up",
      "intent_family": "exploration_observation",
      "rows": 10,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.006322301012493391,
      "action_primitives": "diagnostic_sandbox_probe",
      "action_channels": "exploration_injection",
      "mean_delta_conflict": 5.927157199048239e-07,
      "mean_delta_uncertainty": 2.3708628796637043e-06,
      "mean_delta_exploration": 1.580575253121441e-05,
      "mean_delta_overconvergence": -1.1064026771867574e-05,
      "mean_delta_m_overall": 2.1535337823808122e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "hysteresis_guard_down",
      "intent_family": "switching_flexibility",
      "rows": 20,
      "mean_alignment_score": 0.6666666666666666,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.009363586398186593,
      "action_primitives": "diagnostic_switching_flexibility",
      "action_channels": "coupling_relief",
      "mean_delta_conflict": -8.485750173370388e-06,
      "mean_delta_uncertainty": 0.0,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -1.697150034671753e-05,
      "mean_delta_m_overall": 8.48575017337594e-06,
      "dominant_verdict": "diagnostic_semantic_aligned"
    },
    {
      "semantic_effect": "intensity_cap_brake",
      "intent_family": "safety_cap",
      "rows": 20,
      "mean_alignment_score": 0.6666666666666666,
      "alignment_pass_rate": 1.0,
      "mean_action_mass": 0.009479999999999999,
      "action_primitives": "buffer_first",
      "action_channels": "buffer_increase",
      "mean_delta_conflict": -2.3700000000098643e-06,
      "mean_delta_uncertainty": -3.5550000000078573e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 2.607000000000581e-05,
      "dominant_verdict": "diagnostic_semantic_aligned"
    }
  ],
  "dept_pressure_tuning_readiness": "not_ready_review_diagnostic_outcome_alignment_first",
  "next_recommended_task": "DiagnosticClosedLoopRerunReview_RC1",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/diagnostic_closed_loop_rerun_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "diagnostic_closed_loop_combined_trace": "diagnostic_closed_loop_combined_trace_RC1.csv",
    "diagnostic_closed_loop_action_application": "diagnostic_closed_loop_action_application_RC1.csv",
    "diagnostic_closed_loop_semantic_isolated_alignment": "diagnostic_closed_loop_semantic_isolated_alignment_RC1.csv",
    "diagnostic_closed_loop_semantic_summary": "diagnostic_closed_loop_semantic_summary_RC1.csv",
    "diagnostic_closed_loop_scenario_summary": "diagnostic_closed_loop_scenario_summary_RC1.csv"
  },
  "rerun_note": "Diagnostic actions were actually applied to pseudo-reality in combined and isolated replay modes."
}
```

Focused test status:

```text
test_diagnostic_closed_loop_rerun.py: 3 passed
```

## 2. Main Result

Diagnostic actions were actually applied to pseudo-reality.

```text
combined_trace_rows = 20
applied_action_rows = 220
isolated_alignment_rows = 220
semantic_effect_count = 14
scenario_count = 4
```

Isolated semantic replay:

```text
mean_isolated_alignment_score = 0.561
isolated_alignment_pass_rate = 0.614
mean_isolated_action_mass = 0.008581
```

Combined rerun mean deltas:

```text
combined_mean_delta_conflict = -0.000084316
combined_mean_delta_uncertainty = -0.000086736
combined_mean_delta_exploration = 0.000234248
combined_mean_delta_m_overall = 0.000593909
```

## 3. Semantic Outcome Summary

```text
                   semantic_effect           intent_family  rows  mean_alignment_score  alignment_pass_rate  mean_action_mass                    action_primitives       action_channels  mean_delta_conflict  mean_delta_uncertainty  mean_delta_exploration  mean_delta_overconvergence  mean_delta_m_overall               dominant_verdict
        diagnostic_resolution_down observation_cost_saving    20              0.000000                  0.0          0.009179  diagnostic_observation_saving_probe     uncertainty_probe        -3.155219e-06               -0.000013                0.000005                   -0.000002              0.000008 diagnostic_semantic_misaligned
               rollback_guard_down       safety_relaxation    20              0.000000                  0.0          0.009235 diagnostic_rollback_relaxation_probe       buffer_increase        -2.308672e-06               -0.000003                0.000000                    0.000000              0.000025 diagnostic_semantic_misaligned
          sandbox_probe_entry_down         probe_restraint    10              0.000000                  0.0          0.006000           diagnostic_probe_restraint       buffer_increase        -1.500000e-06               -0.000002                0.000000                    0.000000              0.000017 diagnostic_semantic_misaligned
exploration_attempt_frequency_down   exploration_restraint     5              0.333333                  0.0          0.006000     diagnostic_exploration_restraint       buffer_increase        -1.500000e-06               -0.000002                0.000000                    0.000000              0.000017 diagnostic_semantic_misaligned
               sensitivity_opening        response_opening    20              0.333333                  0.0          0.009457       diagnostic_sensitivity_opening       coupling_relief        -8.570236e-06                0.000000                0.000000                   -0.000017              0.000009 diagnostic_semantic_misaligned
             update_frequency_down        update_restraint    10              0.333333                  0.0          0.006161          diagnostic_update_restraint       buffer_increase        -1.540365e-06               -0.000002                0.000000                    0.000000              0.000017 diagnostic_semantic_misaligned
             hysteresis_guard_down   switching_flexibility    20              0.666667                  1.0          0.009364     diagnostic_switching_flexibility       coupling_relief        -8.485750e-06                0.000000                0.000000                   -0.000017              0.000008    diagnostic_semantic_aligned
               intensity_cap_brake              safety_cap    20              0.666667                  1.0          0.009480                         buffer_first       buffer_increase        -2.370000e-06               -0.000004                0.000000                    0.000000              0.000026    diagnostic_semantic_aligned
             update_access_opening        temporal_opening    20              0.666667                  1.0          0.009480       diagnostic_update_access_probe     uncertainty_probe        -3.258750e-06               -0.000013                0.000005                   -0.000002              0.000008    diagnostic_semantic_aligned
               update_frequency_up          update_opening    10              0.666667                  1.0          0.006085            diagnostic_update_opening     uncertainty_probe        -2.091874e-06               -0.000008                0.000003                   -0.000002              0.000005    diagnostic_semantic_aligned
           adoption_barrier_relief        adoption_opening    20              1.000000                  1.0          0.009480    diagnostic_adoption_opening_probe exploration_injection         8.887500e-07                0.000004                0.000024                   -0.000017              0.000032    diagnostic_semantic_aligned
          commitment_strength_down       commitment_relief    20              1.000000                  1.0          0.009388   diagnostic_commitment_relief_probe exploration_injection         8.801171e-07                0.000004                0.000023                   -0.000016              0.000032    diagnostic_semantic_aligned
  exploration_attempt_frequency_up     exploration_attempt    15              1.000000                  1.0          0.007396       diagnostic_exploration_attempt exploration_injection         6.934208e-07                0.000003                0.000018                   -0.000013              0.000025    diagnostic_semantic_aligned
            sandbox_probe_entry_up exploration_observation    10              1.000000                  1.0          0.006322             diagnostic_sandbox_probe exploration_injection         5.927157e-07                0.000002                0.000016                   -0.000011              0.000022    diagnostic_semantic_aligned
```

Strongest semantic effects:

```text
adoption_barrier_relief
commitment_strength_down
exploration_attempt_frequency_up
sandbox_probe_entry_up
hysteresis_guard_down
intensity_cap_brake
```

Weakest semantic effects:

```text
diagnostic_resolution_down
rollback_guard_down
sandbox_probe_entry_down
update_access_opening
update_frequency_up
exploration_attempt_frequency_down
```

## 4. Scenario Summary

```text
    run_scenario  combined_steps  combined_mean_action_mass  combined_mean_delta_conflict  combined_mean_delta_uncertainty  combined_mean_delta_exploration  combined_mean_delta_m_overall  isolated_rows  isolated_alignment_pass_rate  isolated_mean_alignment_score  isolated_mean_action_mass
exploration_loss               5                   0.096891                     -0.000081                        -0.000084                         0.000286                       0.000606             55                      0.727273                       0.636364                   0.008808
          normal               5                   0.094063                     -0.000093                        -0.000097                         0.000169                       0.000595             55                      0.454545                       0.454545                   0.008551
   relation_lock               5                   0.093927                     -0.000079                        -0.000084                         0.000270                       0.000579             55                      0.727273                       0.636364                   0.008539
           shock               5                   0.092694                     -0.000085                        -0.000081                         0.000211                       0.000595             55                      0.545455                       0.515152                   0.008427
```

## 5. Interpretation

RC1 confirms that the diagnostic policy is no longer only a table-level coverage
fix. The weak diagnostic actions can be sent into pseudo-reality and measured.

However, the alignment is mixed:

```text
isolated_alignment_pass_rate = 0.614
```

This means the validation action module is now observable enough to diagnose,
but not yet good enough to tune DEPT pressure from the result.

## 6. Important Pattern

Exploration-opening style effects responded best:

```text
adoption_barrier_relief
commitment_strength_down
exploration_attempt_frequency_up
sandbox_probe_entry_up
```

This makes sense because their diagnostic channel is:

```text
exploration_injection
```

and pseudo-reality has a direct response path for that channel.

Buffer/restraint/update semantics were weaker or mixed because their expected
semantic contracts are more indirect than their current diagnostic channels.

## 7. Current Boundary

This still does not justify H-DEPT pressure tuning.

Reason:

```text
we now have outcome attribution,
but several semantic families are misaligned or weak under diagnostic replay
```

The next step should review this rerun result and decide whether to tune:

```text
diagnostic primitive mapping
expected-effect contracts
action strength
or only then DEPT-side pressure generation
```

## 8. Next Recommended Task

```text
DiagnosticClosedLoopRerunReview_RC1
```

Purpose:

```text
Classify which semantic families are ready,
which need primitive mapping repair,
and whether coupling_relief->staged_unlock should be handled next.
```

After that:

```text
CouplingReliefStagedUnlockRepair_RC1
```

remains the separate sequence-level repair task.
