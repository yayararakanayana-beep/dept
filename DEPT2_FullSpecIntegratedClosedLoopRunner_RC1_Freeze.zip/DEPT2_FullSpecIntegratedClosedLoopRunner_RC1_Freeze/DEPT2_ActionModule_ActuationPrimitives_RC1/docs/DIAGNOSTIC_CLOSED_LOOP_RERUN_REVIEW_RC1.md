# Diagnostic Closed Loop Rerun Review RC1

## 0. Position

`DiagnosticClosedLoopRerunReview_RC1` reviews the result of:

```text
DiagnosticClosedLoopRerun_RC1
```

It does not change the action module.

## 1. Purpose

Classify each semantic family into:

```text
ready_current_mapping
positive_control_keep
usable_but_review_expected_contract
expected_effect_contract_review
primitive_mapping_repair
primitive_mapping_or_contract_review
```

The goal is to decide what to fix before DEPT pressure tuning.

## 2. Outputs

```text
results/diagnostic_closed_loop_rerun_semantic_family_review_RC1.csv
results/diagnostic_closed_loop_rerun_scenario_review_RC1.csv
results/diagnostic_closed_loop_rerun_review_class_summary_RC1.csv
results/diagnostic_closed_loop_rerun_next_action_plan_RC1.csv
results/diagnostic_closed_loop_rerun_review_summary_RC1.json
```

## 3. Boundary

This review does not authorize H-DEPT pressure tuning.

The next recommended work is selected from:

```text
DiagnosticPrimitiveMappingRepair_RC1
ExpectedEffectContractReview_RC1
CouplingReliefStagedUnlockRepair_RC1
```
