# Diagnostic Action Translation Policy RC1

## 0. Position

`DiagnosticActionTranslationPolicy_RC1` is a validation-only action policy.

It follows the conclusion of:

```text
PressureOutcomeAlignmentAudit_RC2_ResultReview_RC1
```

Main finding:

```text
RC2 fixed the sign-only audit issue.
The remaining bottleneck is semantic/action survival.
```

## 1. Purpose

This task does **not** build a safety/governance action module.

It builds a validation action translation policy:

```text
pressure semantic_effect
→ weak diagnostic plan
→ weak diagnostic action
→ explicit drop/recovery reason
```

The goal is to preserve enough pressure intent into actual action so later
pressure-outcome alignment can be interpreted.

## 2. What It Adds

```text
alignment_probe / diagnostic_translation mode
semantic-family minimum plan survival
weak action pass-through for semantic effects
explicit drop reason table
diagnostic primitive routes for sandbox/update/exploration/adoption-opening
buffer->replan positive control retention
```

## 3. What It Does Not Do

It does not repair:

```text
coupling_relief -> staged_unlock
```

That is intentionally split into a later task.

It also does not tune H-DEPT pressure generation.

## 4. Key Principle

For validation:

```text
Do not drop pressure meaning just because it is not governance-safe.
Pass it weakly and traceably.
```

The output action frame is diagnostic-only.

## 5. Outputs

```text
results/diagnostic_action_translation_policy_plan_RC1.csv
results/diagnostic_action_translation_policy_action_frame_RC1.csv
results/diagnostic_action_translation_policy_drop_reason_RC1.csv
results/diagnostic_action_translation_policy_semantic_coverage_RC1.csv
results/diagnostic_action_translation_policy_primitive_route_summary_RC1.csv
results/diagnostic_action_translation_policy_family_summary_RC1.csv
results/diagnostic_action_translation_policy_summary_RC1.json
```
