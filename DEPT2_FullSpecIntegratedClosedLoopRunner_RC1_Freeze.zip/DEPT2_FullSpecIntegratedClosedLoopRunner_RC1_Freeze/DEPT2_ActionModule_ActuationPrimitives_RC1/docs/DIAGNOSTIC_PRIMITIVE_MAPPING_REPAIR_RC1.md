# Diagnostic Primitive Mapping Repair RC1

## 0. Position

`DiagnosticPrimitiveMappingRepair_RC1` follows:

```text
DiagnosticClosedLoopRerunReview_RC1
```

It repairs only the primitive/channel mapping for semantic effects that were
already delivered and measurable, but misaligned.

## 1. Repair Targets

```text
sensitivity_opening
exploration_attempt_frequency_down
update_frequency_down
```

## 2. Boundary

This task does not:

```text
- tune H-DEPT pressure
- repair coupling_relief->staged_unlock
- rewrite expected-effect contracts
```

## 3. Main Repair Logic

```text
sensitivity_opening:
  coupling_relief -> exploration_injection

exploration_attempt_frequency_down:
  buffer_increase -> diagnostic_exploration_restraint

update_frequency_down:
  buffer_increase -> diagnostic_update_restraint
```

The restraint channels are validation-only diagnostic channels used by this
repair rerun to express explicit exploration/update restraint.

## 4. Outputs

```text
results/diagnostic_primitive_mapping_repair_table_RC1.csv
results/diagnostic_primitive_mapping_repaired_action_frame_RC1.csv
results/diagnostic_primitive_mapping_repair_isolated_alignment_RC1.csv
results/diagnostic_primitive_mapping_repair_semantic_summary_RC1.csv
results/diagnostic_primitive_mapping_repair_comparison_RC1.csv
results/diagnostic_primitive_mapping_repair_target_comparison_RC1.csv
results/diagnostic_primitive_mapping_repair_summary_RC1.json
```

## 5. Next

After this repair, expected-effect contract review is still required for the
contract-review semantic families.
