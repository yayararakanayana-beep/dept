# Coupling Relief Staged Unlock Repair Report RC1

## 0. Position

This report records **CouplingReliefStagedUnlockRepair_RC1**.

It follows:

```text
ProbeRestraintPrimitivePatch_RC1
```

The previous diagnostic action issues were:

```text
coverage
action delivery
primitive mapping
expected-effect contract
probe-restraint ambiguity
```

Those have been handled.  
This task repairs the remaining sequence-level issue:

```text
coupling_relief -> staged_unlock
```

## 1. Prior Evidence

From the earlier RC2 primitive audit, staged unlock sequences were weak:

```text
prior_staged_unlock_mean_pass_rate = 0.16666666666666666
prior_staged_unlock_rows = 2
```

Prior rows:

```text
     action_primitive                         primitive_sequence  action_channel  rows  mean_alignment_score  alignment_pass_rate  total_action_rows  total_action_mass                    dominant_verdict                                     prior_source
coupling_relief_first           coupling_relief -> staged_unlock coupling_relief     4              0.083333             0.000000                 15           1.417449 primitive_misaligned_despite_action pressure_outcome_alignment_rc2_primitive_summary
         buffer_first buffer -> coupling_relief -> staged_unlock buffer_increase     3              0.444444             0.333333                  4           0.450201 primitive_misaligned_despite_action pressure_outcome_alignment_rc2_primitive_summary
```

## 2. Repair Table

```text
                              old_sequence                                                 repair_sequence                       repair_type                                                                                                   reason                                             repair_contract
          coupling_relief -> staged_unlock           coupling_relief -> observe -> guarded_relation_unlock          delayed_guarded_sequence immediate unlock is a sequence-level risk; separate relief from unlock and gate unlock after observation CouplingReliefStagedUnlockRepair_RC1__sequence_repair_table
buffer -> coupling_relief -> staged_unlock buffer -> coupling_relief -> observe -> guarded_relation_unlock buffered_delayed_guarded_sequence                         buffer precondition can be retained but unlock should remain delayed and guarded CouplingReliefStagedUnlockRepair_RC1__sequence_repair_table
```

## 3. Targets

```text
 run_seed     run_scenario  loop_step          semantic_effect         intent_family                   original_action_primitives                                                original_primitive_sequences        original_action_channels  target_rows  diagnostic_strength                                            target_contract
       42 exploration_loss          0 commitment_strength_down     commitment_relief coupling_relief_first|staged_relation_unlock                                                    staged_unlock -> observe coupling_relief|relation_unlock            2               0.0090 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42 exploration_loss          1    hysteresis_guard_down switching_flexibility coupling_relief_first|staged_relation_unlock                                                    staged_unlock -> observe coupling_relief|relation_unlock            2               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42 exploration_loss          2    hysteresis_guard_down switching_flexibility coupling_relief_first|staged_relation_unlock                                                    staged_unlock -> observe coupling_relief|relation_unlock            2               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42 exploration_loss          3    hysteresis_guard_down switching_flexibility coupling_relief_first|staged_relation_unlock                                                    staged_unlock -> observe coupling_relief|relation_unlock            2               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42 exploration_loss          4    hysteresis_guard_down switching_flexibility coupling_relief_first|staged_relation_unlock                                                    staged_unlock -> observe coupling_relief|relation_unlock            2               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42           normal          0    hysteresis_guard_down switching_flexibility                       staged_relation_unlock                                                    staged_unlock -> observe                 relation_unlock            1               0.0090 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42           normal          1    hysteresis_guard_down switching_flexibility                       staged_relation_unlock                                                    staged_unlock -> observe                 relation_unlock            1               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42           normal          2    hysteresis_guard_down switching_flexibility                       staged_relation_unlock                                                    staged_unlock -> observe                 relation_unlock            1               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42           normal          3    hysteresis_guard_down switching_flexibility                       staged_relation_unlock                                                    staged_unlock -> observe                 relation_unlock            1               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42           normal          4    hysteresis_guard_down switching_flexibility                       staged_relation_unlock                                                    staged_unlock -> observe                 relation_unlock            1               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42    relation_lock          0      sensitivity_opening      response_opening           buffer_first|coupling_relief_first buffer -> coupling_relief -> staged_unlock|coupling_relief -> staged_unlock buffer_increase|coupling_relief            2               0.0090 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42    relation_lock          1    hysteresis_guard_down switching_flexibility           buffer_first|coupling_relief_first buffer -> coupling_relief -> staged_unlock|coupling_relief -> staged_unlock buffer_increase|coupling_relief            2               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42    relation_lock          2    hysteresis_guard_down switching_flexibility           buffer_first|coupling_relief_first buffer -> coupling_relief -> staged_unlock|coupling_relief -> staged_unlock buffer_increase|coupling_relief            2               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42    relation_lock          3    hysteresis_guard_down switching_flexibility           buffer_first|coupling_relief_first buffer -> coupling_relief -> staged_unlock|coupling_relief -> staged_unlock buffer_increase|coupling_relief            2               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
       42    relation_lock          4    hysteresis_guard_down switching_flexibility           buffer_first|coupling_relief_first buffer -> coupling_relief -> staged_unlock|coupling_relief -> staged_unlock buffer_increase|coupling_relief            2               0.0096 CouplingReliefStagedUnlockRepair_RC1__staged_unlock_target
```

## 4. Execution Summary

```json
{
  "task": "CouplingReliefStagedUnlockRepair_RC1",
  "status": "completed",
  "target_rows": 15,
  "alignment_rows": 60,
  "variant_count": 4,
  "prior_staged_unlock_rows": 2,
  "prior_staged_unlock_mean_pass_rate": 0.16666666666666666,
  "old_immediate_pass_rate": 1.0,
  "old_immediate_mean_score": 1.0,
  "best_variant": "delayed_guarded_unlock",
  "best_variant_pass_rate": 1.0,
  "best_variant_mean_score": 1.0,
  "pass_rate_delta_vs_old": 0.0,
  "score_delta_vs_old": 0.0,
  "recommended_sequence": "coupling_relief -> observe -> guarded_relation_unlock",
  "repair_decision": "replace_immediate_unlock_with_guarded_delayed_sequence",
  "variant_summary": [
    {
      "sequence_variant": "buffered_delayed_guarded_unlock",
      "rows": 15,
      "semantic_effects": 3,
      "scenarios": 3,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_diagnostic_strength": 0.009479999999999999,
      "mean_delta_conflict": -1.5227250000023524e-05,
      "mean_delta_uncertainty": -4.799250000013059e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -2.642550000000789e-05,
      "mean_delta_m_overall": 3.323925000006482e-05
    },
    {
      "sequence_variant": "delayed_guarded_unlock",
      "rows": 15,
      "semantic_effects": 3,
      "scenarios": 3,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_diagnostic_strength": 0.009479999999999999,
      "mean_delta_conflict": -1.4812500000016549e-05,
      "mean_delta_uncertainty": -3.3180000000003022e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -2.796600000001398e-05,
      "mean_delta_m_overall": 2.0619000000040207e-05
    },
    {
      "sequence_variant": "old_immediate_unlock",
      "rows": 15,
      "semantic_effects": 3,
      "scenarios": 3,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_diagnostic_strength": 0.009479999999999999,
      "mean_delta_conflict": -1.2738750000044578e-05,
      "mean_delta_uncertainty": 0.0,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -2.547750000001468e-05,
      "mean_delta_m_overall": 1.7715750000083887e-05
    },
    {
      "sequence_variant": "relief_observe_only",
      "rows": 15,
      "semantic_effects": 3,
      "scenarios": 3,
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_diagnostic_strength": 0.009479999999999999,
      "mean_delta_conflict": -8.59125000001922e-06,
      "mean_delta_uncertainty": 0.0,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -1.7182500000015772e-05,
      "mean_delta_m_overall": 8.591250000026622e-06
    }
  ],
  "primary_conclusion": "Immediate staged unlock should be replaced by a guarded delayed unlock sequence for diagnostic validation.",
  "dept_pressure_tuning_readiness": "not_ready_final_integration_review_required",
  "next_recommended_task": "DiagnosticActionModuleIntegrationReview_RC1",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/coupling_relief_staged_unlock_repair_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "coupling_relief_staged_unlock_targets": "coupling_relief_staged_unlock_targets_RC1.csv",
    "coupling_relief_staged_unlock_variant_alignment": "coupling_relief_staged_unlock_variant_alignment_RC1.csv",
    "coupling_relief_staged_unlock_variant_summary": "coupling_relief_staged_unlock_variant_summary_RC1.csv",
    "coupling_relief_staged_unlock_repaired_policy": "coupling_relief_staged_unlock_repaired_policy_RC1.csv",
    "coupling_relief_staged_unlock_prior_rc2": "coupling_relief_staged_unlock_prior_rc2_RC1.csv",
    "coupling_relief_staged_unlock_repair_table": "coupling_relief_staged_unlock_repair_table_RC1.csv"
  }
}
```

Focused test status:

```text
test_coupling_relief_staged_unlock_repair.py: 3 passed
```

## 5. Variant Summary

```text
               sequence_variant  rows  semantic_effects  scenarios  mean_alignment_score  alignment_pass_rate  mean_diagnostic_strength  mean_delta_conflict  mean_delta_uncertainty  mean_delta_exploration  mean_delta_overconvergence  mean_delta_m_overall
buffered_delayed_guarded_unlock    15                 3          3                   1.0                  1.0                   0.00948            -0.000015               -0.000005                     0.0                   -0.000026              0.000033
         delayed_guarded_unlock    15                 3          3                   1.0                  1.0                   0.00948            -0.000015               -0.000003                     0.0                   -0.000028              0.000021
           old_immediate_unlock    15                 3          3                   1.0                  1.0                   0.00948            -0.000013                0.000000                     0.0                   -0.000025              0.000018
            relief_observe_only    15                 3          3                   1.0                  1.0                   0.00948            -0.000009                0.000000                     0.0                   -0.000017              0.000009
```

## 6. Policy Decision

```text
recommended_sequence_variant                                  recommended_sequence  alignment_pass_rate  mean_alignment_score                                        repair_decision                                                                         repair_reason                                                   policy_contract
      delayed_guarded_unlock coupling_relief -> observe -> guarded_relation_unlock                  1.0                   1.0 replace_immediate_unlock_with_guarded_delayed_sequence sequence-level repair separates relief from unlock and gates unlock after observation CouplingReliefStagedUnlockRepair_RC1__recommended_sequence_policy
```

## 7. Interpretation

Compact replay shows all sequence variants can produce the expected direction
under the simplified diagnostic setup.

However, prior RC2 logs showed the immediate staged-unlock family was weak:

```text
prior_staged_unlock_mean_pass_rate = 0.16666666666666666
```

So the repair decision is not based on compact replay improvement alone.  
It is based on the sequence-design principle:

```text
do not unlock immediately after coupling relief;
separate relief from unlock and insert observation before unlock.
```

The selected sequence is:

```text
coupling_relief -> observe -> guarded_relation_unlock
```

This keeps the action module diagnostic and traceable:

```text
coupling_relief
-> observe
-> guarded_relation_unlock
```

## 8. Current State

```text
coverage:
  solved

action delivery:
  solved

primitive mapping:
  repaired

expected-effect contract:
  patched

probe-restraint ambiguity:
  split and resolved

coupling_relief -> staged_unlock:
  repaired as guarded delayed sequence
```

## 9. Remaining Boundary

This still does not mean H-DEPT pressure tuning is ready.

Reason:

```text
The action module has now been substantially repaired.
A final integration review should verify that all changes are coherent before
using outcomes to tune pressure generation.
```

## 10. Next Recommended Task

```text
DiagnosticActionModuleIntegrationReview_RC1
```

Purpose:

```text
Review the full validation action module after all repairs:
- coverage
- delivery
- primitive mapping
- expected-effect contracts
- probe-restraint split
- staged unlock repair

Then decide whether pressure-outcome tuning can begin.
```
