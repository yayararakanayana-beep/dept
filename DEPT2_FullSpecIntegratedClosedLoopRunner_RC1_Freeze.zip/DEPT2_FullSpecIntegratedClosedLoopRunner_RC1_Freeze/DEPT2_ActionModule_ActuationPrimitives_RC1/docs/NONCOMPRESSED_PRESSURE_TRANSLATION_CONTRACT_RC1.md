# NonCompressed Pressure Translation Contract RC1

## Purpose

Fix the lower-layer interpretation error where signed `approved_*` values were treated as direct promote/suppress action pressure and averaged too early.

## Fixed principle

The lower layer must translate upper pressure without compressing it.
Compression is allowed only inside the action module's ActionPlanner, because only the planner has the combined context needed to decide how to act on a concrete pseudo system.

## Layer roles

### H-DEPT
Produces approved pressure components from G_t/K_t-derived M_t.

### H11-local
Receives upper pressure as high-fidelity H11 local pressure field.
It does not convert pressure into action channels.

### HDEPTPressureIntentAnnotator
Adds semantic annotations to each approved component:

- component identity
- signed parameter direction
- semantic effect of that direction
- control domain
- possible action relevance flags

It does not aggregate or average components.

### ActionSurface
Outputs affordance map:

- where action is possible
- which channel is available
- estimated need
- estimated cost
- local reversibility

It does not use H11 pressure to decide action strength.

### v8 support
Returns local support metrics for affordances/planned candidates:

- confidence
- conflict
- unresolved
- whether detailed local support is requested

### ActionPlanner
First compression and decision point. It receives:

- non-compressed PressureIntentBundle
- ActionSurface affordances
- v8 local support
- lower parameter state

It decides route and strength, preserving distinctions such as:

- exploration cost relief only
- explore with adoption barrier relief
- observe then explore
- guarded relation unlock
- damp with cap

### Final gate
Allows, weakens, shadows, or no-ops planned candidates.

### ActionModule actuator
Applies final gated actions to pseudo reality. It never mutates G_t/K_t directly.

## Formal upper input rule

H-DEPT formal input is limited to G_t/K_t_global. No GraphObject/v8/final gate/action surface/planner columns are allowed into formal H-DEPT observation.
