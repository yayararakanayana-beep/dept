# Diagnostic Closed Loop Rerun Review Report RC1

## 0. Position

This report records **DiagnosticClosedLoopRerunReview_RC1**.

It reviews:

```text
DiagnosticClosedLoopRerun_RC1
```

This task does not modify the action module and does not tune H-DEPT pressure.

## 1. Execution Summary

```json
{
  "task": "DiagnosticClosedLoopRerunReview_RC1",
  "status": "completed",
  "source_task": "DiagnosticClosedLoopRerun_RC1",
  "semantic_effect_count": 14,
  "ready_or_positive_control_count": 5,
  "primitive_mapping_repair_count": 3,
  "contract_review_count": 6,
  "class_counts": {
    "ready_current_mapping": 4,
    "expected_effect_contract_review": 3,
    "usable_but_review_expected_contract": 3,
    "primitive_mapping_or_contract_review": 2,
    "primitive_mapping_repair": 1,
    "positive_control_keep": 1
  },
  "ready_semantics": [
    "intensity_cap_brake",
    "adoption_barrier_relief",
    "commitment_strength_down",
    "exploration_attempt_frequency_up",
    "sandbox_probe_entry_up"
  ],
  "primitive_mapping_repair_semantics": [
    "sensitivity_opening",
    "exploration_attempt_frequency_down",
    "update_frequency_down"
  ],
  "expected_contract_review_semantics": [
    "diagnostic_resolution_down",
    "rollback_guard_down",
    "sandbox_probe_entry_down",
    "hysteresis_guard_down",
    "update_access_opening",
    "update_frequency_up"
  ],
  "scenario_review_classes": {
    "scenario_ready_for_next_precision_test": 2,
    "scenario_direction_good_alignment_mixed": 2
  },
  "mean_isolated_alignment_score": 0.5606060606060606,
  "isolated_alignment_pass_rate": 0.6136363636363636,
  "primary_conclusion": "Diagnostic actions are delivered and outcome-attributable; mapping is usable for opening/exploration semantics but mixed for restraint/update/safety-relaxation semantics.",
  "dept_pressure_tuning_readiness": "not_ready_mapping_and_contract_review_required",
  "recommended_next_task": "DiagnosticPrimitiveMappingRepair_RC1",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/diagnostic_closed_loop_rerun_review_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "diagnostic_rerun_semantic_family_review": "diagnostic_closed_loop_rerun_semantic_family_review_RC1.csv",
    "diagnostic_rerun_scenario_review": "diagnostic_closed_loop_rerun_scenario_review_RC1.csv",
    "diagnostic_rerun_review_class_summary": "diagnostic_closed_loop_rerun_review_class_summary_RC1.csv",
    "diagnostic_rerun_next_action_plan": "diagnostic_closed_loop_rerun_next_action_plan_RC1.csv"
  }
}
```

Focused test status:

```text
test_diagnostic_closed_loop_rerun_review.py: 3 passed
```

## 2. Main Conclusion

Diagnostic actions are now:

```text
delivered
outcome-attributable
reviewable by semantic family
```

But semantic alignment is still mixed.

The key result:

```text
mean_isolated_alignment_score = 0.561
isolated_alignment_pass_rate = 0.614
```

Therefore:

```text
DEPT pressure tuning is still not ready.
```

The bottleneck has moved from:

```text
semantic/action coverage
```

to:

```text
diagnostic primitive mapping
and expected-effect contract correctness
```

## 3. Semantic Family Review

```text
                   semantic_effect           intent_family  rows  mean_alignment_score  alignment_pass_rate  mean_action_mass                    action_primitives       action_channels  mean_delta_conflict  mean_delta_uncertainty  mean_delta_exploration  mean_delta_overconvergence  mean_delta_m_overall               dominant_verdict                         review_class                                                                                                    review_reason  review_priority                                                          net_positive_direction
               intensity_cap_brake              safety_cap    20              0.666667                  1.0          0.009480                         buffer_first       buffer_increase        -2.370000e-06               -0.000004                0.000000                    0.000000              0.000026    diagnostic_semantic_aligned                positive_control_keep                            buffer->replan works as a stable positive control; keep it unchanged for comparisons.                1                                     conflict_down|uncertainty_down|m_overall_up
               sensitivity_opening        response_opening    20              0.333333                  0.0          0.009457       diagnostic_sensitivity_opening       coupling_relief        -8.570236e-06                0.000000                0.000000                   -0.000017              0.000009 diagnostic_semantic_misaligned             primitive_mapping_repair             coupling_relief route moves coupling/conflict but fails the semantic contract; mapping needs repair.                1                                 conflict_down|overconvergence_down|m_overall_up
           adoption_barrier_relief        adoption_opening    20              1.000000                  1.0          0.009480    diagnostic_adoption_opening_probe exploration_injection         8.887500e-07                0.000004                0.000024                   -0.000017              0.000032    diagnostic_semantic_aligned                ready_current_mapping                                 current diagnostic primitive maps cleanly to expected outcome in pseudo-reality.                1                                exploration_up|overconvergence_down|m_overall_up
          commitment_strength_down       commitment_relief    20              1.000000                  1.0          0.009388   diagnostic_commitment_relief_probe exploration_injection         8.801171e-07                0.000004                0.000023                   -0.000016              0.000032    diagnostic_semantic_aligned                ready_current_mapping                                 current diagnostic primitive maps cleanly to expected outcome in pseudo-reality.                1                                exploration_up|overconvergence_down|m_overall_up
  exploration_attempt_frequency_up     exploration_attempt    15              1.000000                  1.0          0.007396       diagnostic_exploration_attempt exploration_injection         6.934208e-07                0.000003                0.000018                   -0.000013              0.000025    diagnostic_semantic_aligned                ready_current_mapping                                 current diagnostic primitive maps cleanly to expected outcome in pseudo-reality.                1                                exploration_up|overconvergence_down|m_overall_up
            sandbox_probe_entry_up exploration_observation    10              1.000000                  1.0          0.006322             diagnostic_sandbox_probe exploration_injection         5.927157e-07                0.000002                0.000016                   -0.000011              0.000022    diagnostic_semantic_aligned                ready_current_mapping                                 current diagnostic primitive maps cleanly to expected outcome in pseudo-reality.                1                                exploration_up|overconvergence_down|m_overall_up
        diagnostic_resolution_down observation_cost_saving    20              0.000000                  0.0          0.009179  diagnostic_observation_saving_probe     uncertainty_probe        -3.155219e-06               -0.000013                0.000005                   -0.000002              0.000008 diagnostic_semantic_misaligned      expected_effect_contract_review      action produces understandable stabilizing movement, but the expected semantic contract appears mismatched.                2 conflict_down|uncertainty_down|exploration_up|overconvergence_down|m_overall_up
               rollback_guard_down       safety_relaxation    20              0.000000                  0.0          0.009235 diagnostic_rollback_relaxation_probe       buffer_increase        -2.308672e-06               -0.000003                0.000000                    0.000000              0.000025 diagnostic_semantic_misaligned      expected_effect_contract_review      action produces understandable stabilizing movement, but the expected semantic contract appears mismatched.                2                                     conflict_down|uncertainty_down|m_overall_up
          sandbox_probe_entry_down         probe_restraint    10              0.000000                  0.0          0.006000           diagnostic_probe_restraint       buffer_increase        -1.500000e-06               -0.000002                0.000000                    0.000000              0.000017 diagnostic_semantic_misaligned      expected_effect_contract_review      action produces understandable stabilizing movement, but the expected semantic contract appears mismatched.                2                                     conflict_down|uncertainty_down|m_overall_up
exploration_attempt_frequency_down   exploration_restraint     5              0.333333                  0.0          0.006000     diagnostic_exploration_restraint       buffer_increase        -1.500000e-06               -0.000002                0.000000                    0.000000              0.000017 diagnostic_semantic_misaligned primitive_mapping_or_contract_review buffer route creates stabilizing movement but does not express the intended restraint/opening semantics clearly.                2                                     conflict_down|uncertainty_down|m_overall_up
             update_frequency_down        update_restraint    10              0.333333                  0.0          0.006161          diagnostic_update_restraint       buffer_increase        -1.540365e-06               -0.000002                0.000000                    0.000000              0.000017 diagnostic_semantic_misaligned primitive_mapping_or_contract_review buffer route creates stabilizing movement but does not express the intended restraint/opening semantics clearly.                2                                     conflict_down|uncertainty_down|m_overall_up
             hysteresis_guard_down   switching_flexibility    20              0.666667                  1.0          0.009364     diagnostic_switching_flexibility       coupling_relief        -8.485750e-06                0.000000                0.000000                   -0.000017              0.000008    diagnostic_semantic_aligned  usable_but_review_expected_contract                   current primitive is usable, but only partially matches the semantic expected-effect contract.                2                                 conflict_down|overconvergence_down|m_overall_up
             update_access_opening        temporal_opening    20              0.666667                  1.0          0.009480       diagnostic_update_access_probe     uncertainty_probe        -3.258750e-06               -0.000013                0.000005                   -0.000002              0.000008    diagnostic_semantic_aligned  usable_but_review_expected_contract                   current primitive is usable, but only partially matches the semantic expected-effect contract.                2 conflict_down|uncertainty_down|exploration_up|overconvergence_down|m_overall_up
               update_frequency_up          update_opening    10              0.666667                  1.0          0.006085            diagnostic_update_opening     uncertainty_probe        -2.091874e-06               -0.000008                0.000003                   -0.000002              0.000005    diagnostic_semantic_aligned  usable_but_review_expected_contract                   current primitive is usable, but only partially matches the semantic expected-effect contract.                2 conflict_down|uncertainty_down|exploration_up|overconvergence_down|m_overall_up
```

## 4. Review Class Summary

```text
                        review_class  semantic_count  mean_alignment_score  mean_pass_rate                                                                                                semantics
     expected_effect_contract_review               3              0.000000             0.0                                  diagnostic_resolution_down|rollback_guard_down|sandbox_probe_entry_down
               positive_control_keep               1              0.666667             1.0                                                                                      intensity_cap_brake
primitive_mapping_or_contract_review               2              0.333333             0.0                                                 exploration_attempt_frequency_down|update_frequency_down
            primitive_mapping_repair               1              0.333333             0.0                                                                                      sensitivity_opening
               ready_current_mapping               4              1.000000             1.0 adoption_barrier_relief|commitment_strength_down|exploration_attempt_frequency_up|sandbox_probe_entry_up
 usable_but_review_expected_contract               3              0.666667             1.0                                          hysteresis_guard_down|update_access_opening|update_frequency_up
```

## 5. Scenario Review

```text
    run_scenario  combined_steps  combined_mean_action_mass  combined_mean_delta_conflict  combined_mean_delta_uncertainty  combined_mean_delta_exploration  combined_mean_delta_m_overall  isolated_rows  isolated_alignment_pass_rate  isolated_mean_alignment_score  isolated_mean_action_mass                   scenario_review_class                                                     scenario_review_reason
exploration_loss               5                   0.096891                     -0.000081                        -0.000084                         0.000286                       0.000606             55                      0.727273                       0.636364                   0.008808  scenario_ready_for_next_precision_test  diagnostic actions show usable alignment and favorable combined movement.
          normal               5                   0.094063                     -0.000093                        -0.000097                         0.000169                       0.000595             55                      0.454545                       0.454545                   0.008551 scenario_direction_good_alignment_mixed combined direction is favorable, but isolated semantic alignment is mixed.
   relation_lock               5                   0.093927                     -0.000079                        -0.000084                         0.000270                       0.000579             55                      0.727273                       0.636364                   0.008539  scenario_ready_for_next_precision_test  diagnostic actions show usable alignment and favorable combined movement.
           shock               5                   0.092694                     -0.000085                        -0.000081                         0.000211                       0.000595             55                      0.545455                       0.515152                   0.008427 scenario_direction_good_alignment_mixed combined direction is favorable, but isolated semantic alignment is mixed.
```

## 6. Classification

### Ready / keep

```text
intensity_cap_brake
adoption_barrier_relief
commitment_strength_down
exploration_attempt_frequency_up
sandbox_probe_entry_up
```

These are either cleanly mapped or useful as positive controls.

### Primitive mapping repair

```text
sensitivity_opening
exploration_attempt_frequency_down
update_frequency_down
```

These are observable, but current diagnostic primitive mapping does not express
the semantic intent cleanly enough.

### Expected-effect contract review

```text
diagnostic_resolution_down
rollback_guard_down
sandbox_probe_entry_down
hysteresis_guard_down
update_access_opening
update_frequency_up
```

These often move pseudo-reality in a reasonable stabilizing direction, but they
fail the current expected-effect contract.  
This suggests the contract may be too coarse or semantically mismatched.

## 7. Next Action Plan

```text
 priority                            next_task                                                                                                                 reason                                                                                                                        target_semantics                                                                              expected_output
        1 DiagnosticPrimitiveMappingRepair_RC1 Some semantic effects are now observable but misaligned; fix diagnostic primitive mapping before DEPT pressure tuning.                                                            sensitivity_opening|exploration_attempt_frequency_down|update_frequency_down            revised semantic_effect -> diagnostic primitive/channel map and re-run alignment.
        2     ExpectedEffectContractReview_RC1                  Several stabilizing diagnostic actions look beneficial but fail the current expected-effect contract. diagnostic_resolution_down|rollback_guard_down|sandbox_probe_entry_down|hysteresis_guard_down|update_access_opening|update_frequency_up                             separate true misalignment from wrong expected-outcome contract.
        3 CouplingReliefStagedUnlockRepair_RC1                  Sequence-level repair remains separate; do it after diagnostic mapping/contract issues are separated.                                                                    sensitivity_opening|hysteresis_guard_down|relation/coupling families repair staged unlock only after current coupling-relief diagnostic semantics are understood.
        4     Keep_DEPT_pressure_tuning_frozen                                                   Outcome attribution exists now, but semantic mapping is still mixed.                                                                                                                                     all                             pressure tuning resumes only after diagnostic mapping is stable.
```

## 8. Recommended Next Task

```text
DiagnosticPrimitiveMappingRepair_RC1
```

Reason:

```text
Some semantic effects are now delivered and measurable, but misaligned.
The next minimal repair is to fix semantic_effect -> diagnostic primitive/channel mapping.
```

Do not jump to H-DEPT pressure tuning yet.

`CouplingReliefStagedUnlockRepair_RC1` remains important, but it should follow
after the diagnostic primitive mapping / expected-contract split is cleaned up.
