# Validation Design and Results — NonCompressedPressureTranslation RC1

## Aim

Validate the revised contract: upper pressure is translated with semantic annotations but not compressed before the action module.

## Run configuration

- steps: 12
- seeds: 42
- scenarios: normal, exploration_loss, relation_lock, shock
- scope: smoke/contract validation, not performance proof

## Checks

| Check | Result |
|---|---:|
| formal input no lower leakage | True |
| intent annotation is noncompressive | True |
| first compression layer is ActionPlanner | True |
| ActionSurface has no pressure compression columns | True |
| exploration_loss has planned actions | True |
| exploration_loss has actuated actions | True |
| all sanity checks passed | True |

## Row counts

| Artifact | Rows |
|---|---:|
| PressureIntentBundle | 5808 |
| unique semantic effects | 14 |
| ActionSurface affordance rows | 5184 |
| planned action rows | 5184 |
| final gate rows | 5184 |
| action module rows | 644 |

## Scenario summary

| run_scenario     |   mean_action_mass |   mean_exploration_action_mass |   mean_planned_rows |   start_conflict |   end_conflict |
|:-----------------|-------------------:|-------------------------------:|--------------------:|-----------------:|---------------:|
| exploration_loss |           0.954859 |                       0.954859 |                 108 |         0.332506 |       0.368096 |
| normal           |           3.41529  |                       2.8334   |                 108 |         0.205839 |       0.19975  |
| relation_lock    |           0.99005  |                       0.563219 |                 108 |         0.405839 |       0.484735 |
| shock            |           1.2376   |                       0.360068 |                 108 |         0.342506 |       0.369879 |

## Interpretation

The previous issue, where exploration_loss produced no actions because pressure was compressed too early, is repaired at the contract level. In this RC1 run, exploration_loss has both planned and actuated actions.

This does not prove performance. Mean conflict still increased in several scenarios, especially relation_lock. That means the translation boundary is now cleaner, but the planner policy and actuator policy need further tuning.

## Key limitation

ActionPlanner currently uses a hand-written pseudo policy. Future work should compare planner policies and eventually learn the mapping from pressure intents and system character to action choice.
