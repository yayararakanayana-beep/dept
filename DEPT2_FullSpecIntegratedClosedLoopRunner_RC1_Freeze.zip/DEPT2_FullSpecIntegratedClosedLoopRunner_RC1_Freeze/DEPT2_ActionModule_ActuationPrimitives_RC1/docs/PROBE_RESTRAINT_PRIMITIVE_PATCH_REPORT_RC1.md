# Probe Restraint Primitive Patch Report RC1

## 0. Position

This report records **ProbeRestraintPrimitivePatch_RC1**.

It follows:

```text
ProbeRestraintPrimitiveCheck_RC1
```

The check showed that `sandbox_probe_entry_down` had two different meanings mixed
together:

```text
buffer-style stabilization
direct probe-restraint
```

This patch splits those roles.

## 1. Patch Table

```text
semantic_effect_original                patched_semantic_effect             probe_role                               action_primitive                    action_channel                  contract_role  rows                                                     reason                               patch_contract
sandbox_probe_entry_down sandbox_probe_entry_down_stabilization    stabilization_guard diagnostic_probe_restraint_stabilization_guard                   buffer_increase patched_stabilization_contract    10     preserve current buffer-style stabilization separately ProbeRestraintPrimitivePatch_RC1__role_split
sandbox_probe_entry_down               sandbox_probe_entry_down direct_probe_restraint           diagnostic_probe_restraint_direct_v1 diagnostic_probe_restraint_direct   old_probe_restraint_contract    10 add direct primitive to express probe-entry-down semantics ProbeRestraintPrimitivePatch_RC1__role_split
```

## 2. Contract Basis

```text
                 contract_role                        semantic_effect                                contract    assigned_probe_role                                                    reason
  old_probe_restraint_contract               sandbox_probe_entry_down       exploration:-1;overconvergence:+1 direct_probe_restraint          directly expresses sandbox/probe entry reduction
patched_stabilization_contract sandbox_probe_entry_down_stabilization conflict:-1;m_overall:+1;uncertainty:-1    stabilization_guard preserves buffer-style stabilization as separate behavior
```

## 3. Execution Summary

```json
{
  "task": "ProbeRestraintPrimitivePatch_RC1",
  "status": "completed",
  "patched_action_frame_rows": 230,
  "original_target_rows_split": 10,
  "role_split_rows": 20,
  "alignment_rows": 20,
  "direct_probe_restraint_role_pass_rate": 1.0,
  "stabilization_guard_role_pass_rate": 1.0,
  "direct_probe_old_contract_score": 1.0,
  "stabilization_patched_contract_score": 1.0,
  "role_summary": [
    {
      "probe_role": "direct_probe_restraint",
      "semantic_effect": "sandbox_probe_entry_down",
      "rows": 10,
      "action_primitive": "diagnostic_probe_restraint_direct_v1",
      "action_channel": "diagnostic_probe_restraint_direct",
      "mean_action_mass": 0.006,
      "role_contract_pass_rate": 1.0,
      "role_contract_mean_score": 1.0,
      "old_contract_pass_rate": 1.0,
      "old_contract_mean_score": 1.0,
      "patched_contract_pass_rate": 0.0,
      "patched_contract_mean_score": 0.0,
      "mean_delta_conflict": 2.0624999999996342e-06,
      "mean_delta_uncertainty": 1.4999999999931734e-06,
      "mean_delta_exploration": -1.4999999999992797e-05,
      "mean_delta_overconvergence": 1.349999999999546e-05,
      "mean_delta_m_overall": -2.231250000005458e-05
    },
    {
      "probe_role": "stabilization_guard",
      "semantic_effect": "sandbox_probe_entry_down_stabilization",
      "rows": 10,
      "action_primitive": "diagnostic_probe_restraint_stabilization_guard",
      "action_channel": "buffer_increase",
      "mean_action_mass": 0.006,
      "role_contract_pass_rate": 1.0,
      "role_contract_mean_score": 1.0,
      "old_contract_pass_rate": 0.0,
      "old_contract_mean_score": 0.0,
      "patched_contract_pass_rate": 1.0,
      "patched_contract_mean_score": 1.0,
      "mean_delta_conflict": -1.5000000000264802e-06,
      "mean_delta_uncertainty": -2.249999999998087e-06,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": 0.0,
      "mean_delta_m_overall": 1.6500000000019276e-05
    }
  ],
  "primary_conclusion": "sandbox_probe_entry_down is now split into direct probe-restraint and stabilization guard roles.",
  "dept_pressure_tuning_readiness": "not_ready_coupling_sequence_repair_still_required",
  "next_recommended_task": "CouplingReliefStagedUnlockRepair_RC1",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/probe_restraint_primitive_patch_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "probe_restraint_primitive_patch_table": "probe_restraint_primitive_patch_table_RC1.csv",
    "probe_restraint_primitive_patched_action_frame": "probe_restraint_primitive_patched_action_frame_RC1.csv",
    "probe_restraint_primitive_patch_alignment": "probe_restraint_primitive_patch_alignment_RC1.csv",
    "probe_restraint_primitive_patch_summary": "probe_restraint_primitive_patch_summary_RC1.csv",
    "probe_restraint_primitive_patch_contract_basis": "probe_restraint_primitive_patch_contract_basis_RC1.csv"
  }
}
```

Focused test status:

```text
test_probe_restraint_primitive_patch.py: 3 passed
```

## 4. Role Summary

```text
            probe_role                        semantic_effect  rows                               action_primitive                    action_channel  mean_action_mass  role_contract_pass_rate  role_contract_mean_score  old_contract_pass_rate  old_contract_mean_score  patched_contract_pass_rate  patched_contract_mean_score  mean_delta_conflict  mean_delta_uncertainty  mean_delta_exploration  mean_delta_overconvergence  mean_delta_m_overall
direct_probe_restraint               sandbox_probe_entry_down    10           diagnostic_probe_restraint_direct_v1 diagnostic_probe_restraint_direct             0.006                      1.0                       1.0                     1.0                      1.0                         0.0                          0.0             0.000002                0.000001               -0.000015                    0.000013             -0.000022
   stabilization_guard sandbox_probe_entry_down_stabilization    10 diagnostic_probe_restraint_stabilization_guard                   buffer_increase             0.006                      1.0                       1.0                     0.0                      0.0                         1.0                          1.0            -0.000002               -0.000002                0.000000                    0.000000              0.000017
```

## 5. Interpretation

The original `sandbox_probe_entry_down` rows are now split into:

```text
direct_probe_restraint:
  semantic_effect = sandbox_probe_entry_down
  primitive = diagnostic_probe_restraint_direct_v1
  channel = diagnostic_probe_restraint_direct
  contract = old probe-restraint contract

stabilization_guard:
  semantic_effect = sandbox_probe_entry_down_stabilization
  primitive = diagnostic_probe_restraint_stabilization_guard
  channel = buffer_increase
  contract = patched stabilization contract
```

Both roles pass their own contract:

```text
direct_probe_restraint_role_pass_rate = 1.000
stabilization_guard_role_pass_rate = 1.000
```

## 6. Current State

```text
coverage:
  solved

action delivery:
  solved

primitive mapping:
  repaired

expected-effect contract:
  patched

sandbox_probe_entry_down ambiguity:
  split into direct role and stabilization role

remaining:
  coupling_relief -> staged_unlock sequence repair
```

## 7. Next Recommended Task

```text
CouplingReliefStagedUnlockRepair_RC1
```

This is now the clean next step because the probe-restraint ambiguity has been
separated.
