# ActionModule Actuation Primitives Contract RC1

## 0. Position

This package modifies the action module after the non-compressed pressure translation fix.

The lower layer still must not compress H-DEPT upper pressure before the action module.
The action module is allowed to be environment-specific. For this RC1, the target environment is the current pseudo reality system used in the DEPT2 closed-loop codebase.

## 1. Fixed boundaries

The following are fixed for this package:

- pseudo reality system
- G_t / K_t observation contract
- H-DEPT formal input restriction: G_t / K_t only
- H11-local high-fidelity pressure reception
- non-compressed PressureIntentBundle
- ActionSurface as affordance map, not pressure compressor
- v8 as local support only

The modified area is:

- `action_module/actions.py`

## 2. Core design change

Previous action module behavior was too direct:

```text
planner route -> action_channel -> pseudo reality feature update
```

RC1 introduces an intermediate primitive layer:

```text
PressureIntentBundle
  + ActionSurface affordance
  + v8 local support
  + lower parameter state
    ↓
ActionPlanner
    ↓
ActuationPrimitive
    ↓
final gate
    ↓
ActionModule actuator
    ↓
PseudoReality
```

## 3. Primitive library

The RC1 primitive library is environment-specific:

- observe_only
- buffer_first
- coupling_relief_first
- staged_relation_unlock
- peripheral_explore
- exploration_cost_relief
- adoption_barrier_relief_guarded
- volatility_damp_first
- delayed_uncertainty_probe

## 4. Scenario-specific intent

### relation_lock

Direct exploration and direct unlock are treated as potentially disruptive.
The planner prefers:

- buffer_first
- coupling_relief_first
- observe_only under high v8 risk
- peripheral_explore only as a safer substitute

### shock

Immediate probing is treated as too early when volatility/unresolved signals are high.
The planner prefers:

- buffer_first
- volatility_damp_first
- delayed_uncertainty_probe only after local risk is moderate

### exploration_loss

Exploration is not collapsed into one action. The planner separates:

- exploration_cost_relief
- adoption_barrier_relief_guarded

The default bias is to restore attempts/cooldown first while keeping adoption conservative under conflict.

## 5. Non-compression rule

The primitive layer is the first allowed decision/compression point.
Before that:

- H-DEPT pressure component identity is preserved
- signed component direction is preserved
- semantic effect is annotated but not collapsed
- ActionSurface does not consume pressure intents

## 6. Safety and limits

This RC1 is not a performance proof. It is a design and stress-diagnostic package.

The actuator applies at most one selected primitive-derived action per entity per step. It does not directly mutate G_t or K_t; it only acts on the pseudo reality system.
