# Coupling Relief Staged Unlock Repair RC1

## 0. Position

`CouplingReliefStagedUnlockRepair_RC1` follows:

```text
ProbeRestraintPrimitivePatch_RC1
```

It repairs the sequence-level issue around:

```text
coupling_relief -> staged_unlock
```

## 1. Problem

This was not a coverage problem.  
The issue was that immediate unlock after coupling relief can be too coarse.

## 2. Repair

Compare variants:

```text
old_immediate_unlock:
  coupling_relief -> relation_unlock

relief_observe_only:
  coupling_relief -> observe

delayed_guarded_unlock:
  coupling_relief -> observe -> guarded_relation_unlock

buffered_delayed_guarded_unlock:
  buffer -> coupling_relief -> observe -> guarded_relation_unlock
```

## 3. Boundary

This task does not:

```text
- tune H-DEPT pressure
- change upper DEPT inputs
```

It only repairs the validation action sequence.

## 4. Outputs

```text
results/coupling_relief_staged_unlock_targets_RC1.csv
results/coupling_relief_staged_unlock_variant_alignment_RC1.csv
results/coupling_relief_staged_unlock_variant_summary_RC1.csv
results/coupling_relief_staged_unlock_repaired_policy_RC1.csv
results/coupling_relief_staged_unlock_prior_rc2_RC1.csv
results/coupling_relief_staged_unlock_repair_table_RC1.csv
results/coupling_relief_staged_unlock_repair_summary_RC1.json
```
