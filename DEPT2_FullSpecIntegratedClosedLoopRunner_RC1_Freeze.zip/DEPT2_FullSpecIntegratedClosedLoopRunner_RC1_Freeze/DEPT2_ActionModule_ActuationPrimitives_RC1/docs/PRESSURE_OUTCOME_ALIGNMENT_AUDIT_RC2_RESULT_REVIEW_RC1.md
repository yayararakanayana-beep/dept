# Pressure Outcome Alignment Audit RC2 Result Review RC1

## 0. Position

This document reviews **PressureOutcomeAlignmentAudit_RC2**.

It does not change the action module yet.  
Its purpose is to determine what RC2 actually tells us before moving to
validation-oriented action-module adjustment.

## 1. Corrected Point from RC1

RC1 compared:

```text
approved_* sign
vs
observed outcome
```

That was too crude.

RC2 corrected the main alignment basis to:

```text
semantic_effect / primitive_sequence
vs
observed outcome
```

Therefore the sign-simplification issue is considered fixed at the audit-design
level.

## 2. Main RC2 Result

```json
{
  "task": "PressureOutcomeAlignmentAudit_RC2_ResultReview_RC1",
  "status": "completed",
  "source_task": "PressureOutcomeAlignmentAudit_RC2",
  "semantic_alignment_rate": 0.4147727272727273,
  "primitive_alignment_rate": 0.42105263157894735,
  "semantic_to_plan_present_rate": 0.2840909090909091,
  "plan_to_action_present_rate": 0.09090909090909091,
  "primary_conclusion": "RC2 fixed the sign-only audit problem; the remaining blocker is semantic/action survival in the validation action module.",
  "dept_tuning_readiness": "not_ready_action_coverage_bottleneck",
  "main_bottleneck": "plan_to_action_coverage",
  "semantic_review_classes": {
    "missing_at_planning": 8,
    "actuated_but_weak_alignment": 3,
    "planned_but_not_actuated": 2,
    "usable_or_partly_usable": 1
  },
  "primitive_review_classes": {
    "acted_but_misaligned": 2,
    "partial_control": 1,
    "positive_control": 1
  },
  "top_recommendations": [
    {
      "priority": 1,
      "recommendation": "Create DiagnosticActionTranslationPolicy_RC1",
      "reason": "The validation module must preserve pressure meaning into weak diagnostic actions, not drop most semantic effects.",
      "implementation_hint": "Add alignment_probe / diagnostic_translation mode with per-semantic-family minimum plan and weak-action survival."
    },
    {
      "priority": 1,
      "recommendation": "Add explicit semantic drop-reason audit",
      "reason": "RC2 shows low survival but not exactly where each semantic effect drops.",
      "implementation_hint": "For each semantic_effect, record dropped_at: planner / final_gate / execution_policy / no_primitive / action_budget / scenario_guard."
    },
    {
      "priority": 2,
      "recommendation": "Add missing diagnostic primitive routes",
      "reason": "sandbox_probe_entry, update_frequency, update_access_opening, exploration_attempt are weak or absent.",
      "implementation_hint": "Introduce low-intensity probe primitives for sandbox/update/exploration families with trace IDs."
    },
    {
      "priority": 2,
      "recommendation": "Use buffer->replan as positive control",
      "reason": "It has the strongest primitive pass rate in RC2.",
      "implementation_hint": "Keep it as baseline to compare new diagnostic translation changes."
    }
  ],
  "all_sanity_checks_passed": true,
  "outputs": {
    "result_review": "pressure_outcome_alignment_rc2_result_review_RC1.csv",
    "semantic_review": "pressure_outcome_alignment_rc2_semantic_review_RC1.csv",
    "primitive_review": "pressure_outcome_alignment_rc2_primitive_review_RC1.csv",
    "next_actions": "pressure_outcome_alignment_rc2_next_actions_RC1.csv"
  }
}
```

## 3. Core Interpretation

RC2 does **not** show that DEPT pressure generation is wrong.

It shows:

```text
semantic effects are present,
but many do not survive into diagnostic action,
so pressure-outcome tuning is not yet observable enough.
```

In concrete values:

```text
semantic_alignment_rate = 0.415
primitive_alignment_rate = 0.421
semantic_to_plan_present_rate = 0.284
plan_to_action_present_rate = 0.091
```

The decisive blocker is:

```text
plan_to_action_present_rate = 0.091
```

That means only a small share of semantic effects reach actual action.

## 4. Semantic Review

```text
                   semantic_effect           intent_family  rows  mean_alignment_score  alignment_pass_rate  semantic_to_plan_present_rate  plan_to_action_present_rate  mean_action_mass                         dominant_verdict                review_class                                                   recommended_adjustment
            sandbox_probe_entry_up exploration_observation     8              0.041667             0.000000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned         missing_at_planning                        add diagnostic planning route / primitive mapping
               update_frequency_up          update_opening     8              0.041667             0.000000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned         missing_at_planning                        add diagnostic planning route / primitive mapping
             update_frequency_down        update_restraint     8              0.375000             0.125000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned         missing_at_planning                        add diagnostic planning route / primitive mapping
exploration_attempt_frequency_down   exploration_restraint     4              0.416667             0.250000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned         missing_at_planning                        add diagnostic planning route / primitive mapping
  exploration_attempt_frequency_up     exploration_attempt    12              0.250000             0.333333                         0.2500                       0.0000          0.000000          semantic_misaligned_not_planned    planned_but_not_actuated open validation-mode pass-through or inspect final gate/execution policy
          sandbox_probe_entry_down         probe_restraint     8              0.187500             0.375000                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned         missing_at_planning                        add diagnostic planning route / primitive mapping
             update_access_opening        temporal_opening    16              0.333333             0.437500                         0.0000                       0.0000          0.000000          semantic_misaligned_not_planned         missing_at_planning                        add diagnostic planning route / primitive mapping
           adoption_barrier_relief        adoption_opening    16              0.333333             0.437500                         0.0625                       0.0625          0.051576          semantic_misaligned_not_planned actuated_but_weak_alignment                      tune primitive expected-effect contract or sequence
               sensitivity_opening        response_opening    16              0.333333             0.437500                         1.0000                       0.0625          0.005435 semantic_misaligned_planned_not_actuated actuated_but_weak_alignment                      tune primitive expected-effect contract or sequence
             hysteresis_guard_down   switching_flexibility    16              0.416667             0.437500                         0.8125                       0.8125          1.095464       semantic_misaligned_despite_action actuated_but_weak_alignment                      tune primitive expected-effect contract or sequence
        diagnostic_resolution_down observation_cost_saving    16              0.416667             0.500000                         0.0000                       0.0000          0.000000        semantic_aligned_but_unattributed         missing_at_planning                        add diagnostic planning route / primitive mapping
               rollback_guard_down       safety_relaxation    16              0.416667             0.500000                         0.0000                       0.0000          0.000000        semantic_aligned_but_unattributed         missing_at_planning                        add diagnostic planning route / primitive mapping
          commitment_strength_down       commitment_relief    16              0.458333             0.500000                         0.0625                       0.0625          0.015553        semantic_aligned_but_unattributed     usable_or_partly_usable                             retain as reference; use as positive control
               intensity_cap_brake              safety_cap    16              0.604167             0.750000                         1.0000                       0.0000          0.000000    semantic_aligned_planned_not_actuated    planned_but_not_actuated open validation-mode pass-through or inspect final gate/execution policy
```

Important pattern:

```text
sandbox_probe_entry_up/down
update_frequency_up/down
update_access_opening
exploration_attempt_frequency_up/down
adoption_barrier_relief
```

are weak or under-carried.

These are exactly the exploratory / opening / probe families that need to remain
visible in a validation action module.

## 5. Primitive Review

```text
     action_primitive                         primitive_sequence  action_channel  rows  mean_alignment_score  alignment_pass_rate  total_action_rows  total_action_mass                    dominant_verdict         review_class                                      recommended_adjustment
coupling_relief_first           coupling_relief -> staged_unlock coupling_relief     4              0.083333             0.000000                 15           1.417449 primitive_misaligned_despite_action acted_but_misaligned do not increase pressure; fix sequence/effect mapping first
         buffer_first buffer -> coupling_relief -> staged_unlock buffer_increase     3              0.444444             0.333333                  4           0.450201 primitive_misaligned_despite_action acted_but_misaligned do not increase pressure; fix sequence/effect mapping first
coupling_relief_first                 coupling_relief -> observe coupling_relief     8              0.500000             0.500000                 92          12.612325 primitive_misaligned_despite_action      partial_control         inspect feature-level mismatch and target selection
         buffer_first                           buffer -> replan buffer_increase     4              0.583333             0.750000                 37           4.208477      primitive_aligned_and_actuated     positive_control                    retain and compare lower-budget variants
```

Main primitive-level finding:

```text
buffer -> replan:
  strongest positive control

coupling_relief -> staged_unlock:
  actuated but misaligned

coupling_relief -> observe:
  partial

buffer -> coupling_relief -> staged_unlock:
  weak / mixed
```

This means we should not simply increase pressure.  
We need to repair translation/sequence coverage first.

## 6. Scenario Coverage

```text
    run_scenario  semantic_chain_rows  unique_semantic_effects  semantic_to_plan_present_rate  plan_to_action_present_rate  total_planned_rows  total_action_rows  total_action_mass
exploration_loss                   76                       11                       0.526316                     0.065789               540.0               30.0           2.979848
          normal                   75                       11                       0.466667                     0.066667               540.0               90.0          13.523000
   relation_lock                   90                       11                       0.555556                     0.100000               540.0               30.0           3.069489
           shock                   65                       11                       0.384615                     0.076923               540.0               51.0           5.674122
```

All scenarios have low plan-to-action survival.

Even the best scenario does not yet provide enough coverage to tune DEPT pressure
from outcome feedback.

## 7. Review Conclusions

```text
1. RC2 successfully fixed the sign-only audit mistake.
2. The main remaining issue is not pressure sign semantics.
3. The bottleneck is semantic_effect → planned action → actual action survival.
4. The validation action module is currently too lossy for pressure-outcome tuning.
5. DEPT-side pressure tuning should remain frozen.
6. The next change should be a validation-oriented action translation policy.
```

## 8. Next Recommended Task

```text
DiagnosticActionTranslationPolicy_RC1
```

Purpose:

```text
Make the validation action module preserve pressure meaning into weak,
traceable diagnostic actions.
```

Required changes:

```text
- Add alignment_probe / diagnostic_translation mode.
- Guarantee minimum semantic-family survival into plan.
- Guarantee weak-action pass-through for each major semantic family.
- Add explicit drop-reason table.
- Add missing diagnostic primitive routes for sandbox/update/exploration families.
- Use buffer->replan as positive control.
- Repair coupling_relief->staged_unlock separately.
```

## 9. Boundary

Do not tune H-DEPT pressure weights yet.

Reason:

```text
The observation device now reads semantic/primitive alignment correctly,
but the action module does not yet pass enough semantic effects into actual action.
```

The next work should adjust the validation action module, not DEPT pressure.
