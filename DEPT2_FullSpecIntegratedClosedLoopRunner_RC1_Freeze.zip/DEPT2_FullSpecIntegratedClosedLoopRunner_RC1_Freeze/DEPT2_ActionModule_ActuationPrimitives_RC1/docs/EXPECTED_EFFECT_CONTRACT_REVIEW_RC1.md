# Expected Effect Contract Review RC1

## 0. Position

`ExpectedEffectContractReview_RC1` follows:

```text
DiagnosticPrimitiveMappingRepair_RC1
```

It reviews whether some semantic effects were failing because their expected
outcome contracts were wrong or too coarse.

## 1. Review Targets

```text
diagnostic_resolution_down
rollback_guard_down
sandbox_probe_entry_down
hysteresis_guard_down
update_access_opening
update_frequency_up
```

## 2. Boundary

This task does not:

```text
- tune H-DEPT pressure
- change primitive mappings
- repair coupling_relief->staged_unlock
- freeze the candidate contracts
```

It only proposes diagnostic expected-effect contract candidates.

## 3. Outputs

```text
results/expected_effect_contract_review_table_RC1.csv
results/expected_effect_contract_feature_evidence_RC1.csv
results/expected_effect_contract_candidate_contracts_RC1.csv
results/expected_effect_contract_class_summary_RC1.csv
results/expected_effect_contract_next_action_plan_RC1.csv
results/expected_effect_contract_review_summary_RC1.json
```

## 4. Next

The natural next step is:

```text
ExpectedEffectContractPatch_RC1
```

which would freeze candidate diagnostic contracts and rerun alignment.
