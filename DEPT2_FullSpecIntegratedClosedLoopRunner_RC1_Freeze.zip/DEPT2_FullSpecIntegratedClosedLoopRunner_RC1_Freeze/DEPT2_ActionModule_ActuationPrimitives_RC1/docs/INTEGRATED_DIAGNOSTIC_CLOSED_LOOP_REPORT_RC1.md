# Integrated Diagnostic Closed Loop Report RC1

## 0. Position

This report records **IntegratedDiagnosticClosedLoop_RC1**.

It is the first fresh end-to-end run after the diagnostic action-module repair chain.

The executed chain was:

```text
DEPT core
-> pressure semantic
-> repaired diagnostic action policy
-> pseudo-reality
-> fresh outcome trace
```

This is not a replay of old stored outcomes.

## 1. Boundary

This task does not tune H-DEPT pressure.

Formal upper input remains:

```text
G_t global + K_t global only
```

The repaired diagnostic action policy is validation-only.

## 2. Execution Summary

```json
{
  "task": "IntegratedDiagnosticClosedLoop_RC1",
  "status": "completed",
  "steps_per_run": 8,
  "run_count": 4,
  "metric_rows": 32,
  "action_rows": 4664,
  "unique_semantic_effects": 15,
  "sequence_event_rows": 1320,
  "isolated_outcome_rows": 368,
  "isolated_alignment_pass_rate": 1.0,
  "isolated_mean_alignment_score": 1.0,
  "combined_mean_pass_rate": 0.8958333333333334,
  "mean_action_rows_per_step": 145.75,
  "mean_action_mass_per_step": 1.2183992931212855,
  "mean_delta_conflict": -0.001838374669720885,
  "mean_delta_uncertainty": -0.0019147815655435833,
  "mean_delta_exploration": 0.0030453005026720896,
  "mean_delta_overconvergence": -0.004451896698097103,
  "mean_delta_m_overall": 0.009095013941251121,
  "weakest_semantic_effects": [
    {
      "semantic_effect": "adoption_barrier_relief",
      "intent_family": "adoption_opening",
      "rows": 32,
      "action_rows": 352,
      "mean_action_mass": 0.10477499999999998,
      "action_primitives": "diagnostic_adoption_opening_probe",
      "action_channels": "exploration_injection",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": 9.822656250001865e-06,
      "mean_delta_uncertainty": 3.929062499999185e-05,
      "mean_delta_exploration": 0.0002604374999999985,
      "mean_delta_overconvergence": -0.00018260624999999193,
      "mean_delta_m_overall": 0.0003553898437499252,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "commitment_strength_down",
      "intent_family": "commitment_relief",
      "rows": 32,
      "action_rows": 660,
      "mean_action_mass": 0.16780126478687193,
      "action_primitives": "diagnostic_coupling_relief_then_guarded_unlock|diagnostic_coupling_relief_then_guarded_unlock|guarded_relation_unlock",
      "action_channels": "coupling_relief|coupling_relief|guarded_relation_unlock",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": -0.0001540592507232319,
      "mean_delta_uncertainty": -3.1829672161995046e-05,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -0.00029220366536544763,
      "mean_delta_m_overall": 0.00020976117700670718,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "diagnostic_resolution_down",
      "intent_family": "observation_cost_saving",
      "rows": 32,
      "action_rows": 352,
      "mean_action_mass": 0.10270437538710671,
      "action_primitives": "diagnostic_observation_saving_probe",
      "action_channels": "uncertainty_probe",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": -3.530462903929624e-05,
      "mean_delta_uncertainty": -0.00014121851615727168,
      "mean_delta_exploration": 5.075218769355757e-05,
      "mean_delta_overconvergence": -2.5376093846777486e-05,
      "mean_delta_m_overall": 8.605681673279006e-05,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_down",
      "intent_family": "exploration_restraint",
      "rows": 8,
      "action_rows": 88,
      "mean_action_mass": 0.066,
      "action_primitives": "diagnostic_exploration_restraint_v2",
      "action_channels": "diagnostic_exploration_restraint",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": -1.4437500000005765e-05,
      "mean_delta_uncertainty": -7.424999999998405e-05,
      "mean_delta_exploration": -0.00016499999999997073,
      "mean_delta_overconvergence": 0.00011550000000000882,
      "mean_delta_m_overall": -0.00020006250000001446,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_up",
      "intent_family": "exploration_attempt",
      "rows": 24,
      "action_rows": 264,
      "mean_action_mass": 0.0853211804415438,
      "action_primitives": "diagnostic_exploration_attempt",
      "action_channels": "exploration_injection",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": 7.998860666422192e-06,
      "mean_delta_uncertainty": 3.199544266558931e-05,
      "mean_delta_exploration": 0.0002113029511038612,
      "mean_delta_overconvergence": -0.00014831206577269976,
      "mean_delta_m_overall": 0.0002886252708788987,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "hysteresis_guard_down",
      "intent_family": "switching_flexibility",
      "rows": 32,
      "action_rows": 660,
      "mean_action_mass": 0.16751691602880595,
      "action_primitives": "diagnostic_coupling_relief_then_guarded_unlock|diagnostic_coupling_relief_then_guarded_unlock|guarded_relation_unlock",
      "action_channels": "coupling_relief|coupling_relief|guarded_relation_unlock",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": -0.0001537979007617818,
      "mean_delta_uncertainty": -3.177112977063336e-05,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -0.0002917102366382289,
      "mean_delta_m_overall": 0.00020939737786036458,
      "dominant_verdict": "integrated_semantic_aligned"
    }
  ],
  "strongest_semantic_effects": [
    {
      "semantic_effect": "adoption_barrier_relief",
      "intent_family": "adoption_opening",
      "rows": 32,
      "action_rows": 352,
      "mean_action_mass": 0.10477499999999998,
      "action_primitives": "diagnostic_adoption_opening_probe",
      "action_channels": "exploration_injection",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": 9.822656250001865e-06,
      "mean_delta_uncertainty": 3.929062499999185e-05,
      "mean_delta_exploration": 0.0002604374999999985,
      "mean_delta_overconvergence": -0.00018260624999999193,
      "mean_delta_m_overall": 0.0003553898437499252,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "commitment_strength_down",
      "intent_family": "commitment_relief",
      "rows": 32,
      "action_rows": 660,
      "mean_action_mass": 0.16780126478687193,
      "action_primitives": "diagnostic_coupling_relief_then_guarded_unlock|diagnostic_coupling_relief_then_guarded_unlock|guarded_relation_unlock",
      "action_channels": "coupling_relief|coupling_relief|guarded_relation_unlock",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": -0.0001540592507232319,
      "mean_delta_uncertainty": -3.1829672161995046e-05,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -0.00029220366536544763,
      "mean_delta_m_overall": 0.00020976117700670718,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "diagnostic_resolution_down",
      "intent_family": "observation_cost_saving",
      "rows": 32,
      "action_rows": 352,
      "mean_action_mass": 0.10270437538710671,
      "action_primitives": "diagnostic_observation_saving_probe",
      "action_channels": "uncertainty_probe",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": -3.530462903929624e-05,
      "mean_delta_uncertainty": -0.00014121851615727168,
      "mean_delta_exploration": 5.075218769355757e-05,
      "mean_delta_overconvergence": -2.5376093846777486e-05,
      "mean_delta_m_overall": 8.605681673279006e-05,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_down",
      "intent_family": "exploration_restraint",
      "rows": 8,
      "action_rows": 88,
      "mean_action_mass": 0.066,
      "action_primitives": "diagnostic_exploration_restraint_v2",
      "action_channels": "diagnostic_exploration_restraint",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": -1.4437500000005765e-05,
      "mean_delta_uncertainty": -7.424999999998405e-05,
      "mean_delta_exploration": -0.00016499999999997073,
      "mean_delta_overconvergence": 0.00011550000000000882,
      "mean_delta_m_overall": -0.00020006250000001446,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "exploration_attempt_frequency_up",
      "intent_family": "exploration_attempt",
      "rows": 24,
      "action_rows": 264,
      "mean_action_mass": 0.0853211804415438,
      "action_primitives": "diagnostic_exploration_attempt",
      "action_channels": "exploration_injection",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": 7.998860666422192e-06,
      "mean_delta_uncertainty": 3.199544266558931e-05,
      "mean_delta_exploration": 0.0002113029511038612,
      "mean_delta_overconvergence": -0.00014831206577269976,
      "mean_delta_m_overall": 0.0002886252708788987,
      "dominant_verdict": "integrated_semantic_aligned"
    },
    {
      "semantic_effect": "hysteresis_guard_down",
      "intent_family": "switching_flexibility",
      "rows": 32,
      "action_rows": 660,
      "mean_action_mass": 0.16751691602880595,
      "action_primitives": "diagnostic_coupling_relief_then_guarded_unlock|diagnostic_coupling_relief_then_guarded_unlock|guarded_relation_unlock",
      "action_channels": "coupling_relief|coupling_relief|guarded_relation_unlock",
      "mean_alignment_score": 1.0,
      "alignment_pass_rate": 1.0,
      "mean_delta_conflict": -0.0001537979007617818,
      "mean_delta_uncertainty": -3.177112977063336e-05,
      "mean_delta_exploration": 0.0,
      "mean_delta_overconvergence": -0.0002917102366382289,
      "mean_delta_m_overall": 0.00020939737786036458,
      "dominant_verdict": "integrated_semantic_aligned"
    }
  ],
  "pressure_tuning_readiness": "not_ready_rc3_audit_required",
  "next_recommended_task": "PressureOutcomeAlignmentAudit_RC3",
  "all_sanity_checks_passed": true,
  "outputs": {
    "gt_global": "integrated_diagnostic_gt_global_RC1.csv",
    "kt_global": "integrated_diagnostic_kt_global_RC1.csv",
    "formal_gtkt_packets": "integrated_diagnostic_formal_gtkt_packets_RC1.csv",
    "m_observation": "integrated_diagnostic_m_observation_RC1.csv",
    "pressure_candidates": "integrated_diagnostic_pressure_candidates_RC1.csv",
    "h11_local_pressure_field": "integrated_diagnostic_h11_local_pressure_field_RC1.csv",
    "pressure_intent_bundle": "integrated_diagnostic_pressure_intent_bundle_RC1.csv",
    "parameter_registry": "integrated_diagnostic_parameter_registry_RC1.csv",
    "parameter_updates": "integrated_diagnostic_parameter_updates_RC1.csv",
    "graph_objects_audit": "integrated_diagnostic_graph_objects_audit_RC1.csv",
    "action_surface_affordance": "integrated_diagnostic_action_surface_affordance_RC1.csv",
    "v8_affordance_support": "integrated_diagnostic_v8_affordance_support_RC1.csv",
    "final_gate_audit": "integrated_diagnostic_final_gate_audit_RC1.csv",
    "integrated_action_frame": "integrated_diagnostic_action_frame_RC1.csv",
    "integrated_sequence_events": "integrated_diagnostic_sequence_events_RC1.csv",
    "integrated_combined_outcomes": "integrated_diagnostic_combined_outcomes_RC1.csv",
    "integrated_isolated_semantic_outcomes": "integrated_diagnostic_isolated_semantic_outcomes_RC1.csv",
    "integrated_loop_metrics": "integrated_diagnostic_loop_metrics_RC1.csv",
    "semantic_summary": "integrated_diagnostic_semantic_summary_RC1.csv"
  }
}
```

Focused test status:

```text
test_integrated_diagnostic_closed_loop.py: 4 passed
```

## 3. Scenario Summary

```text
    run_scenario  steps  mean_action_rows  mean_action_mass  mean_isolated_pass_rate  mean_combined_pass_rate  mean_delta_conflict  mean_delta_uncertainty  mean_delta_exploration  mean_delta_overconvergence  mean_delta_m_overall
exploration_loss      8            140.25          1.224407                      1.0                 1.000000            -0.001822               -0.001668                0.004585                   -0.005667              0.010881
          normal      8            151.25          1.242419                      1.0                 0.750000            -0.001945               -0.002428                0.000719                   -0.002775              0.006452
   relation_lock      8            140.25          1.185538                      1.0                 1.000000            -0.001775               -0.001650                0.004646                   -0.005570              0.010754
           shock      8            151.25          1.221233                      1.0                 0.833333            -0.001811               -0.001913                0.002232                   -0.003796              0.008293
```

## 4. Semantic Summary

```text
                       semantic_effect           intent_family  rows  action_rows  mean_action_mass                                                                                                     action_primitives                                         action_channels  mean_alignment_score  alignment_pass_rate  mean_delta_conflict  mean_delta_uncertainty  mean_delta_exploration  mean_delta_overconvergence  mean_delta_m_overall            dominant_verdict
               adoption_barrier_relief        adoption_opening    32          352          0.104775                                                                                     diagnostic_adoption_opening_probe                                   exploration_injection                   1.0                  1.0             0.000010                0.000039                0.000260                   -0.000183              0.000355 integrated_semantic_aligned
              commitment_strength_down       commitment_relief    32          660          0.167801 diagnostic_coupling_relief_then_guarded_unlock|diagnostic_coupling_relief_then_guarded_unlock|guarded_relation_unlock coupling_relief|coupling_relief|guarded_relation_unlock                   1.0                  1.0            -0.000154               -0.000032                0.000000                   -0.000292              0.000210 integrated_semantic_aligned
            diagnostic_resolution_down observation_cost_saving    32          352          0.102704                                                                                   diagnostic_observation_saving_probe                                       uncertainty_probe                   1.0                  1.0            -0.000035               -0.000141                0.000051                   -0.000025              0.000086 integrated_semantic_aligned
    exploration_attempt_frequency_down   exploration_restraint     8           88          0.066000                                                                                   diagnostic_exploration_restraint_v2                        diagnostic_exploration_restraint                   1.0                  1.0            -0.000014               -0.000074               -0.000165                    0.000116             -0.000200 integrated_semantic_aligned
      exploration_attempt_frequency_up     exploration_attempt    24          264          0.085321                                                                                        diagnostic_exploration_attempt                                   exploration_injection                   1.0                  1.0             0.000008                0.000032                0.000211                   -0.000148              0.000289 integrated_semantic_aligned
                 hysteresis_guard_down   switching_flexibility    32          660          0.167517 diagnostic_coupling_relief_then_guarded_unlock|diagnostic_coupling_relief_then_guarded_unlock|guarded_relation_unlock coupling_relief|coupling_relief|guarded_relation_unlock                   1.0                  1.0            -0.000154               -0.000032                0.000000                   -0.000292              0.000209 integrated_semantic_aligned
                   intensity_cap_brake              safety_cap    32          352          0.104775                                                                                                          buffer_first                                         buffer_increase                   1.0                  1.0            -0.000026               -0.000039                0.000000                    0.000000              0.000288 integrated_semantic_aligned
                   rollback_guard_down       safety_relaxation    32          352          0.103088                                                                                  diagnostic_rollback_relaxation_probe                                         buffer_increase                   1.0                  1.0            -0.000026               -0.000039                0.000000                    0.000000              0.000283 integrated_semantic_aligned
              sandbox_probe_entry_down         probe_restraint    16          176          0.066627                                                                                  diagnostic_probe_restraint_direct_v1                       diagnostic_probe_restraint_direct                   1.0                  1.0             0.000023                0.000017               -0.000167                    0.000150             -0.000248 integrated_semantic_aligned
sandbox_probe_entry_down_stabilization     stabilization_guard    16          176          0.066627                                                                        diagnostic_probe_restraint_stabilization_guard                                         buffer_increase                   1.0                  1.0            -0.000017               -0.000025                0.000000                    0.000000              0.000183 integrated_semantic_aligned
                sandbox_probe_entry_up exploration_observation    16          176          0.078361                                                                                              diagnostic_sandbox_probe                                   exploration_injection                   1.0                  1.0             0.000007                0.000029                0.000193                   -0.000136              0.000264 integrated_semantic_aligned
                   sensitivity_opening        response_opening    32          352          0.104616                                                                               diagnostic_sensitivity_opening_probe_v2                                   exploration_injection                   1.0                  1.0             0.000010                0.000039                0.000260                   -0.000182              0.000355 integrated_semantic_aligned
                 update_access_opening        temporal_opening    32          352          0.104775                                                                                        diagnostic_update_access_probe                                       uncertainty_probe                   1.0                  1.0            -0.000036               -0.000144                0.000052                   -0.000026              0.000088 integrated_semantic_aligned
                 update_frequency_down        update_restraint    16          176          0.071097                                                                                        diagnostic_update_restraint_v2                             diagnostic_update_restraint                   1.0                  1.0            -0.000025               -0.000116               -0.000133                    0.000096             -0.000152 integrated_semantic_aligned
                   update_frequency_up          update_opening    16          176          0.073002                                                                                     diagnostic_update_frequency_probe                                       uncertainty_probe                   1.0                  1.0            -0.000025               -0.000100                0.000036                   -0.000018              0.000061 integrated_semantic_aligned
```

## 5. Sequence Events

```text
                      event_type  rows  sequence_ids  mean_action_strength
 execute_guarded_relation_unlock   616           154              0.006608
schedule_guarded_relation_unlock   704           176              0.006622
```

## 6. Action Role / Channel Summary

```text
                       semantic_effect                    action_channel  rows  mean_strength  total_mass
               adoption_barrier_relief             exploration_injection   352       0.009525    3.352800
              commitment_strength_down                   coupling_relief   352       0.009467    3.332541
            diagnostic_resolution_down                 uncertainty_probe   352       0.009337    3.286540
                   intensity_cap_brake                   buffer_increase   352       0.009525    3.352800
                 hysteresis_guard_down                   coupling_relief   352       0.009452    3.327189
                   sensitivity_opening             exploration_injection   352       0.009511    3.347699
                 update_access_opening                 uncertainty_probe   352       0.009525    3.352800
                   rollback_guard_down                   buffer_increase   352       0.009372    3.298831
                 hysteresis_guard_down           guarded_relation_unlock   308       0.006602    2.033352
              commitment_strength_down           guarded_relation_unlock   308       0.006614    2.037099
      exploration_attempt_frequency_up             exploration_injection   264       0.007756    2.047708
                sandbox_probe_entry_up             exploration_injection   176       0.007124    1.253769
              sandbox_probe_entry_down diagnostic_probe_restraint_direct   176       0.006057    1.066033
                 update_frequency_down       diagnostic_update_restraint   176       0.006463    1.137551
sandbox_probe_entry_down_stabilization                   buffer_increase   176       0.006057    1.066033
                   update_frequency_up                 uncertainty_probe   176       0.006637    1.168031
    exploration_attempt_frequency_down  diagnostic_exploration_restraint    88       0.006000    0.528000
```

## 7. Main Result

Fresh end-to-end execution succeeded.

```text
run_count = 4
metric_rows = 32
action_rows = 4664
unique_semantic_effects = 15
sequence_event_rows = 1320
isolated_outcome_rows = 368
```

The isolated semantic shadow audit is strong:

```text
isolated_alignment_pass_rate = 1.000
isolated_mean_alignment_score = 1.000
```

The combined step outcome is intentionally more mixed:

```text
combined_mean_pass_rate = 0.896
```

This distinction is important.  
Isolated semantic shadow confirms that each repaired semantic/action route works
when evaluated against its own expected-effect contract.  
Combined outcome is a many-action aggregate and should be interpreted by RC3.

## 8. Confirmed Repairs in Fresh Loop

```text
probe-restraint split:
  sandbox_probe_entry_down
  sandbox_probe_entry_down_stabilization

guarded delayed unlock:
  schedule_guarded_relation_unlock
  execute_guarded_relation_unlock

mapping repairs:
  diagnostic_exploration_restraint
  diagnostic_update_restraint
  exploration_injection for sensitivity/opening semantics

contract patch:
  patched diagnostic contracts used for semantic outcome scoring
```

## 9. Remaining Boundary

Even though this fresh loop passes sanity checks:

```text
all_sanity_checks_passed = True
```

H-DEPT pressure tuning is still not ready.

Reason:

```text
This task creates fresh traces.
The next task must audit those traces with RC3 before tuning pressure generation.
```

## 10. Next Recommended Task

```text
PressureOutcomeAlignmentAudit_RC3
```

Purpose:

```text
Use the fresh IntegratedDiagnosticClosedLoop_RC1 outputs to audit:

approved pressure component
-> component direction
-> semantic_effect
-> repaired diagnostic primitive
-> action channel
-> expected-effect contract
-> observed outcome
```
