# Pressure Sign Semantics Audit RC1

## 0. Position

`PressureSignSemanticsAudit_RC1` is Task A after
`PressureOutcomeAlignmentAudit_RC1`.

The previous alignment audit showed that directly comparing:

```text
approved pressure sign
vs
observed outcome direction
```

is unsafe.

This audit separates the chain:

```text
approved pressure component + sign
→ semantic_effect
→ translated primitive / sequence
→ actual action channel
→ observed outcome
```

## 1. Purpose

The purpose is not to tune DEPT.

The purpose is to determine where apparent pressure/outcome mismatch arises:

```text
pressure sign convention?
semantic effect mapping?
planner primitive mapping?
ActionModule selection?
expected outcome map?
pseudo-reality response?
```

## 2. Outputs

```text
results/pressure_sign_component_table_RC1.csv
results/pressure_sign_semantic_chain_RC1.csv
results/pressure_semantic_plan_action_chain_RC1.csv
results/pressure_semantic_outcome_alignment_RC1.csv
results/pressure_primitive_outcome_alignment_RC1.csv
results/pressure_sign_component_summary_RC1.csv
results/pressure_semantic_outcome_summary_RC1.csv
results/pressure_primitive_outcome_summary_RC1.csv
results/pressure_outcome_increment_table_RC1.csv
results/pressure_sign_semantics_audit_summary_RC1.json
```

## 3. Tables

### pressure_sign_component_table

Shows:

```text
approved component
approved value
component direction
semantic effect expected from sign contract
intent family
suggested route
```

### pressure_sign_semantic_chain

Checks whether the component sign contract matches
`PressureIntentBundle`.

This verifies:

```text
approved_* sign
→ semantic_effect
```

### pressure_semantic_plan_action_chain

Checks whether semantic effects enter planner/action:

```text
semantic_effect
→ planned primitive / sequence
→ actual ActionModule frame
```

### pressure_semantic_outcome_alignment

Compares semantic effect expected outcomes against next-step observed outcome.

### pressure_primitive_outcome_alignment

Compares primitive expected outcomes against next-step observed outcome.

## 4. Interpretation

If sign-to-intent match is high:

```text
pressure_intent annotation is respecting the sign contract
```

If semantic-to-plan/action is low:

```text
planner/action selection may be losing that semantic effect
```

If semantic outcome is poor but primitive outcome is better:

```text
pressure sign semantics may be indirect, but action primitives are working
```

If both semantic and primitive outcome are poor:

```text
translation/action mapping or pseudo-reality coupling should be audited
```

## 5. Next Step

After this audit, the next natural task is:

```text
PressureOutcomeAlignmentAudit_RC2
```

RC2 should use:

```text
semantic_effect alignment
primitive/sequence alignment
component-sign alignment only as secondary diagnostic
```
