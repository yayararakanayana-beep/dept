# CODEBASE_CONTRACT_RC1

## Purpose

Fix the validation premise before serious closed-loop experiments.

The package separates three zones:

1. **Pseudo reality system**
   - owns synthetic world state and dynamics.
   - may be changed to create test worlds and stress scenarios.
   - receives interventions from the action module.

2. **DEPT2/H-DEPT integrated system**
   - receives only trace-derived G_t/K_t_global as formal upper input.
   - contains H-DEPT-compatible observation, H11-local pressure reception, ActionSurface, v8 support, final gate, and lower parameter governance box.
   - should remain stable while pseudo reality and action module are varied.

3. **Action module**
   - maps final gated action candidates to pseudo reality interventions.
   - may be changed during validation to test how interventions affect the world.

## Formal upper input rule

H-DEPT-compatible observer may only consume:

- G_t global features
- K_t global features

It must not consume:

- GraphObject columns
- v8 columns
- final gate columns
- ActionSurface columns
- action module columns

This is enforced in `HDEPTObserver.validate_formal_input` and `GtKtBuilder.build_formal_packet`.

## H11-local rule

H11-local is a pressure reception surface, not the action compression layer.

- It receives upper pressure in high-fidelity H11 dimension x pressure component form.
- It does not collapse pressure into `explore/unlock/derisk` or action channels.
- ActionSurface performs the first action-oriented compression.

## Lower parameter governance rule

Lower Parameter Governance Box is registry-limited.
Only registered parameters can move. Each parameter has:

- theta0 reference value
- min/max safety bounds
- max step delta
- resistance to theta0
- primary H11 dimensions
- primary pressure components

RC1 uses hand-designed pseudo functions. They are hypotheses to test, not learned policies.

## Action rule

Action module must not directly mutate G_t or K_t.
It acts on pseudo reality. New G/K must be rebuilt from the next emitted trace.
