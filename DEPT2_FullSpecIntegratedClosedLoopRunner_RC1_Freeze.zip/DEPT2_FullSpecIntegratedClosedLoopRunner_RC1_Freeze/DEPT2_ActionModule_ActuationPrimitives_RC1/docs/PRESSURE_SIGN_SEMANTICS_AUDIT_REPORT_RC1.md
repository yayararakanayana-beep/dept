# Pressure Sign Semantics Audit Report RC1

## 0. Position

This report records **PressureSignSemanticsAudit_RC1**.

This is Task A after the pressure/outcome alignment concern.

The purpose is not to tune DEPT.  
The purpose is to split the meaning chain:

```text
approved pressure sign
→ semantic_effect
→ translated primitive / sequence
→ actual action channel
→ observed outcome
```

This is the missing layer before any DEPT-side pressure tuning.

## 1. Execution Summary

```json
{
  "task": "PressureSignSemanticsAudit_RC1",
  "status": "completed",
  "sign_semantic_chain_rows": 220,
  "semantic_plan_action_chain_rows": 306,
  "semantic_outcome_rows": 176,
  "primitive_outcome_rows": 19,
  "sign_to_intent_match_rate": 1.0,
  "semantic_to_plan_present_rate": 0.49019607843137253,
  "plan_to_action_present_rate": 0.0784313725490196,
  "mean_semantic_outcome_match_rate": 0.35700757575757575,
  "semantic_aligned_rate": 0.4147727272727273,
  "mean_primitive_outcome_match_rate": 0.42105263157894735,
  "primitive_aligned_rate": 0.42105263157894735,
  "dominant_semantic_outcome_verdicts": {
    "semantic_misaligned": 103,
    "semantic_aligned": 73
  },
  "dominant_primitive_outcome_verdicts": {
    "primitive_misaligned": 11,
    "primitive_aligned": 8
  },
  "worst_semantic_effects": [
    {
      "pressure_component": "sandbox_entry_rate",
      "component_direction": "increase",
      "semantic_effect": "sandbox_probe_entry_up",
      "rows": 8,
      "mean_match_rate": 0.041666666666666664,
      "aligned_rows": 0,
      "misaligned_rows": 8,
      "dominant_verdict": "semantic_misaligned"
    },
    {
      "pressure_component": "update_frequency",
      "component_direction": "increase",
      "semantic_effect": "update_frequency_up",
      "rows": 8,
      "mean_match_rate": 0.041666666666666664,
      "aligned_rows": 0,
      "misaligned_rows": 8,
      "dominant_verdict": "semantic_misaligned"
    },
    {
      "pressure_component": "sandbox_entry_rate",
      "component_direction": "decrease",
      "semantic_effect": "sandbox_probe_entry_down",
      "rows": 8,
      "mean_match_rate": 0.1875,
      "aligned_rows": 3,
      "misaligned_rows": 5,
      "dominant_verdict": "semantic_misaligned"
    },
    {
      "pressure_component": "exploration_frequency",
      "component_direction": "increase",
      "semantic_effect": "exploration_attempt_frequency_up",
      "rows": 12,
      "mean_match_rate": 0.25,
      "aligned_rows": 4,
      "misaligned_rows": 8,
      "dominant_verdict": "semantic_misaligned"
    },
    {
      "pressure_component": "adoption_threshold",
      "component_direction": "decrease",
      "semantic_effect": "adoption_barrier_relief",
      "rows": 16,
      "mean_match_rate": 0.3333333333333333,
      "aligned_rows": 7,
      "misaligned_rows": 9,
      "dominant_verdict": "semantic_misaligned"
    },
    {
      "pressure_component": "cooldown_length",
      "component_direction": "decrease",
      "semantic_effect": "update_access_opening",
      "rows": 16,
      "mean_match_rate": 0.3333333333333333,
      "aligned_rows": 7,
      "misaligned_rows": 9,
      "dominant_verdict": "semantic_misaligned"
    },
    {
      "pressure_component": "deadzone_width",
      "component_direction": "decrease",
      "semantic_effect": "sensitivity_opening",
      "rows": 16,
      "mean_match_rate": 0.3333333333333333,
      "aligned_rows": 7,
      "misaligned_rows": 9,
      "dominant_verdict": "semantic_misaligned"
    },
    {
      "pressure_component": "update_frequency",
      "component_direction": "decrease",
      "semantic_effect": "update_frequency_down",
      "rows": 8,
      "mean_match_rate": 0.375,
      "aligned_rows": 1,
      "misaligned_rows": 7,
      "dominant_verdict": "semantic_misaligned"
    }
  ],
  "worst_primitives": [
    {
      "action_primitive": "coupling_relief_first",
      "action_channel": "coupling_relief",
      "rows": 12,
      "total_action_rows": 107,
      "mean_action_mass": 1.1691478397191977,
      "mean_match_rate": 0.3611111111111111,
      "aligned_rows": 4,
      "misaligned_rows": 8,
      "dominant_verdict": "primitive_misaligned"
    },
    {
      "action_primitive": "buffer_first",
      "action_channel": "buffer_increase",
      "rows": 7,
      "total_action_rows": 41,
      "mean_action_mass": 0.6655253931814543,
      "mean_match_rate": 0.5238095238095238,
      "aligned_rows": 4,
      "misaligned_rows": 3,
      "dominant_verdict": "primitive_aligned"
    }
  ],
  "all_sanity_checks_passed": true,
  "audit_interpretation": "primary purpose is chain visibility, not DEPT tuning",
  "results_dir": "/mnt/data/task_a_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "pressure_sign_component_table": "pressure_sign_component_table_RC1.csv",
    "pressure_sign_semantic_chain": "pressure_sign_semantic_chain_RC1.csv",
    "pressure_semantic_plan_action_chain": "pressure_semantic_plan_action_chain_RC1.csv",
    "pressure_semantic_outcome_alignment": "pressure_semantic_outcome_alignment_RC1.csv",
    "pressure_primitive_outcome_alignment": "pressure_primitive_outcome_alignment_RC1.csv",
    "pressure_sign_component_summary": "pressure_sign_component_summary_RC1.csv",
    "pressure_semantic_outcome_summary": "pressure_semantic_outcome_summary_RC1.csv",
    "pressure_primitive_outcome_summary": "pressure_primitive_outcome_summary_RC1.csv",
    "pressure_outcome_increment_table": "pressure_outcome_increment_table_RC1.csv"
  },
  "note": "This audit separates pressure sign, semantic effect, primitive/action, and outcome. It does not tune DEPT."
}
```

Task-specific test status:

```text
test_pressure_sign_semantics_audit.py: 3 passed
```

## 2. Main Finding

The first link is clean:

```text
sign_to_intent_match_rate = 1.000
```

This means:

```text
approved_* sign
→ PressureIntentBundle semantic_effect
```

is consistent with the declared sign/semantic contract.

So the immediate problem is probably **not** that the pressure-intent annotator
is randomly flipping signs.

## 3. Where Loss Appears

The weak links are later:

```text
semantic_to_plan_present_rate = 0.490
plan_to_action_present_rate = 0.078
```

Interpretation:

```text
Many semantic effects exist in PressureIntentBundle,
but only part of them become dominant planned primitives,
and a much smaller part becomes actual ActionModule action.
```

This is expected to some degree because the planner compresses and selects.
But it means direct pressure-sign vs outcome comparison is too crude.

## 4. Outcome Alignment

Semantic-effect outcome alignment:

```text
mean_semantic_outcome_match_rate = 0.357
semantic_aligned_rate = 0.415
```

Primitive outcome alignment:

```text
mean_primitive_outcome_match_rate = 0.421
primitive_aligned_rate = 0.421
```

This is mixed, not cleanly aligned.

The important point:

```text
The pressure sign itself maps correctly to semantic labels,
but semantic labels do not reliably survive as executed action-outcome effects.
```

## 5. Component Sign Summary

```text
   pressure_component component_direction_from_sign semantic_effect_from_sign_contract  rows  sign_to_intent_match_rate  mean_approved_value  intent_rows
   adoption_threshold                      decrease            adoption_barrier_relief    20                        1.0            -0.079000          220
  commitment_strength                      decrease           commitment_strength_down    20                        1.0            -0.078233          220
      cooldown_length                      decrease              update_access_opening    20                        1.0            -0.079000          220
       deadzone_width                      decrease                sensitivity_opening    20                        1.0            -0.078807          220
     diagnostic_depth                      decrease         diagnostic_resolution_down    20                        1.0            -0.076490          220
exploration_frequency                      decrease exploration_attempt_frequency_down     5                        1.0            -0.007294           55
exploration_frequency                      increase   exploration_attempt_frequency_up    15                        1.0             0.046702          165
  hysteresis_strength                      decrease              hysteresis_guard_down    20                        1.0            -0.078030          220
         pressure_cap                      decrease                intensity_cap_brake    20                        1.0            -0.079000          220
 rollback_sensitivity                      decrease                rollback_guard_down    20                        1.0            -0.076956          220
   sandbox_entry_rate                      decrease           sandbox_probe_entry_down    10                        1.0            -0.026171          110
   sandbox_entry_rate                      increase             sandbox_probe_entry_up    10                        1.0             0.039718          110
     update_frequency                      decrease              update_frequency_down    10                        1.0            -0.030024          110
     update_frequency                      increase                update_frequency_up    10                        1.0             0.034434          110
```

This table confirms that the sign-to-semantic mapping itself is functioning.

Example:

```text
adoption_threshold decrease
→ adoption_barrier_relief

deadzone_width decrease
→ sensitivity_opening

cooldown_length decrease
→ update_access_opening

hysteresis_strength decrease
→ hysteresis_guard_down
```

## 6. Worst Semantic Effects

```text
   pressure_component component_direction                  semantic_effect  rows  mean_match_rate  aligned_rows  misaligned_rows    dominant_verdict
   sandbox_entry_rate            increase           sandbox_probe_entry_up     8         0.041667             0                8 semantic_misaligned
     update_frequency            increase              update_frequency_up     8         0.041667             0                8 semantic_misaligned
   sandbox_entry_rate            decrease         sandbox_probe_entry_down     8         0.187500             3                5 semantic_misaligned
exploration_frequency            increase exploration_attempt_frequency_up    12         0.250000             4                8 semantic_misaligned
   adoption_threshold            decrease          adoption_barrier_relief    16         0.333333             7                9 semantic_misaligned
      cooldown_length            decrease            update_access_opening    16         0.333333             7                9 semantic_misaligned
       deadzone_width            decrease              sensitivity_opening    16         0.333333             7                9 semantic_misaligned
     update_frequency            decrease            update_frequency_down     8         0.375000             1                7 semantic_misaligned
     diagnostic_depth            decrease       diagnostic_resolution_down    16         0.416667             8                8    semantic_aligned
  hysteresis_strength            decrease            hysteresis_guard_down    16         0.416667             7                9 semantic_misaligned
```

Weak semantic-effect outcome links include:

```text
sandbox_probe_entry_up
update_frequency_up
exploration_attempt_frequency_up
adoption_barrier_relief
update_access_opening
sensitivity_opening
```

This points toward the exploration/opening family being hard to confirm by
simple one-step outcome metrics.

## 7. Primitive Outcome Summary

```text
     action_primitive  action_channel  rows  total_action_rows  mean_action_mass  mean_match_rate  aligned_rows  misaligned_rows     dominant_verdict
         buffer_first buffer_increase     7                 41          0.665525         0.523810             4                3    primitive_aligned
coupling_relief_first coupling_relief    12                107          1.169148         0.361111             4                8 primitive_misaligned
```

Only the actually actuated primitive families appear here in this available RC1
data:

```text
buffer_first
coupling_relief_first
```

`buffer_first` is moderately aligned.  
`coupling_relief_first` is weaker.

This means the current stored result set is still too sparse to fully audit all
primitive sequences. A later RC should run this audit on the richer RC2
execution-policy closed-loop outputs.

## 8. Correct Interpretation

The earlier apparent contradiction:

```text
outcome is good,
but signed pressure alignment looks inverse
```

is now better explained as:

```text
approved sign → semantic effect:
  clean

semantic effect → planned/action primitive:
  partly compressed/selected away

executed primitive → one-step outcome:
  mixed and sparse

therefore:
  pressure sign should not be compared directly to outcome
```

## 9. What To Fix Next

The next task should be:

```text
PressureOutcomeAlignmentAudit_RC2
```

But RC2 should not use the old direct mapping.

Instead:

```text
Primary:
  executed primitive / sequence expected outcome
  vs observed outcome

Secondary:
  semantic_effect expected outcome
  vs observed outcome

Diagnostic only:
  approved component sign
  vs observed outcome
```

Also, the next audit should run on richer action execution outputs where all
primitive families are represented.

## 10. Development Decision

Do not tune DEPT pressure generation yet.

Current status:

```text
pressure sign to semantic:
  OK

semantic to action:
  partial / compressed

action to outcome:
  mixed

DEPT pressure tuning:
  still premature
```

The immediate correction is to change the alignment target from:

```text
approved_* sign vs outcome
```

to:

```text
semantic effect / primitive sequence vs outcome
```
