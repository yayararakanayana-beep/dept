# Pressure Outcome Alignment Audit RC2

## 0. Position

`PressureOutcomeAlignmentAudit_RC2` corrects the main weakness of RC1.

RC1 compared:

```text
approved pressure sign
vs
observed outcome
```

That was too coarse because `approved_*` signs are lower-parameter adjustment
directions, not direct outcome directions.

RC2 compares:

```text
semantic_effect
vs
observed outcome
```

and:

```text
primitive / sequence
vs
observed outcome
```

The pressure sign is retained only as a diagnostic layer.

## 1. Why RC2 Exists

Task A, `PressureSignSemanticsAudit_RC1`, showed:

```text
pressure sign -> semantic_effect:
  contract is intact

semantic_effect -> plan/action:
  many effects are filtered or not actuated

primitive/action -> outcome:
  mixed
```

Therefore outcome alignment should not be judged directly from pressure sign.

## 2. Primary Metrics

RC2 records:

```text
semantic_alignment_rate
semantic_to_plan_present_rate
plan_to_action_present_rate
primitive_alignment_rate
```

Interpretation:

```text
semantic_alignment_rate:
  Does the semantic effect match the observed outcome direction?

plan_to_action_present_rate:
  Did the semantic effect survive into actual action?

primitive_alignment_rate:
  Did the actuated primitive/sequence produce its expected outcome?
```

## 3. Outputs

```text
results/pressure_outcome_alignment_rc2_semantic_primary.csv
results/pressure_outcome_alignment_rc2_primitive_primary.csv
results/pressure_outcome_alignment_rc2_chain_coverage.csv
results/pressure_outcome_alignment_rc2_semantic_summary.csv
results/pressure_outcome_alignment_rc2_primitive_summary.csv
results/pressure_outcome_alignment_rc2_review.csv
results/pressure_outcome_alignment_rc2_summary.json
```

## 4. Interpretation

If semantic alignment is acceptable but action coverage is low:

```text
the pressure meaning is not the main problem;
the bottleneck is semantic-effect survival into action
```

If primitive alignment is mixed:

```text
the action module / pseudo-reality coupling needs further calibration
```

If both semantic and primitive alignment are high:

```text
limited DEPT-side pressure tuning can begin
```

If both are low:

```text
do not tune DEPT yet; fix translation/action semantics first
```
