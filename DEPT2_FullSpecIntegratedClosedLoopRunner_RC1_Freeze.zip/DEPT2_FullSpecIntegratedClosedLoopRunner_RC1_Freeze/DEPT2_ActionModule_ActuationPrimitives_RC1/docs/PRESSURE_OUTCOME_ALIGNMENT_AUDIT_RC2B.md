# Pressure Outcome Alignment Audit RC2b

## 0. Position

`PressureOutcomeAlignmentAudit_RC2b` runs after:

```text
DiagnosticActionTranslationPolicy_RC1
```

RC2b asks:

```text
Did the diagnostic policy fix semantic/action coverage?
Can outcome alignment now be interpreted?
What still requires a closed-loop rerun?
```

## 1. Boundary

DiagnosticActionTranslationPolicy_RC1 created weak diagnostic actions, but those
newly rescued actions have not yet been re-applied to pseudo-reality.

Therefore RC2b must not claim:

```text
new diagnostic actions improved outcome
```

unless those actions were actually executed in a closed-loop rerun.

## 2. What RC2b Measures

```text
before/after semantic_to_plan coverage
before/after plan_to_action coverage
which semantic effects are now ready for rerun
which effects still only have pending outcome attribution
requirements for the next diagnostic closed-loop rerun
```

## 3. Outputs

```text
results/pressure_outcome_alignment_rc2b_semantic_policy_alignment.csv
results/pressure_outcome_alignment_rc2b_coverage_delta.csv
results/pressure_outcome_alignment_rc2b_outcome_attribution_status.csv
results/pressure_outcome_alignment_rc2b_diagnostic_action_readiness.csv
results/pressure_outcome_alignment_rc2b_next_closed_loop_requirements.csv
results/pressure_outcome_alignment_rc2b_summary.json
```

## 4. Interpretation

RC2b can confirm:

```text
coverage fixed
diagnostic actions generated
semantic effects ready for pseudo-reality rerun
```

RC2b cannot yet confirm:

```text
new diagnostic actions caused expected outcome
```

For that, the next task is:

```text
DiagnosticClosedLoopRerun_RC1
```
