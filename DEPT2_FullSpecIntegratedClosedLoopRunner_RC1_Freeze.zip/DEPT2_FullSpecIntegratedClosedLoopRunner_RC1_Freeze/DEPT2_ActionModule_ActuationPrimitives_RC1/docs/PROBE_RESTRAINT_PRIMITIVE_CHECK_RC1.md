# Probe Restraint Primitive Check RC1

## 0. Position

`ProbeRestraintPrimitiveCheck_RC1` follows:

```text
ExpectedEffectContractPatch_RC1
```

It resolves the remaining ambiguity around:

```text
sandbox_probe_entry_down
```

## 1. Question

The patched contract passes because the current action behaves like
buffer-style stabilization.

But does that actually express probe restraint?

This check compares:

```text
current_buffer_style
direct_probe_restraint
hybrid_probe_restraint
```

against both:

```text
old probe-restraint contract
patched stabilization contract
```

## 2. Boundary

This task does not:

```text
- tune H-DEPT pressure
- repair coupling_relief->staged_unlock
```

## 3. Outputs

```text
results/probe_restraint_variant_action_frame_RC1.csv
results/probe_restraint_variant_alignment_RC1.csv
results/probe_restraint_variant_summary_RC1.csv
results/probe_restraint_contract_basis_RC1.csv
results/probe_restraint_policy_decision_RC1.csv
results/probe_restraint_primitive_check_summary_RC1.json
```
