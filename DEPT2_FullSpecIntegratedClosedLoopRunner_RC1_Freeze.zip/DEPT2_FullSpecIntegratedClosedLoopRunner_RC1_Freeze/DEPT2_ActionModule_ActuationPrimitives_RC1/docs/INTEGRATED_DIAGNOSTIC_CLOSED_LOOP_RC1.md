# Integrated Diagnostic Closed Loop RC1

## 0. Position

`IntegratedDiagnosticClosedLoop_RC1` is the first fresh end-to-end run after
the validation action-module repairs.

It follows:

```text
DiagnosticActionModuleIntegrationReview_RC1
```

## 1. Purpose

Run:

```text
DEPT core
-> pressure semantic
-> repaired diagnostic action policy
-> pseudo-reality
-> fresh outcome trace
```

This is not a replay of old stored outcomes.

## 2. Included Repairs

```text
diagnostic action coverage policy
primitive mapping repair
expected-effect contract patch
probe-restraint direct/stabilization split
guarded delayed staged-unlock sequence
```

## 3. Boundary

This task does not:

```text
- tune H-DEPT pressure
- claim deployment safety
- change formal H-DEPT input
```

Formal H-DEPT input remains:

```text
G_t global + K_t global only
```

## 4. Outputs

```text
results/integrated_diagnostic_gt_global_RC1.csv
results/integrated_diagnostic_kt_global_RC1.csv
results/integrated_diagnostic_formal_gtkt_packets_RC1.csv
results/integrated_diagnostic_m_observation_RC1.csv
results/integrated_diagnostic_pressure_candidates_RC1.csv
results/integrated_diagnostic_h11_local_pressure_field_RC1.csv
results/integrated_diagnostic_pressure_intent_bundle_RC1.csv
results/integrated_diagnostic_action_frame_RC1.csv
results/integrated_diagnostic_sequence_events_RC1.csv
results/integrated_diagnostic_combined_outcomes_RC1.csv
results/integrated_diagnostic_isolated_semantic_outcomes_RC1.csv
results/integrated_diagnostic_semantic_summary_RC1.csv
results/integrated_diagnostic_loop_metrics_RC1.csv
results/integrated_diagnostic_closed_loop_summary_RC1.json
```

## 5. Next

The natural next task is:

```text
PressureOutcomeAlignmentAudit_RC3
```
