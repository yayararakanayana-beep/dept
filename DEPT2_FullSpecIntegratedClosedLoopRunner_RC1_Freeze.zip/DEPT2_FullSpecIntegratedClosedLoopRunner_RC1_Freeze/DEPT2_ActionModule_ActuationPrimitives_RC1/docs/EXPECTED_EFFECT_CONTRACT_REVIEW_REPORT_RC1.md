# Expected Effect Contract Review Report RC1

## 0. Position

This report records **ExpectedEffectContractReview_RC1**.

It follows:

```text
DiagnosticPrimitiveMappingRepair_RC1
```

The previous task repaired primitive mappings.  
This task reviews the remaining question:

```text
Is the expected-effect contract itself wrong or too coarse?
```

## 1. Scope

Review targets:

```text
diagnostic_resolution_down
rollback_guard_down
sandbox_probe_entry_down
hysteresis_guard_down
update_access_opening
update_frequency_up
```

This task does not freeze new contracts.  
It proposes candidate diagnostic contracts.

## 2. Execution Summary

```json
{
  "task": "ExpectedEffectContractReview_RC1",
  "status": "completed",
  "reviewed_semantic_count": 6,
  "mean_old_contract_alignment_score": 0.3333333333333333,
  "mean_candidate_contract_alignment_score": 1.0,
  "mean_score_delta": 0.6666666666666666,
  "candidate_adoption_after_rerun_count": 5,
  "ambiguity_count": 1,
  "class_counts": {
    "contract_over_specified_or_missing_feature": 3,
    "contract_inverted_or_wrong_direction": 2,
    "contract_or_primitive_ambiguity": 1
  },
  "candidate_contract_semantics": [
    "diagnostic_resolution_down",
    "rollback_guard_down",
    "sandbox_probe_entry_down",
    "hysteresis_guard_down",
    "update_access_opening",
    "update_frequency_up"
  ],
  "ambiguous_semantics": [
    "sandbox_probe_entry_down"
  ],
  "class_summary": [
    {
      "contract_review_class": "contract_inverted_or_wrong_direction",
      "semantic_count": 2,
      "mean_old_score": 0.0,
      "mean_candidate_score": 1.0,
      "semantics": "diagnostic_resolution_down|rollback_guard_down"
    },
    {
      "contract_review_class": "contract_or_primitive_ambiguity",
      "semantic_count": 1,
      "mean_old_score": 0.0,
      "mean_candidate_score": 1.0,
      "semantics": "sandbox_probe_entry_down"
    },
    {
      "contract_review_class": "contract_over_specified_or_missing_feature",
      "semantic_count": 3,
      "mean_old_score": 0.6666666666666666,
      "mean_candidate_score": 1.0,
      "semantics": "hysteresis_guard_down|update_access_opening|update_frequency_up"
    }
  ],
  "primary_conclusion": "Several old expected-effect contracts are mismatched with observed diagnostic pseudo-reality effects; candidate diagnostic contracts are proposed but not frozen.",
  "dept_pressure_tuning_readiness": "not_ready_contract_patch_and_rerun_required",
  "next_recommended_task": "ExpectedEffectContractPatch_RC1",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/expected_effect_contract_review_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "expected_effect_contract_review_table": "expected_effect_contract_review_table_RC1.csv",
    "expected_effect_contract_feature_evidence": "expected_effect_contract_feature_evidence_RC1.csv",
    "expected_effect_contract_candidate_contracts": "expected_effect_contract_candidate_contracts_RC1.csv",
    "expected_effect_contract_class_summary": "expected_effect_contract_class_summary_RC1.csv",
    "expected_effect_contract_next_action_plan": "expected_effect_contract_next_action_plan_RC1.csv"
  },
  "review_note": "candidate contracts are diagnostic candidates only; not frozen until patch+rereun."
}
```

Focused test status:

```text
test_expected_effect_contract_review.py: 3 passed
```

## 3. Main Result

```text
mean_old_contract_alignment_score = 0.333
mean_candidate_contract_alignment_score = 1.000
mean_score_delta = 0.667
```

The candidate diagnostic contracts fit the observed pseudo-reality behavior much
better than the old contracts.

## 4. Review Table

```text
           semantic_effect           intent_family                                                                   semantic_intent_hint                                     old_contract                                            candidate_contract  old_contract_alignment_score  candidate_contract_alignment_score  score_delta                                                                                                                                               old_match_details                                                                                                                                                                                          candidate_match_details                      contract_review_class                                                                                                                                                                                             review_reason  review_priority                   recommended_action
diagnostic_resolution_down observation_cost_saving                                          observation cost saving / lighter observation          conflict:+1;m_overall:-1;uncertainty:+1                       conflict:-1;m_overall:+1;uncertainty:-1                      0.000000                                 1.0     1.000000        uncertainty:expected=1,observed_sign=-1,match=False; conflict:expected=1,observed_sign=-1,match=False; m_overall:expected=-1,observed_sign=1,match=False                                                           conflict:expected=-1,observed_sign=-1,match=True; uncertainty:expected=-1,observed_sign=-1,match=True; m_overall:expected=1,observed_sign=1,match=True       contract_inverted_or_wrong_direction                                                              Old contract expects the opposite direction from the observed diagnostic effect; candidate contract matches current pseudo-reality behavior.                1 adopt_candidate_after_one_more_rerun
       rollback_guard_down       safety_relaxation rollback/safety relaxation semantics; current action behaves like buffer stabilization          conflict:+1;m_overall:-1;uncertainty:+1                       conflict:-1;m_overall:+1;uncertainty:-1                      0.000000                                 1.0     1.000000        uncertainty:expected=1,observed_sign=-1,match=False; conflict:expected=1,observed_sign=-1,match=False; m_overall:expected=-1,observed_sign=1,match=False                                                           conflict:expected=-1,observed_sign=-1,match=True; uncertainty:expected=-1,observed_sign=-1,match=True; m_overall:expected=1,observed_sign=1,match=True       contract_inverted_or_wrong_direction                                                              Old contract expects the opposite direction from the observed diagnostic effect; candidate contract matches current pseudo-reality behavior.                1 adopt_candidate_after_one_more_rerun
  sandbox_probe_entry_down         probe_restraint        probe/sandbox entry restraint; current action behaves like buffer stabilization                exploration:-1;overconvergence:+1                       conflict:-1;m_overall:+1;uncertainty:-1                      0.000000                                 1.0     1.000000                                                     exploration:expected=-1,observed_sign=0,match=False; overconvergence:expected=1,observed_sign=0,match=False                                                           conflict:expected=-1,observed_sign=-1,match=True; uncertainty:expected=-1,observed_sign=-1,match=True; m_overall:expected=1,observed_sign=1,match=True            contract_or_primitive_ambiguity Current buffer-style action does not express old probe-restraint expectations; candidate contract captures observed stabilization, but a future direct probe-restraint primitive may still be preferable.                1        manual_review_before_adoption
     hysteresis_guard_down   switching_flexibility                                          switching flexibility / less hysteresis guard    conflict:-1;exploration:+1;overconvergence:-1                   conflict:-1;m_overall:+1;overconvergence:-1                      0.666667                                 1.0     0.333333   exploration:expected=1,observed_sign=0,match=False; overconvergence:expected=-1,observed_sign=-1,match=True; conflict:expected=-1,observed_sign=-1,match=True                                                       conflict:expected=-1,observed_sign=-1,match=True; overconvergence:expected=-1,observed_sign=-1,match=True; m_overall:expected=1,observed_sign=1,match=True contract_over_specified_or_missing_feature                                                                                                   Old contract is partly valid but contains/omits features that do not match observed diagnostic effects.                2 adopt_candidate_after_one_more_rerun
     update_access_opening        temporal_opening                                   temporal/update access opening via uncertainty probe exploration:+1;overconvergence:-1;uncertainty:+1 exploration:+1;m_overall:+1;overconvergence:-1;uncertainty:-1                      0.666667                                 1.0     0.333333 exploration:expected=1,observed_sign=1,match=True; overconvergence:expected=-1,observed_sign=-1,match=True; uncertainty:expected=1,observed_sign=-1,match=False exploration:expected=1,observed_sign=1,match=True; overconvergence:expected=-1,observed_sign=-1,match=True; uncertainty:expected=-1,observed_sign=-1,match=True; m_overall:expected=1,observed_sign=1,match=True contract_over_specified_or_missing_feature                                                                                                   Old contract is partly valid but contains/omits features that do not match observed diagnostic effects.                2 adopt_candidate_after_one_more_rerun
       update_frequency_up          update_opening                 update opening / more frequent diagnostic update via uncertainty probe exploration:+1;overconvergence:-1;uncertainty:+1 exploration:+1;m_overall:+1;overconvergence:-1;uncertainty:-1                      0.666667                                 1.0     0.333333 exploration:expected=1,observed_sign=1,match=True; overconvergence:expected=-1,observed_sign=-1,match=True; uncertainty:expected=1,observed_sign=-1,match=False exploration:expected=1,observed_sign=1,match=True; overconvergence:expected=-1,observed_sign=-1,match=True; uncertainty:expected=-1,observed_sign=-1,match=True; m_overall:expected=1,observed_sign=1,match=True contract_over_specified_or_missing_feature                                                                                                   Old contract is partly valid but contains/omits features that do not match observed diagnostic effects.                2 adopt_candidate_after_one_more_rerun
```

## 5. Candidate Contracts

```text
           semantic_effect           intent_family                                     old_contract                                            candidate_contract              candidate_status                                                                                                                                                                                          candidate_reason                      contract_review_class  review_priority                                              contract_patch_contract
diagnostic_resolution_down observation_cost_saving          conflict:+1;m_overall:-1;uncertainty:+1                       conflict:-1;m_overall:+1;uncertainty:-1 candidate_only_not_yet_frozen                                                              Old contract expects the opposite direction from the observed diagnostic effect; candidate contract matches current pseudo-reality behavior.       contract_inverted_or_wrong_direction                1 ExpectedEffectContractReview_RC1__candidate_expected_effect_contract
       rollback_guard_down       safety_relaxation          conflict:+1;m_overall:-1;uncertainty:+1                       conflict:-1;m_overall:+1;uncertainty:-1 candidate_only_not_yet_frozen                                                              Old contract expects the opposite direction from the observed diagnostic effect; candidate contract matches current pseudo-reality behavior.       contract_inverted_or_wrong_direction                1 ExpectedEffectContractReview_RC1__candidate_expected_effect_contract
  sandbox_probe_entry_down         probe_restraint                exploration:-1;overconvergence:+1                       conflict:-1;m_overall:+1;uncertainty:-1 candidate_only_not_yet_frozen Current buffer-style action does not express old probe-restraint expectations; candidate contract captures observed stabilization, but a future direct probe-restraint primitive may still be preferable.            contract_or_primitive_ambiguity                1 ExpectedEffectContractReview_RC1__candidate_expected_effect_contract
     hysteresis_guard_down   switching_flexibility    conflict:-1;exploration:+1;overconvergence:-1                   conflict:-1;m_overall:+1;overconvergence:-1 candidate_only_not_yet_frozen                                                                                                   Old contract is partly valid but contains/omits features that do not match observed diagnostic effects. contract_over_specified_or_missing_feature                2 ExpectedEffectContractReview_RC1__candidate_expected_effect_contract
     update_access_opening        temporal_opening exploration:+1;overconvergence:-1;uncertainty:+1 exploration:+1;m_overall:+1;overconvergence:-1;uncertainty:-1 candidate_only_not_yet_frozen                                                                                                   Old contract is partly valid but contains/omits features that do not match observed diagnostic effects. contract_over_specified_or_missing_feature                2 ExpectedEffectContractReview_RC1__candidate_expected_effect_contract
       update_frequency_up          update_opening exploration:+1;overconvergence:-1;uncertainty:+1 exploration:+1;m_overall:+1;overconvergence:-1;uncertainty:-1 candidate_only_not_yet_frozen                                                                                                   Old contract is partly valid but contains/omits features that do not match observed diagnostic effects. contract_over_specified_or_missing_feature                2 ExpectedEffectContractReview_RC1__candidate_expected_effect_contract
```

## 6. Feature Evidence

```text
           semantic_effect           intent_family         feature  old_expected_sign  observed_sign  candidate_expected_sign  observed_delta  old_matches_observed  candidate_matches_observed
diagnostic_resolution_down observation_cost_saving        conflict                  1             -1                       -1       -0.000003                 False                        True
diagnostic_resolution_down observation_cost_saving     exploration                  0              1                        0        0.000005                 False                       False
diagnostic_resolution_down observation_cost_saving       m_overall                 -1              1                        1        0.000008                 False                        True
diagnostic_resolution_down observation_cost_saving overconvergence                  0             -1                        0       -0.000002                 False                       False
diagnostic_resolution_down observation_cost_saving     uncertainty                  1             -1                       -1       -0.000013                 False                        True
       rollback_guard_down       safety_relaxation        conflict                  1             -1                       -1       -0.000002                 False                        True
       rollback_guard_down       safety_relaxation     exploration                  0              0                        0        0.000000                 False                       False
       rollback_guard_down       safety_relaxation       m_overall                 -1              1                        1        0.000025                 False                        True
       rollback_guard_down       safety_relaxation overconvergence                  0              0                        0        0.000000                 False                       False
       rollback_guard_down       safety_relaxation     uncertainty                  1             -1                       -1       -0.000003                 False                        True
  sandbox_probe_entry_down         probe_restraint        conflict                  0             -1                       -1       -0.000002                 False                        True
  sandbox_probe_entry_down         probe_restraint     exploration                 -1              0                        0        0.000000                 False                       False
  sandbox_probe_entry_down         probe_restraint       m_overall                  0              1                        1        0.000017                 False                        True
  sandbox_probe_entry_down         probe_restraint overconvergence                  1              0                        0        0.000000                 False                       False
  sandbox_probe_entry_down         probe_restraint     uncertainty                  0             -1                       -1       -0.000002                 False                        True
     hysteresis_guard_down   switching_flexibility        conflict                 -1             -1                       -1       -0.000008                  True                        True
     hysteresis_guard_down   switching_flexibility     exploration                  1              0                        0        0.000000                 False                       False
     hysteresis_guard_down   switching_flexibility       m_overall                  0              1                        1        0.000008                 False                        True
     hysteresis_guard_down   switching_flexibility overconvergence                 -1             -1                       -1       -0.000017                  True                        True
     hysteresis_guard_down   switching_flexibility     uncertainty                  0              0                        0        0.000000                 False                       False
     update_access_opening        temporal_opening        conflict                  0             -1                        0       -0.000003                 False                       False
     update_access_opening        temporal_opening     exploration                  1              1                        1        0.000005                  True                        True
     update_access_opening        temporal_opening       m_overall                  0              1                        1        0.000008                 False                        True
     update_access_opening        temporal_opening overconvergence                 -1             -1                       -1       -0.000002                  True                        True
     update_access_opening        temporal_opening     uncertainty                  1             -1                       -1       -0.000013                 False                        True
       update_frequency_up          update_opening        conflict                  0             -1                        0       -0.000002                 False                       False
       update_frequency_up          update_opening     exploration                  1              1                        1        0.000003                  True                        True
       update_frequency_up          update_opening       m_overall                  0              1                        1        0.000005                 False                        True
       update_frequency_up          update_opening overconvergence                 -1             -1                       -1       -0.000002                  True                        True
       update_frequency_up          update_opening     uncertainty                  1             -1                       -1       -0.000008                 False                        True
```

## 7. Class Summary

```text
                     contract_review_class  semantic_count  mean_old_score  mean_candidate_score                                                       semantics
      contract_inverted_or_wrong_direction               2        0.000000                   1.0                  diagnostic_resolution_down|rollback_guard_down
           contract_or_primitive_ambiguity               1        0.000000                   1.0                                        sandbox_probe_entry_down
contract_over_specified_or_missing_feature               3        0.666667                   1.0 hysteresis_guard_down|update_access_opening|update_frequency_up
```

## 8. Interpretation

### Contract inverted / wrong direction

```text
diagnostic_resolution_down
rollback_guard_down
```

The old contract expected conflict/uncertainty up and m_overall down.  
Observed diagnostic behavior is the opposite:

```text
conflict down
uncertainty down
m_overall up
```

So these look like contract-direction errors for the current diagnostic setting.

### Contract over-specified / missing feature

```text
hysteresis_guard_down
update_access_opening
update_frequency_up
```

These were partly correct, but the old contract expected features that are not
actually expressed, or expected the wrong sign for uncertainty.

### Contract / primitive ambiguity

```text
sandbox_probe_entry_down
```

This one is ambiguous.  
The current buffer-style diagnostic action gives stabilization, but it does not
really express direct sandbox/probe restraint.  
So the candidate contract fits observed behavior, but a future primitive check
may still be useful.

## 9. Next Action Plan

```text
 priority                            next_task                                                                                            reason                                                                                                                        target_semantics                                                                            expected_output
        1      ExpectedEffectContractPatch_RC1            Review found candidate contracts that better match diagnostic pseudo-reality behavior. diagnostic_resolution_down|rollback_guard_down|sandbox_probe_entry_down|hysteresis_guard_down|update_access_opening|update_frequency_up  freeze candidate contracts as diagnostic expected-effect contracts, then rerun alignment.
        2     ProbeRestraintPrimitiveCheck_RC1 sandbox_probe_entry_down may be a contract/primitive ambiguity rather than a pure contract issue.                                                                                                                sandbox_probe_entry_down decide whether to keep buffer-style stabilization or add direct probe-restraint primitive.
        3 CouplingReliefStagedUnlockRepair_RC1              Sequence-level repair remains separate after diagnostic mapping and contract review.                                                                                                relation/coupling staged unlock families                                          repair coupling_relief -> staged_unlock sequence.
```

## 10. Recommended Next Task

```text
ExpectedEffectContractPatch_RC1
```

Purpose:

```text
freeze candidate diagnostic expected-effect contracts,
then rerun alignment to confirm the patch.
```

Do not tune H-DEPT pressure yet.
