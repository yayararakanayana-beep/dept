# Diagnostic Action Translation Policy Report RC1

## 0. Position

This report records **DiagnosticActionTranslationPolicy_RC1**.

This task implements the first validation-oriented action translation policy after:

```text
PressureOutcomeAlignmentAudit_RC2_ResultReview_RC1
```

The previous result showed:

```text
semantic_to_plan_present_rate = 0.284
plan_to_action_present_rate = 0.091
```

The conclusion was:

```text
The sign-only audit issue is fixed.
The remaining bottleneck is semantic/action survival.
```

## 1. Purpose

This task is not a governance/safety policy.

It is a validation policy:

```text
semantic_effect
→ weak diagnostic plan
→ weak diagnostic action
→ explicit drop/recovery reason
```

The goal is to make pressure intent observable in pseudo-reality alignment tests.

## 2. Execution Summary

```json
{
  "task": "DiagnosticActionTranslationPolicy_RC1",
  "status": "completed",
  "policy_mode": "alignment_probe",
  "semantic_rows": 220,
  "semantic_effect_count": 14,
  "intent_family_count": 14,
  "diagnostic_action_rows": 220,
  "diagnostic_primitive_count": 14,
  "original_semantic_to_plan_rate": 0.2909090909090909,
  "original_plan_to_action_rate": 0.09090909090909091,
  "policy_semantic_to_plan_rate": 1.0,
  "policy_plan_to_action_rate": 1.0,
  "rescued_from_no_plan_rows": 156,
  "rescued_from_no_action_rows": 44,
  "retained_existing_action_rows": 20,
  "positive_control_rows": 20,
  "total_diagnostic_action_mass": 26.944735328816936,
  "explicit_route_rate": 1.0,
  "semantic_coverage": [
    {
      "semantic_effect": "adoption_barrier_relief",
      "intent_family": "adoption_opening",
      "rows": 20,
      "original_plan_rate": 0.05,
      "original_action_rate": 0.05,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1896,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "commitment_strength_down",
      "intent_family": "commitment_relief",
      "rows": 20,
      "original_plan_rate": 0.05,
      "original_action_rate": 0.05,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.18775831407379154,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "diagnostic_resolution_down",
      "intent_family": "observation_cost_saving",
      "rows": 20,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.18357636476249223,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "exploration_attempt_frequency_down",
      "intent_family": "exploration_restraint",
      "rows": 5,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.03,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "exploration_attempt_frequency_up",
      "intent_family": "exploration_attempt",
      "rows": 15,
      "original_plan_rate": 0.3333333333333333,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.11094732046939831,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "hysteresis_guard_down",
      "intent_family": "switching_flexibility",
      "rows": 20,
      "original_plan_rate": 0.85,
      "original_action_rate": 0.85,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1872717279637321,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "intensity_cap_brake",
      "intent_family": "safety_cap",
      "rows": 20,
      "original_plan_rate": 1.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1896,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 20
    },
    {
      "semantic_effect": "rollback_guard_down",
      "intent_family": "safety_relaxation",
      "rows": 20,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1846937285476303,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "sandbox_probe_entry_down",
      "intent_family": "probe_restraint",
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.06,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "sandbox_probe_entry_up",
      "intent_family": "exploration_observation",
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.06322301012493407,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "sensitivity_opening",
      "intent_family": "response_opening",
      "rows": 20,
      "original_plan_rate": 1.0,
      "original_action_rate": 0.05,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.18913623647500657,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "update_access_opening",
      "intent_family": "temporal_opening",
      "rows": 20,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1896,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "update_frequency_down",
      "intent_family": "update_restraint",
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.06161459474509284,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    },
    {
      "semantic_effect": "update_frequency_up",
      "intent_family": "update_opening",
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.0608545030440429,
      "explicit_route_rate": 1.0,
      "positive_control_rows": 0
    }
  ],
  "primitive_route_summary": [
    {
      "diagnostic_action_primitive": "buffer_first",
      "diagnostic_primitive_sequence": "buffer -> replan",
      "diagnostic_action_channel": "buffer_increase",
      "semantic_effects": 1,
      "rows": 20,
      "total_action_mass_after_policy": 0.1896,
      "mean_diagnostic_strength": 0.009479999999999999,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 20
    },
    {
      "diagnostic_action_primitive": "diagnostic_adoption_opening_probe",
      "diagnostic_primitive_sequence": "adoption_opening_probe -> buffer_observe -> report",
      "diagnostic_action_channel": "exploration_injection",
      "semantic_effects": 1,
      "rows": 20,
      "total_action_mass_after_policy": 1.0058133285512036,
      "mean_diagnostic_strength": 0.009479999999999999,
      "originally_actuated_rate": 0.05,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_commitment_relief_probe",
      "diagnostic_primitive_sequence": "commitment_relief -> peripheral_observe",
      "diagnostic_action_channel": "exploration_injection",
      "semantic_effects": 1,
      "rows": 20,
      "total_action_mass_after_policy": 0.42760703441570636,
      "mean_diagnostic_strength": 0.009387915703689577,
      "originally_actuated_rate": 0.05,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_exploration_attempt",
      "diagnostic_primitive_sequence": "exploration_attempt -> observe -> report",
      "diagnostic_action_channel": "exploration_injection",
      "semantic_effects": 1,
      "rows": 15,
      "total_action_mass_after_policy": 0.11094732046939831,
      "mean_diagnostic_strength": 0.007396488031293221,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_exploration_restraint",
      "diagnostic_primitive_sequence": "exploration_restraint -> observe",
      "diagnostic_action_channel": "buffer_increase",
      "semantic_effects": 1,
      "rows": 5,
      "total_action_mass_after_policy": 0.03,
      "mean_diagnostic_strength": 0.006,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_observation_saving_probe",
      "diagnostic_primitive_sequence": "lighter_observation -> report",
      "diagnostic_action_channel": "uncertainty_probe",
      "semantic_effects": 1,
      "rows": 20,
      "total_action_mass_after_policy": 0.18357636476249223,
      "mean_diagnostic_strength": 0.009178818238124612,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_probe_restraint",
      "diagnostic_primitive_sequence": "probe_restraint -> observe",
      "diagnostic_action_channel": "buffer_increase",
      "semantic_effects": 1,
      "rows": 10,
      "total_action_mass_after_policy": 0.06,
      "mean_diagnostic_strength": 0.006,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_rollback_relaxation_probe",
      "diagnostic_primitive_sequence": "rollback_relaxation -> observe",
      "diagnostic_action_channel": "buffer_increase",
      "semantic_effects": 1,
      "rows": 20,
      "total_action_mass_after_policy": 0.1846937285476303,
      "mean_diagnostic_strength": 0.009234686427381514,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_sandbox_probe",
      "diagnostic_primitive_sequence": "sandbox_probe -> observe -> report",
      "diagnostic_action_channel": "exploration_injection",
      "semantic_effects": 1,
      "rows": 10,
      "total_action_mass_after_policy": 0.06322301012493407,
      "mean_diagnostic_strength": 0.006322301012493407,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_sensitivity_opening",
      "diagnostic_primitive_sequence": "sensitivity_opening -> observe -> report",
      "diagnostic_action_channel": "coupling_relief",
      "semantic_effects": 1,
      "rows": 20,
      "total_action_mass_after_policy": 0.26709858483298815,
      "mean_diagnostic_strength": 0.009456811823750329,
      "originally_actuated_rate": 0.05,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_switching_flexibility",
      "diagnostic_primitive_sequence": "switching_flexibility -> observe",
      "diagnostic_action_channel": "coupling_relief",
      "semantic_effects": 1,
      "rows": 20,
      "total_action_mass_after_policy": 24.110106859323448,
      "mean_diagnostic_strength": 0.009363586398186605,
      "originally_actuated_rate": 0.85,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_update_access_probe",
      "diagnostic_primitive_sequence": "update_access_probe -> observe -> report",
      "diagnostic_action_channel": "uncertainty_probe",
      "semantic_effects": 1,
      "rows": 20,
      "total_action_mass_after_policy": 0.1896,
      "mean_diagnostic_strength": 0.009479999999999999,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_update_opening",
      "diagnostic_primitive_sequence": "update_opening -> observe -> report",
      "diagnostic_action_channel": "uncertainty_probe",
      "semantic_effects": 1,
      "rows": 10,
      "total_action_mass_after_policy": 0.0608545030440429,
      "mean_diagnostic_strength": 0.00608545030440429,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 0
    },
    {
      "diagnostic_action_primitive": "diagnostic_update_restraint",
      "diagnostic_primitive_sequence": "update_restraint -> observe",
      "diagnostic_action_channel": "buffer_increase",
      "semantic_effects": 1,
      "rows": 10,
      "total_action_mass_after_policy": 0.06161459474509284,
      "mean_diagnostic_strength": 0.0061614594745092845,
      "originally_actuated_rate": 0.0,
      "positive_control_rows": 0
    }
  ],
  "family_summary": [
    {
      "intent_family": "adoption_opening",
      "semantic_effects": 1,
      "rows": 20,
      "original_plan_rate": 0.05,
      "original_action_rate": 0.05,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1896
    },
    {
      "intent_family": "commitment_relief",
      "semantic_effects": 1,
      "rows": 20,
      "original_plan_rate": 0.05,
      "original_action_rate": 0.05,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.18775831407379154
    },
    {
      "intent_family": "exploration_attempt",
      "semantic_effects": 1,
      "rows": 15,
      "original_plan_rate": 0.3333333333333333,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.11094732046939831
    },
    {
      "intent_family": "exploration_observation",
      "semantic_effects": 1,
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.06322301012493407
    },
    {
      "intent_family": "exploration_restraint",
      "semantic_effects": 1,
      "rows": 5,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.03
    },
    {
      "intent_family": "observation_cost_saving",
      "semantic_effects": 1,
      "rows": 20,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.18357636476249223
    },
    {
      "intent_family": "probe_restraint",
      "semantic_effects": 1,
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.06
    },
    {
      "intent_family": "response_opening",
      "semantic_effects": 1,
      "rows": 20,
      "original_plan_rate": 1.0,
      "original_action_rate": 0.05,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.18913623647500657
    },
    {
      "intent_family": "safety_cap",
      "semantic_effects": 1,
      "rows": 20,
      "original_plan_rate": 1.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1896
    },
    {
      "intent_family": "safety_relaxation",
      "semantic_effects": 1,
      "rows": 20,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1846937285476303
    },
    {
      "intent_family": "switching_flexibility",
      "semantic_effects": 1,
      "rows": 20,
      "original_plan_rate": 0.85,
      "original_action_rate": 0.85,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1872717279637321
    },
    {
      "intent_family": "temporal_opening",
      "semantic_effects": 1,
      "rows": 20,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.1896
    },
    {
      "intent_family": "update_opening",
      "semantic_effects": 1,
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.0608545030440429
    },
    {
      "intent_family": "update_restraint",
      "semantic_effects": 1,
      "rows": 10,
      "original_plan_rate": 0.0,
      "original_action_rate": 0.0,
      "policy_plan_rate": 1.0,
      "policy_action_rate": 1.0,
      "diagnostic_action_mass": 0.06161459474509284
    }
  ],
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/diagnostic_action_translation_policy_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "diagnostic_policy_plan": "diagnostic_action_translation_policy_plan_RC1.csv",
    "diagnostic_policy_action_frame": "diagnostic_action_translation_policy_action_frame_RC1.csv",
    "diagnostic_policy_drop_reason": "diagnostic_action_translation_policy_drop_reason_RC1.csv",
    "diagnostic_policy_semantic_coverage": "diagnostic_action_translation_policy_semantic_coverage_RC1.csv",
    "diagnostic_policy_primitive_route_summary": "diagnostic_action_translation_policy_primitive_route_summary_RC1.csv",
    "diagnostic_policy_family_summary": "diagnostic_action_translation_policy_family_summary_RC1.csv"
  },
  "policy_note": "validation-only weak diagnostic action pass-through; not a safety/governance policy"
}
```

Focused test status:

```text
test_diagnostic_action_translation_policy.py: 3 passed
```

## 3. Main Result

The policy guarantees validation survival:

```text
original_semantic_to_plan_rate = 0.291
original_plan_to_action_rate = 0.091

policy_semantic_to_plan_rate = 1.000
policy_plan_to_action_rate = 1.000
```

This does not mean all actions are safe or governance-ready.  
It means every semantic effect is now represented as a weak diagnostic action
candidate so pressure-outcome alignment can be observed.

## 4. Recovered Rows

```text
rescued_from_no_plan_rows = 156
rescued_from_no_action_rows = 44
retained_existing_action_rows = 20
positive_control_rows = 20
```

Interpretation:

```text
Many semantic effects were previously missing at plan/action level.
The policy rescues them into diagnostic-only weak actions.
```

## 5. Semantic Coverage

```text
                   semantic_effect           intent_family  rows  original_plan_rate  original_action_rate  policy_plan_rate  policy_action_rate  diagnostic_action_mass  explicit_route_rate  positive_control_rows
           adoption_barrier_relief        adoption_opening    20            0.050000                  0.05               1.0                 1.0                0.189600                  1.0                      0
          commitment_strength_down       commitment_relief    20            0.050000                  0.05               1.0                 1.0                0.187758                  1.0                      0
        diagnostic_resolution_down observation_cost_saving    20            0.000000                  0.00               1.0                 1.0                0.183576                  1.0                      0
exploration_attempt_frequency_down   exploration_restraint     5            0.000000                  0.00               1.0                 1.0                0.030000                  1.0                      0
  exploration_attempt_frequency_up     exploration_attempt    15            0.333333                  0.00               1.0                 1.0                0.110947                  1.0                      0
             hysteresis_guard_down   switching_flexibility    20            0.850000                  0.85               1.0                 1.0                0.187272                  1.0                      0
               intensity_cap_brake              safety_cap    20            1.000000                  0.00               1.0                 1.0                0.189600                  1.0                     20
               rollback_guard_down       safety_relaxation    20            0.000000                  0.00               1.0                 1.0                0.184694                  1.0                      0
          sandbox_probe_entry_down         probe_restraint    10            0.000000                  0.00               1.0                 1.0                0.060000                  1.0                      0
            sandbox_probe_entry_up exploration_observation    10            0.000000                  0.00               1.0                 1.0                0.063223                  1.0                      0
               sensitivity_opening        response_opening    20            1.000000                  0.05               1.0                 1.0                0.189136                  1.0                      0
             update_access_opening        temporal_opening    20            0.000000                  0.00               1.0                 1.0                0.189600                  1.0                      0
             update_frequency_down        update_restraint    10            0.000000                  0.00               1.0                 1.0                0.061615                  1.0                      0
               update_frequency_up          update_opening    10            0.000000                  0.00               1.0                 1.0                0.060855                  1.0                      0
```

All semantic effects now have:

```text
policy_plan_rate = 1.0
policy_action_rate = 1.0
```

This directly addresses the RC2 coverage bottleneck.

## 6. Primitive Route Summary

```text
         diagnostic_action_primitive                      diagnostic_primitive_sequence diagnostic_action_channel  semantic_effects  rows  total_action_mass_after_policy  mean_diagnostic_strength  originally_actuated_rate  positive_control_rows
                        buffer_first                                   buffer -> replan           buffer_increase                 1    20                        0.189600                  0.009480                      0.00                     20
   diagnostic_adoption_opening_probe adoption_opening_probe -> buffer_observe -> report     exploration_injection                 1    20                        1.005813                  0.009480                      0.05                      0
  diagnostic_commitment_relief_probe            commitment_relief -> peripheral_observe     exploration_injection                 1    20                        0.427607                  0.009388                      0.05                      0
      diagnostic_exploration_attempt           exploration_attempt -> observe -> report     exploration_injection                 1    15                        0.110947                  0.007396                      0.00                      0
    diagnostic_exploration_restraint                   exploration_restraint -> observe           buffer_increase                 1     5                        0.030000                  0.006000                      0.00                      0
 diagnostic_observation_saving_probe                      lighter_observation -> report         uncertainty_probe                 1    20                        0.183576                  0.009179                      0.00                      0
          diagnostic_probe_restraint                         probe_restraint -> observe           buffer_increase                 1    10                        0.060000                  0.006000                      0.00                      0
diagnostic_rollback_relaxation_probe                     rollback_relaxation -> observe           buffer_increase                 1    20                        0.184694                  0.009235                      0.00                      0
            diagnostic_sandbox_probe                 sandbox_probe -> observe -> report     exploration_injection                 1    10                        0.063223                  0.006322                      0.00                      0
      diagnostic_sensitivity_opening           sensitivity_opening -> observe -> report           coupling_relief                 1    20                        0.267099                  0.009457                      0.05                      0
    diagnostic_switching_flexibility                   switching_flexibility -> observe           coupling_relief                 1    20                       24.110107                  0.009364                      0.85                      0
      diagnostic_update_access_probe           update_access_probe -> observe -> report         uncertainty_probe                 1    20                        0.189600                  0.009480                      0.00                      0
           diagnostic_update_opening                update_opening -> observe -> report         uncertainty_probe                 1    10                        0.060855                  0.006085                      0.00                      0
         diagnostic_update_restraint                        update_restraint -> observe           buffer_increase                 1    10                        0.061615                  0.006161                      0.00                      0
```

New diagnostic routes cover:

```text
sandbox_probe_entry
update_frequency / update_access
exploration_attempt
adoption_barrier_relief
sensitivity_opening
commitment_relief
rollback relaxation
observation-cost saving
```

The existing positive control is preserved:

```text
buffer_first / buffer -> replan
```

## 7. Family Summary

```text
          intent_family  semantic_effects  rows  original_plan_rate  original_action_rate  policy_plan_rate  policy_action_rate  diagnostic_action_mass
       adoption_opening                 1    20            0.050000                  0.05               1.0                 1.0                0.189600
      commitment_relief                 1    20            0.050000                  0.05               1.0                 1.0                0.187758
    exploration_attempt                 1    15            0.333333                  0.00               1.0                 1.0                0.110947
exploration_observation                 1    10            0.000000                  0.00               1.0                 1.0                0.063223
  exploration_restraint                 1     5            0.000000                  0.00               1.0                 1.0                0.030000
observation_cost_saving                 1    20            0.000000                  0.00               1.0                 1.0                0.183576
        probe_restraint                 1    10            0.000000                  0.00               1.0                 1.0                0.060000
       response_opening                 1    20            1.000000                  0.05               1.0                 1.0                0.189136
             safety_cap                 1    20            1.000000                  0.00               1.0                 1.0                0.189600
      safety_relaxation                 1    20            0.000000                  0.00               1.0                 1.0                0.184694
  switching_flexibility                 1    20            0.850000                  0.85               1.0                 1.0                0.187272
       temporal_opening                 1    20            0.000000                  0.00               1.0                 1.0                0.189600
         update_opening                 1    10            0.000000                  0.00               1.0                 1.0                0.060855
       update_restraint                 1    10            0.000000                  0.00               1.0                 1.0                0.061615
```

Every intent family has weak diagnostic action coverage.

## 8. Important Boundary

This task does not repair:

```text
coupling_relief -> staged_unlock
```

That remains a separate task.

This task also does not tune H-DEPT pressure generation.

## 9. Next Step

The correct next step is to rerun the outcome-alignment audit against this
diagnostic policy output.

Suggested task:

```text
PressureOutcomeAlignmentAudit_RC2b
```

Purpose:

```text
Check whether semantic/action survival improves the ability to observe
pressure-outcome alignment.
```

After that, proceed to:

```text
CouplingReliefStagedUnlockRepair_RC1
```

if the staged unlock sequence remains weak.
