# Probe Restraint Primitive Patch RC1

## 0. Position

`ProbeRestraintPrimitivePatch_RC1` follows:

```text
ProbeRestraintPrimitiveCheck_RC1
```

It resolves the `sandbox_probe_entry_down` ambiguity by splitting the behavior
into two roles:

```text
direct_probe_restraint
stabilization_guard
```

## 1. Patch

```text
sandbox_probe_entry_down:
  direct_probe_restraint
  diagnostic_probe_restraint_direct_v1
  diagnostic_probe_restraint_direct

sandbox_probe_entry_down_stabilization:
  stabilization_guard
  diagnostic_probe_restraint_stabilization_guard
  buffer_increase
```

## 2. Boundary

This task does not:

```text
- tune H-DEPT pressure
- repair coupling_relief->staged_unlock
```

## 3. Outputs

```text
results/probe_restraint_primitive_patch_table_RC1.csv
results/probe_restraint_primitive_patched_action_frame_RC1.csv
results/probe_restraint_primitive_patch_alignment_RC1.csv
results/probe_restraint_primitive_patch_summary_RC1.csv
results/probe_restraint_primitive_patch_contract_basis_RC1.csv
results/probe_restraint_primitive_patch_summary_RC1.json
```
