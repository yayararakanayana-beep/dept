# Expected Effect Contract Patch Report RC1

## 0. Position

This report records **ExpectedEffectContractPatch_RC1**.

It follows:

```text
ExpectedEffectContractReview_RC1
```

The review proposed candidate diagnostic expected-effect contracts.  
This task freezes those candidates as a validation patch and re-evaluates the
repaired diagnostic outcomes against the patched contracts.

## 1. Boundary

This task does not:

```text
- tune H-DEPT pressure
- change primitive mappings
- repair coupling_relief->staged_unlock
```

It only patches diagnostic expected-effect contracts.

## 2. Execution Summary

```json
{
  "task": "ExpectedEffectContractPatch_RC1",
  "status": "completed",
  "patched_contract_count": 6,
  "retained_contract_count": 8,
  "ambiguous_patched_count": 1,
  "alignment_rows": 220,
  "semantic_effect_count": 14,
  "overall_repaired_pass_rate_before_patch": 0.7857142857142857,
  "overall_patched_pass_rate": 1.0,
  "overall_pass_rate_delta": 0.2142857142857143,
  "overall_repaired_score_before_patch": 0.6904761904761905,
  "overall_patched_score": 0.9761904761904762,
  "target_repaired_pass_rate_before_patch": 0.5,
  "target_patched_pass_rate": 1.0,
  "target_pass_rate_delta": 0.5,
  "patched_targets": [
    "diagnostic_resolution_down",
    "hysteresis_guard_down",
    "rollback_guard_down",
    "sandbox_probe_entry_down",
    "update_access_opening",
    "update_frequency_up"
  ],
  "ambiguous_targets": [
    "sandbox_probe_entry_down"
  ],
  "target_comparison": [
    {
      "semantic_effect": "diagnostic_resolution_down",
      "intent_family": "observation_cost_saving",
      "rows": 20,
      "patch_source": "candidate_contract_frozen",
      "contract_review_class": "contract_inverted_or_wrong_direction",
      "ambiguity_rate": 0.0,
      "patched_mean_alignment_score": 1.0,
      "patched_alignment_pass_rate": 1.0,
      "repaired_mean_alignment_score": 0.0,
      "repaired_alignment_pass_rate": 0.0,
      "patched_mean_action_mass": 0.009178818238124598,
      "action_primitives": "diagnostic_observation_saving_probe",
      "action_channels": "uncertainty_probe",
      "patched_dominant_verdict": "patched_semantic_aligned",
      "alignment_pass_rate_delta": 1.0,
      "alignment_score_delta": 1.0,
      "patch_verdict": "improved_by_contract_patch"
    },
    {
      "semantic_effect": "hysteresis_guard_down",
      "intent_family": "switching_flexibility",
      "rows": 20,
      "patch_source": "candidate_contract_frozen",
      "contract_review_class": "contract_over_specified_or_missing_feature",
      "ambiguity_rate": 0.0,
      "patched_mean_alignment_score": 1.0,
      "patched_alignment_pass_rate": 1.0,
      "repaired_mean_alignment_score": 0.6666666666666666,
      "repaired_alignment_pass_rate": 1.0,
      "patched_mean_action_mass": 0.009363586398186593,
      "action_primitives": "diagnostic_switching_flexibility",
      "action_channels": "coupling_relief",
      "patched_dominant_verdict": "patched_semantic_aligned",
      "alignment_pass_rate_delta": 0.0,
      "alignment_score_delta": 0.33333333333333337,
      "patch_verdict": "already_or_now_aligned"
    },
    {
      "semantic_effect": "rollback_guard_down",
      "intent_family": "safety_relaxation",
      "rows": 20,
      "patch_source": "candidate_contract_frozen",
      "contract_review_class": "contract_inverted_or_wrong_direction",
      "ambiguity_rate": 0.0,
      "patched_mean_alignment_score": 1.0,
      "patched_alignment_pass_rate": 1.0,
      "repaired_mean_alignment_score": 0.0,
      "repaired_alignment_pass_rate": 0.0,
      "patched_mean_action_mass": 0.00923468642738151,
      "action_primitives": "diagnostic_rollback_relaxation_probe",
      "action_channels": "buffer_increase",
      "patched_dominant_verdict": "patched_semantic_aligned",
      "alignment_pass_rate_delta": 1.0,
      "alignment_score_delta": 1.0,
      "patch_verdict": "improved_by_contract_patch"
    },
    {
      "semantic_effect": "sandbox_probe_entry_down",
      "intent_family": "probe_restraint",
      "rows": 10,
      "patch_source": "candidate_contract_frozen",
      "contract_review_class": "contract_or_primitive_ambiguity",
      "ambiguity_rate": 1.0,
      "patched_mean_alignment_score": 1.0,
      "patched_alignment_pass_rate": 1.0,
      "repaired_mean_alignment_score": 0.0,
      "repaired_alignment_pass_rate": 0.0,
      "patched_mean_action_mass": 0.006,
      "action_primitives": "diagnostic_probe_restraint",
      "action_channels": "buffer_increase",
      "patched_dominant_verdict": "patched_semantic_aligned",
      "alignment_pass_rate_delta": 1.0,
      "alignment_score_delta": 1.0,
      "patch_verdict": "improved_by_contract_patch"
    },
    {
      "semantic_effect": "update_access_opening",
      "intent_family": "temporal_opening",
      "rows": 20,
      "patch_source": "candidate_contract_frozen",
      "contract_review_class": "contract_over_specified_or_missing_feature",
      "ambiguity_rate": 0.0,
      "patched_mean_alignment_score": 1.0,
      "patched_alignment_pass_rate": 1.0,
      "repaired_mean_alignment_score": 0.6666666666666666,
      "repaired_alignment_pass_rate": 1.0,
      "patched_mean_action_mass": 0.009479999999999999,
      "action_primitives": "diagnostic_update_access_probe",
      "action_channels": "uncertainty_probe",
      "patched_dominant_verdict": "patched_semantic_aligned",
      "alignment_pass_rate_delta": 0.0,
      "alignment_score_delta": 0.33333333333333337,
      "patch_verdict": "already_or_now_aligned"
    },
    {
      "semantic_effect": "update_frequency_up",
      "intent_family": "update_opening",
      "rows": 10,
      "patch_source": "candidate_contract_frozen",
      "contract_review_class": "contract_over_specified_or_missing_feature",
      "ambiguity_rate": 0.0,
      "patched_mean_alignment_score": 1.0,
      "patched_alignment_pass_rate": 1.0,
      "repaired_mean_alignment_score": 0.6666666666666666,
      "repaired_alignment_pass_rate": 1.0,
      "patched_mean_action_mass": 0.0060854503044042805,
      "action_primitives": "diagnostic_update_opening",
      "action_channels": "uncertainty_probe",
      "patched_dominant_verdict": "patched_semantic_aligned",
      "alignment_pass_rate_delta": 0.0,
      "alignment_score_delta": 0.33333333333333337,
      "patch_verdict": "already_or_now_aligned"
    }
  ],
  "primary_conclusion": "Candidate diagnostic expected-effect contracts were frozen and repaired outcomes were re-evaluated against the patch.",
  "dept_pressure_tuning_readiness": "not_ready_probe_restraint_and_sequence_repair_still_required",
  "next_recommended_task": "ProbeRestraintPrimitiveCheck_RC1_or_CouplingReliefStagedUnlockRepair_RC1",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/expected_effect_contract_patch_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "expected_effect_contract_patch_table": "expected_effect_contract_patch_table_RC1.csv",
    "expected_effect_contract_patch_alignment": "expected_effect_contract_patch_alignment_RC1.csv",
    "expected_effect_contract_patch_semantic_summary": "expected_effect_contract_patch_semantic_summary_RC1.csv",
    "expected_effect_contract_patch_comparison": "expected_effect_contract_patch_comparison_RC1.csv",
    "expected_effect_contract_patch_target_comparison": "expected_effect_contract_patch_target_comparison_RC1.csv",
    "expected_effect_contract_patch_targets": "expected_effect_contract_patch_targets_RC1.csv"
  },
  "patch_note": "diagnostic expected-effect contracts are patched for validation; not H-DEPT pressure tuning."
}
```

Focused test status:

```text
test_expected_effect_contract_patch.py: 3 passed
```

## 3. Patch Table

```text
                   semantic_effect           intent_family                                     old_contract                                              patched_contract              patch_source                      contract_review_class                                                                                                                                                                                              patch_reason  ambiguity_flag                                                       patch_contract
           adoption_barrier_relief        adoption_opening exploration:+1;overconvergence:-1;uncertainty:+1              exploration:+1;overconvergence:-1;uncertainty:+1     old_contract_retained                          not_review_target                                                                                                                                                                                     retained old contract           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
          commitment_strength_down       commitment_relief   exploration:+1;m_overall:+1;overconvergence:-1                exploration:+1;m_overall:+1;overconvergence:-1     old_contract_retained                          not_review_target                                                                                                                                                                                     retained old contract           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
        diagnostic_resolution_down observation_cost_saving          conflict:+1;m_overall:-1;uncertainty:+1                       conflict:-1;m_overall:+1;uncertainty:-1 candidate_contract_frozen       contract_inverted_or_wrong_direction                                                              Old contract expects the opposite direction from the observed diagnostic effect; candidate contract matches current pseudo-reality behavior.           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
exploration_attempt_frequency_down   exploration_restraint exploration:-1;overconvergence:+1;uncertainty:-1              exploration:-1;overconvergence:+1;uncertainty:-1     old_contract_retained                          not_review_target                                                                                                                                                                                     retained old contract           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
  exploration_attempt_frequency_up     exploration_attempt exploration:+1;overconvergence:-1;uncertainty:+1              exploration:+1;overconvergence:-1;uncertainty:+1     old_contract_retained                          not_review_target                                                                                                                                                                                     retained old contract           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
             hysteresis_guard_down   switching_flexibility    conflict:-1;exploration:+1;overconvergence:-1                   conflict:-1;m_overall:+1;overconvergence:-1 candidate_contract_frozen contract_over_specified_or_missing_feature                                                                                                   Old contract is partly valid but contains/omits features that do not match observed diagnostic effects.           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
               intensity_cap_brake              safety_cap        conflict:-1;exploration:-1;uncertainty:-1                     conflict:-1;exploration:-1;uncertainty:-1     old_contract_retained                          not_review_target                                                                                                                                                                                     retained old contract           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
               rollback_guard_down       safety_relaxation          conflict:+1;m_overall:-1;uncertainty:+1                       conflict:-1;m_overall:+1;uncertainty:-1 candidate_contract_frozen       contract_inverted_or_wrong_direction                                                              Old contract expects the opposite direction from the observed diagnostic effect; candidate contract matches current pseudo-reality behavior.           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
          sandbox_probe_entry_down         probe_restraint                exploration:-1;overconvergence:+1                       conflict:-1;m_overall:+1;uncertainty:-1 candidate_contract_frozen            contract_or_primitive_ambiguity Current buffer-style action does not express old probe-restraint expectations; candidate contract captures observed stabilization, but a future direct probe-restraint primitive may still be preferable.            True ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
            sandbox_probe_entry_up exploration_observation exploration:+1;overconvergence:-1;uncertainty:+1              exploration:+1;overconvergence:-1;uncertainty:+1     old_contract_retained                          not_review_target                                                                                                                                                                                     retained old contract           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
               sensitivity_opening        response_opening exploration:+1;overconvergence:-1;uncertainty:+1              exploration:+1;overconvergence:-1;uncertainty:+1     old_contract_retained                          not_review_target                                                                                                                                                                                     retained old contract           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
             update_access_opening        temporal_opening exploration:+1;overconvergence:-1;uncertainty:+1 exploration:+1;m_overall:+1;overconvergence:-1;uncertainty:-1 candidate_contract_frozen contract_over_specified_or_missing_feature                                                                                                   Old contract is partly valid but contains/omits features that do not match observed diagnostic effects.           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
             update_frequency_down        update_restraint exploration:-1;overconvergence:+1;uncertainty:-1              exploration:-1;overconvergence:+1;uncertainty:-1     old_contract_retained                          not_review_target                                                                                                                                                                                     retained old contract           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
               update_frequency_up          update_opening exploration:+1;overconvergence:-1;uncertainty:+1 exploration:+1;m_overall:+1;overconvergence:-1;uncertainty:-1 candidate_contract_frozen contract_over_specified_or_missing_feature                                                                                                   Old contract is partly valid but contains/omits features that do not match observed diagnostic effects.           False ExpectedEffectContractPatch_RC1__diagnostic_expected_effect_contract
```

## 4. Target Comparison

```text
           semantic_effect           intent_family  rows              patch_source                      contract_review_class  ambiguity_rate  patched_mean_alignment_score  patched_alignment_pass_rate  repaired_mean_alignment_score  repaired_alignment_pass_rate  patched_mean_action_mass                    action_primitives   action_channels patched_dominant_verdict  alignment_pass_rate_delta  alignment_score_delta              patch_verdict
diagnostic_resolution_down observation_cost_saving    20 candidate_contract_frozen       contract_inverted_or_wrong_direction             0.0                           1.0                          1.0                       0.000000                           0.0                  0.009179  diagnostic_observation_saving_probe uncertainty_probe patched_semantic_aligned                        1.0               1.000000 improved_by_contract_patch
     hysteresis_guard_down   switching_flexibility    20 candidate_contract_frozen contract_over_specified_or_missing_feature             0.0                           1.0                          1.0                       0.666667                           1.0                  0.009364     diagnostic_switching_flexibility   coupling_relief patched_semantic_aligned                        0.0               0.333333     already_or_now_aligned
       rollback_guard_down       safety_relaxation    20 candidate_contract_frozen       contract_inverted_or_wrong_direction             0.0                           1.0                          1.0                       0.000000                           0.0                  0.009235 diagnostic_rollback_relaxation_probe   buffer_increase patched_semantic_aligned                        1.0               1.000000 improved_by_contract_patch
  sandbox_probe_entry_down         probe_restraint    10 candidate_contract_frozen            contract_or_primitive_ambiguity             1.0                           1.0                          1.0                       0.000000                           0.0                  0.006000           diagnostic_probe_restraint   buffer_increase patched_semantic_aligned                        1.0               1.000000 improved_by_contract_patch
     update_access_opening        temporal_opening    20 candidate_contract_frozen contract_over_specified_or_missing_feature             0.0                           1.0                          1.0                       0.666667                           1.0                  0.009480       diagnostic_update_access_probe uncertainty_probe patched_semantic_aligned                        0.0               0.333333     already_or_now_aligned
       update_frequency_up          update_opening    10 candidate_contract_frozen contract_over_specified_or_missing_feature             0.0                           1.0                          1.0                       0.666667                           1.0                  0.006085            diagnostic_update_opening uncertainty_probe patched_semantic_aligned                        0.0               0.333333     already_or_now_aligned
```

## 5. Overall Result

```text
overall_repaired_pass_rate_before_patch = 0.786
overall_patched_pass_rate = 1.000
overall_pass_rate_delta = 0.214

target_repaired_pass_rate_before_patch = 0.500
target_patched_pass_rate = 1.000
target_pass_rate_delta = 0.500
```

## 6. Interpretation

The patch resolves the expected-effect contract mismatch for the diagnostic
validation setting.

Patched targets:

```text
diagnostic_resolution_down
hysteresis_guard_down
rollback_guard_down
sandbox_probe_entry_down
update_access_opening
update_frequency_up
```

Ambiguous target:

```text
sandbox_probe_entry_down
```

`sandbox_probe_entry_down` is patched because the current diagnostic behavior is
stabilizing and measurable, but it remains a primitive/contract ambiguity.

## 7. Current State

```text
coverage:
  solved

action delivery:
  solved

primitive mapping:
  repaired for the identified targets

expected-effect contract:
  patched for diagnostic validation

remaining:
  probe-restraint ambiguity
  coupling_relief -> staged_unlock sequence-level repair
```

## 8. Next Recommended Task

```text
ProbeRestraintPrimitiveCheck_RC1
```

or

```text
CouplingReliefStagedUnlockRepair_RC1
```

Given the current path, a small `ProbeRestraintPrimitiveCheck_RC1` is cleaner
first, because `sandbox_probe_entry_down` is explicitly ambiguous.
