# Expected Effect Contract Patch RC1

## 0. Position

`ExpectedEffectContractPatch_RC1` follows:

```text
ExpectedEffectContractReview_RC1
```

It freezes the candidate diagnostic expected-effect contracts and re-evaluates
the repaired diagnostic outcomes against the patched contracts.

## 1. Boundary

This task does not:

```text
- tune H-DEPT pressure
- change primitive mappings
- repair coupling_relief->staged_unlock
```

It only patches validation expected-effect contracts.

## 2. Outputs

```text
results/expected_effect_contract_patch_table_RC1.csv
results/expected_effect_contract_patch_alignment_RC1.csv
results/expected_effect_contract_patch_semantic_summary_RC1.csv
results/expected_effect_contract_patch_comparison_RC1.csv
results/expected_effect_contract_patch_target_comparison_RC1.csv
results/expected_effect_contract_patch_targets_RC1.csv
results/expected_effect_contract_patch_summary_RC1.json
```

## 3. Next

After this patch, remaining likely tasks are:

```text
ProbeRestraintPrimitiveCheck_RC1
CouplingReliefStagedUnlockRepair_RC1
```
