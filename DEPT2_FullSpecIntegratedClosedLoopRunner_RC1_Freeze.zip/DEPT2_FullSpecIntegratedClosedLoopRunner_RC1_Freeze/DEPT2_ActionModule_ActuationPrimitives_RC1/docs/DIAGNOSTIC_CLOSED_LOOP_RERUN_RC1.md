# Diagnostic Closed Loop Rerun RC1

## 0. Position

`DiagnosticClosedLoopRerun_RC1` runs after:

```text
DiagnosticActionTranslationPolicy_RC1
PressureOutcomeAlignmentAudit_RC2b
```

RC2b showed:

```text
coverage fixed
outcome attribution pending
```

This task performs the missing step:

```text
weak diagnostic actions -> pseudo-reality -> observed outcome
```

## 1. What It Runs

Two compact replay modes:

```text
combined diagnostic rerun:
  all diagnostic actions for each scenario/step are applied together

isolated semantic rerun:
  one semantic_effect group is applied at a time
```

The isolated replay is used for clearer semantic-effect attribution.

## 2. Outputs

```text
results/diagnostic_closed_loop_combined_trace_RC1.csv
results/diagnostic_closed_loop_action_application_RC1.csv
results/diagnostic_closed_loop_semantic_isolated_alignment_RC1.csv
results/diagnostic_closed_loop_semantic_summary_RC1.csv
results/diagnostic_closed_loop_scenario_summary_RC1.csv
results/diagnostic_closed_loop_rerun_summary_RC1.json
```

## 3. Interpretation

This is still pseudo-reality validation.  
It does not prove real-world performance or justify DEPT pressure tuning yet.

The next step should review diagnostic outcome alignment before changing DEPT.
