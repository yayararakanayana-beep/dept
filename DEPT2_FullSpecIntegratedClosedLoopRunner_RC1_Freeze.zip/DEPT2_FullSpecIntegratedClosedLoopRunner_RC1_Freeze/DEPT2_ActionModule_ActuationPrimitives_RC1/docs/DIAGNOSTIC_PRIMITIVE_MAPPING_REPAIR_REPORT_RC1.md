# Diagnostic Primitive Mapping Repair Report RC1

## 0. Position

This report records **DiagnosticPrimitiveMappingRepair_RC1**.

It follows:

```text
DiagnosticClosedLoopRerunReview_RC1
```

The review found that action delivery and outcome attribution are now possible,
but several semantic effects still have poor diagnostic primitive mapping.

## 1. Scope

Repair targets:

```text
sensitivity_opening
exploration_attempt_frequency_down
update_frequency_down
```

This task does not:

```text
- tune H-DEPT pressure
- repair coupling_relief->staged_unlock
- revise expected-effect contracts
```

## 2. Repair Table

```text
                   semantic_effect  rows_repaired            old_action_primitives                  old_primitive_sequences old_action_channels                    new_action_primitive                                                   new_primitive_sequence               new_action_channel                                                                               repair_reason                                                                repair_contract
               sensitivity_opening             20   diagnostic_sensitivity_opening sensitivity_opening -> observe -> report     coupling_relief diagnostic_sensitivity_opening_probe_v2   sensitivity_opening -> exploratory_response_probe -> observe -> report            exploration_injection           opening semantics need exploration/uncertainty response, not only coupling relief DiagnosticPrimitiveMappingRepair_RC1__semantic_to_diagnostic_primitive_mapping
exploration_attempt_frequency_down              5 diagnostic_exploration_restraint         exploration_restraint -> observe     buffer_increase     diagnostic_exploration_restraint_v2 exploration_restraint -> reduce_exploration_attempt -> observe -> report diagnostic_exploration_restraint            restraint semantics need direct exploration reduction plus uncertainty reduction DiagnosticPrimitiveMappingRepair_RC1__semantic_to_diagnostic_primitive_mapping
             update_frequency_down             10      diagnostic_update_restraint              update_restraint -> observe     buffer_increase          diagnostic_update_restraint_v2             update_restraint -> reduce_update_churn -> observe -> report      diagnostic_update_restraint update restraint needs explicit exploration/update-churn reduction, not generic buffer only DiagnosticPrimitiveMappingRepair_RC1__semantic_to_diagnostic_primitive_mapping
```

## 3. Execution Summary

```json
{
  "task": "DiagnosticPrimitiveMappingRepair_RC1",
  "status": "completed",
  "repaired_semantic_targets": [
    "sensitivity_opening",
    "exploration_attempt_frequency_down",
    "update_frequency_down"
  ],
  "repaired_rows": 35,
  "repaired_action_frame_rows": 220,
  "isolated_alignment_rows": 220,
  "semantic_effect_count": 14,
  "overall_old_pass_rate": 0.5714285714285714,
  "overall_repaired_pass_rate": 0.7857142857142857,
  "target_old_pass_rate": 0.0,
  "target_repaired_pass_rate": 1.0,
  "target_pass_rate_delta": 1.0,
  "target_improved_count": 3,
  "target_count": 3,
  "target_comparison": [
    {
      "semantic_effect": "exploration_attempt_frequency_down",
      "intent_family": "exploration_restraint",
      "rows": 5,
      "mapping_repair_applied_rate": 1.0,
      "repaired_mean_alignment_score": 1.0,
      "repaired_alignment_pass_rate": 1.0,
      "repaired_mean_action_mass": 0.006,
      "repaired_action_primitives": "diagnostic_exploration_restraint_v2",
      "repaired_action_channels": "diagnostic_exploration_restraint",
      "repaired_mean_delta_conflict": -1.3125000000169251e-06,
      "repaired_mean_delta_uncertainty": -6.750000000033119e-06,
      "repaired_mean_delta_exploration": -1.4999999999987246e-05,
      "repaired_mean_delta_overconvergence": 1.049999999999801e-05,
      "repaired_mean_delta_m_overall": -1.8187499999955393e-05,
      "repaired_dominant_verdict": "repaired_semantic_aligned",
      "old_alignment_pass_rate": 0.0,
      "old_mean_alignment_score": 0.3333333333333333,
      "old_action_channels": "buffer_increase",
      "old_action_primitives": "diagnostic_exploration_restraint",
      "alignment_pass_rate_delta": 1.0,
      "alignment_score_delta": 0.6666666666666667,
      "comparison_verdict": "improved"
    },
    {
      "semantic_effect": "sensitivity_opening",
      "intent_family": "response_opening",
      "rows": 20,
      "mapping_repair_applied_rate": 1.0,
      "repaired_mean_alignment_score": 1.0,
      "repaired_alignment_pass_rate": 1.0,
      "repaired_mean_action_mass": 0.009456811823750324,
      "repaired_action_primitives": "diagnostic_sensitivity_opening_probe_v2",
      "repaired_action_channels": "exploration_injection",
      "repaired_mean_delta_conflict": 8.865761084442259e-07,
      "repaired_mean_delta_uncertainty": 3.5463044339018035e-06,
      "repaired_mean_delta_exploration": 2.3642029559377276e-05,
      "repaired_mean_delta_overconvergence": -1.654942069156673e-05,
      "repaired_mean_delta_m_overall": 3.2212265274694785e-05,
      "repaired_dominant_verdict": "repaired_semantic_aligned",
      "old_alignment_pass_rate": 0.0,
      "old_mean_alignment_score": 0.3333333333333333,
      "old_action_channels": "coupling_relief",
      "old_action_primitives": "diagnostic_sensitivity_opening",
      "alignment_pass_rate_delta": 1.0,
      "alignment_score_delta": 0.6666666666666667,
      "comparison_verdict": "improved"
    },
    {
      "semantic_effect": "update_frequency_down",
      "intent_family": "update_restraint",
      "rows": 10,
      "mapping_repair_applied_rate": 1.0,
      "repaired_mean_alignment_score": 1.0,
      "repaired_alignment_pass_rate": 1.0,
      "repaired_mean_action_mass": 0.00616145947450928,
      "repaired_action_primitives": "diagnostic_update_restraint_v2",
      "repaired_action_channels": "diagnostic_update_restraint",
      "repaired_mean_delta_conflict": -2.195019937822895e-06,
      "repaired_mean_delta_uncertainty": -1.0012371646095363e-05,
      "repaired_mean_delta_exploration": -1.1552736514691687e-05,
      "repaired_mean_delta_overconvergence": 8.317970290584036e-06,
      "repaired_mean_delta_m_overall": -1.320862874845119e-05,
      "repaired_dominant_verdict": "repaired_semantic_aligned",
      "old_alignment_pass_rate": 0.0,
      "old_mean_alignment_score": 0.3333333333333333,
      "old_action_channels": "buffer_increase",
      "old_action_primitives": "diagnostic_update_restraint",
      "alignment_pass_rate_delta": 1.0,
      "alignment_score_delta": 0.6666666666666667,
      "comparison_verdict": "improved"
    }
  ],
  "non_target_ready_preserved_rate": 0.7272727272727273,
  "primary_conclusion": "Target primitive mappings were repaired and rerun; target alignment should be reviewed before expected-effect contract changes.",
  "dept_pressure_tuning_readiness": "not_ready_expected_contract_review_still_required",
  "next_recommended_task": "ExpectedEffectContractReview_RC1",
  "all_sanity_checks_passed": true,
  "results_dir": "/mnt/data/diagnostic_primitive_mapping_repair_work/DEPT2_ActionModule_ActuationPrimitives_RC1/results",
  "outputs": {
    "diagnostic_primitive_mapping_repair_table": "diagnostic_primitive_mapping_repair_table_RC1.csv",
    "diagnostic_primitive_mapping_repaired_action_frame": "diagnostic_primitive_mapping_repaired_action_frame_RC1.csv",
    "diagnostic_primitive_mapping_repair_isolated_alignment": "diagnostic_primitive_mapping_repair_isolated_alignment_RC1.csv",
    "diagnostic_primitive_mapping_repair_semantic_summary": "diagnostic_primitive_mapping_repair_semantic_summary_RC1.csv",
    "diagnostic_primitive_mapping_repair_comparison": "diagnostic_primitive_mapping_repair_comparison_RC1.csv",
    "diagnostic_primitive_mapping_repair_target_comparison": "diagnostic_primitive_mapping_repair_target_comparison_RC1.csv"
  }
}
```

Focused test status:

```text
test_diagnostic_primitive_mapping_repair.py: 3 passed
```

## 4. Target Comparison

```text
                   semantic_effect         intent_family  rows  mapping_repair_applied_rate  repaired_mean_alignment_score  repaired_alignment_pass_rate  repaired_mean_action_mass              repaired_action_primitives         repaired_action_channels  repaired_mean_delta_conflict  repaired_mean_delta_uncertainty  repaired_mean_delta_exploration  repaired_mean_delta_overconvergence  repaired_mean_delta_m_overall repaired_dominant_verdict  old_alignment_pass_rate  old_mean_alignment_score old_action_channels            old_action_primitives  alignment_pass_rate_delta  alignment_score_delta comparison_verdict
exploration_attempt_frequency_down exploration_restraint     5                          1.0                            1.0                           1.0                   0.006000     diagnostic_exploration_restraint_v2 diagnostic_exploration_restraint                 -1.312500e-06                        -0.000007                        -0.000015                             0.000010                      -0.000018 repaired_semantic_aligned                      0.0                  0.333333     buffer_increase diagnostic_exploration_restraint                        1.0               0.666667           improved
               sensitivity_opening      response_opening    20                          1.0                            1.0                           1.0                   0.009457 diagnostic_sensitivity_opening_probe_v2            exploration_injection                  8.865761e-07                         0.000004                         0.000024                            -0.000017                       0.000032 repaired_semantic_aligned                      0.0                  0.333333     coupling_relief   diagnostic_sensitivity_opening                        1.0               0.666667           improved
             update_frequency_down      update_restraint    10                          1.0                            1.0                           1.0                   0.006161          diagnostic_update_restraint_v2      diagnostic_update_restraint                 -2.195020e-06                        -0.000010                        -0.000012                             0.000008                      -0.000013 repaired_semantic_aligned                      0.0                  0.333333     buffer_increase      diagnostic_update_restraint                        1.0               0.666667           improved
```

## 5. Overall Comparison

```text
overall_old_pass_rate = 0.571
overall_repaired_pass_rate = 0.786

target_old_pass_rate = 0.000
target_repaired_pass_rate = 1.000
target_pass_rate_delta = 1.000
```

## 6. Interpretation

The repaired target mappings all improved in the compact isolated rerun.

Main changes:

```text
sensitivity_opening:
  coupling_relief
  -> exploration_injection

exploration_attempt_frequency_down:
  buffer_increase
  -> diagnostic_exploration_restraint

update_frequency_down:
  buffer_increase
  -> diagnostic_update_restraint
```

The key idea:

```text
opening semantics need an opening/probe channel
restraint semantics need explicit exploration/update restraint
```

The restraint channels are validation-only diagnostic channels for pseudo-reality
testing.

## 7. Boundary

This improvement is about the diagnostic primitive mapping.

It does not mean DEPT pressure tuning is ready, because expected-effect contract
review is still required for:

```text
diagnostic_resolution_down
rollback_guard_down
sandbox_probe_entry_down
hysteresis_guard_down
update_access_opening
update_frequency_up
```

## 8. Next Recommended Task

```text
ExpectedEffectContractReview_RC1
```

Purpose:

```text
Separate true primitive failure from mismatched expected-outcome contracts.
```

After that, the separate sequence-level repair remains:

```text
CouplingReliefStagedUnlockRepair_RC1
```
