# Task3: world_adapter + gk_builder 統合確認・強化 RC1

## 位置づけ

Task3は、FullSpec Integrated Closed Loop Runner の最初の基礎境界を固めるタスクです。

対象は以下の2モジュールです。

1. `world_adapter`
2. `gk_builder`

Task2では13モジュールの最小skeletonを作りました。
Task3では、そのうち「疑似現実」と「G/K生成」の境界を強化しました。

---

## 固定した原則

### world_adapter

`world_adapter` は疑似現実状態を所有します。
DEPT2内部モジュールは、疑似現実そのものを直接変更しません。

許可される流れは以下です。

```text
PseudoReality state
  ↓ emit_trace
world trace
  ↓ G/K builder / O_t builder が読む
DEPT2 pipeline
  ↓ ActionFrame
ActionModule
  ↓ world_adapter.step
PseudoReality transition
```

禁止される流れは以下です。

```text
G/K → worldへ書き戻し
O_t → worldへ書き戻し
parameter shadow → worldへ直接書き戻し
upper pressure → worldへ直接作用
```

### gk_builder

`gk_builder` は `world_state + trace` から G_t / K_t を作ります。

守るルールは以下です。

```text
G/Kは毎周回world traceから生成する
G/Kはworld traceを変更しない
G/Kに正式候補を置かない
G/K formal inputにO_t/v8/exploration/action_surfaceを混ぜない
```

---

## 追加した監査

### world_trace_audit

各stepで、G/K生成前のworld traceを監査します。

主な項目:

- `trace_contract`
- `trace_fingerprint`
- `world_t`
- `entity_rows`
- `relation_rows`
- `schema_valid`
- `dept_internal_columns_present`
- `gk_written_back_to_world`
- `ot_written_back_to_world`
- `canonical_parameter_written_to_world`

### world_transition_audit

ActionFrame適用後の世界遷移を監査します。

主な項目:

- `trace_before_fingerprint`
- `trace_after_fingerprint`
- `world_t_before`
- `world_t_after`
- `mean_delta_*`
- `gk_writeback_performed`
- `ot_writeback_performed`
- `canonical_parameter_write_performed`

### gk_build_audit

G/K生成がtraceを汚染していないかを監査します。

主な項目:

- `gk_build_contract`
- `source_trace_fingerprint_before`
- `source_trace_fingerprint_after`
- `source_trace_mutated_by_gk_builder`
- `source_world_t`
- `gt_rows`
- `kt_rows`
- `formal_packet_rows`
- `formal_lower_leak_count`
- `gk_writeback_performed`
- `build_status`

---

## 実行結果

確認実行:

```bash
python runner/run_fullspec_integrated_closed_loop_runner_rc1.py --steps 3 --seed 42 --scenario normal --out results
```

結果:

```text
cycle_rows: 3
action_frame_rows: 440
residual_noise_rows: 54
world_trace_audit_rows: 3
world_transition_audit_rows: 3
gk_build_audit_rows: 3
boundary_violation_count: 0
all_sanity_checks_passed: true
```

テスト:

```text
6 passed
```

---

## Task3でまだ行っていないこと

Task3では以下はまだ本統合していません。

- O_t observation module の詳細強化
- residual noise ledger の詳細設計
- 探索候補生成
- 探索sandbox本統合
- v8 local audit本統合
- exploration bridge本統合
- coactivation gateの高度化

これらは後続Taskで扱います。

---

## 次の自然なタスク

次は固定済み順序どおり、以下が自然です。

```text
Task4:
O_t observation module + residual noise ledger 強化
```

Task3で world trace と G/K の境界が固まったため、次はその下位局所観測面として O_t を強化できます。
