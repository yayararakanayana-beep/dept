# Module Boundary Contract Task17 RC1

Task17では、Task16までの13モジュール境界を維持したままstress/scenario validationを行う。

## 維持する境界

1. world_adapter は疑似現実状態を所有する。G/K・O_t・parameter shadowから直接書き戻されない。
2. gk_builder は world trace から G/K を生成する。G/Kへ正式候補や作用結果を書き戻さない。
3. O_t は局所観測面であり、G/K生成器でも上位圧formal inputでもない。
4. upper_pressure_module は G/K formal packet のみを正式入力にする。
5. parameter_shadow_box は shadow-only。canonical write /本更新は禁止。
6. exploration_module は候補生成・sandbox・decisionを行うが、圧生成・作用実行・parameter更新はしない。
7. local_audit_module は v8局所監査専用。G/K生成・ActionModule呼び出しは禁止。
8. pressure_translation_module は上位圧をH11局所受圧場とPressureIntentBundleへ翻訳する。ActionFrameは作らない。
9. action_surface_planning_module はActionFrame前の作用候補を作る。ActionModuleは呼ばない。
10. exploration_bridge_module は薄いprojectionと非圧縮sidecarを分ける。sidecarはActionModuleへ直接渡さない。
11. coactivation_gate_module はActionFrame前の安全門。ActionFrame生成・ActionModule呼び出し・writebackは禁止。
12. action_execution_module はActionFrameを作り、ActionModuleをActionFrameのみで呼ぶ。
13. audit_ledger_module / boundary_guard は診断専用。runtime stateを変更しない。

## Task17固有の扱い

stress条件でwatch flagが出ることは境界違反ではない。境界違反とwatchは分けて記録する。

- boundary violation: fail
- unverified exploration leak: fail
- sanity check failure: fail
- high residual/noise: watch
- coactivation dampen/defer zone: watch
- local observation need high: watch

## RC1 claim boundary

stress diagnostic only。現実安全性、万能性、複合干渉の完全解決は主張しない。
