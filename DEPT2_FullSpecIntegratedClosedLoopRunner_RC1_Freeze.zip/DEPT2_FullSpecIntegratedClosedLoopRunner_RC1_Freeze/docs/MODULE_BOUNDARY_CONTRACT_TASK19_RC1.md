# Module Boundary Contract Task19 RC1

## Hard boundaries

1. `world_adapter` owns pseudo-reality state and trace.
2. `gk_builder` builds G/K from world state + trace only.
3. `O_t` is local observation, not G/K builder and not upper formal input.
4. `upper_pressure_module` uses formal G/K packet only.
5. `parameter_shadow_box` performs shadow-only updates; no canonical write.
6. `exploration_module` may generate and test candidates, but may not act directly.
7. `local_audit_module` is local audit only; no G/K generation and no pressure generation.
8. `pressure_translation_module` translates pressure; it does not build ActionFrame.
9. `action_surface_planning_module` creates pre-gate action candidates only.
10. `exploration_bridge_module` separates thin projection and full sidecar.
11. `coactivation_gate_module` must run before ActionFrame creation.
12. `action_execution_module` passes only ActionFrame to ActionModule.
13. `audit_ledger_module` records; it does not control or write back.
14. `boundary_guard` diagnoses and reports; it does not mutate core state.

## Forbidden flows

- ActionModule → G/K
- ActionModule → O_t
- ActionModule → v8/local audit internals
- ActionModule → exploration sidecar
- ActionModule → parameter shadow box
- O_t → upper pressure formal input
- v8/local audit → upper pressure formal input
- exploration candidates → ActionFrame without sandbox/local-audit bridge
- shadow update → canonical parameter write
- any module → G/K writeback
