# Task11: pressure_translation_module Integration RC1

## Goal

Strengthen the pressure translation layer so that upper weak pressure is converted into lower-readable pressure intent without collapsing information prematurely.

## Inputs

- `m_observation`: M_t derived from formal G/K only.
- `weak_pressure`: approved weak pressure components from the upper pressure module.

The module does not accept O_t, v8, exploration outputs, action candidates, ActionFrame, or ActionModule results.

## Outputs

1. `h11_local_pressure_field`
   - H11-local received pressure per H11 dimension and pressure component.
   - Preserves component identity.
   - Keeps reception as local pressure field, not action command.

2. `pressure_intent_bundle`
   - Semantic pressure intent annotations.
   - Preserves component identity and sign direction.
   - Annotates control domain, semantic effect, intent family, and suggested control route.
   - Does not compress into a single action label before the planner.

3. `pressure_translation_audit`
   - Confirms non-compressive translation.
   - Confirms component identity and direction preservation.
   - Confirms ActionFrame was not created by translation.
   - Confirms ActionModule was not called by translation.
   - Confirms no writeback to G/K/world/canonical state.

## Boundary rules

```text
pressure_translation_module:
  allowed input:
    M_t
    weak pressure

  forbidden input:
    O_t
    v8
    exploration result
    action surface result
    ActionFrame
    ActionModule result

  forbidden output side effects:
    ActionFrame creation
    ActionModule call
    G/K writeback
    world writeback
    canonical parameter write
```

## Reason

This layer is the bridge from abstract upper pressure to lower-readable pressure intent. If it compresses pressure too early, downstream modules lose information about which pressure component acted, which H11 dimension received it, and which semantic route was implied. Task11 keeps this information available until the action surface planner.

## Validation result

```text
pressure_translation_audit_rows: 3
pressure_translation_audit_passed: true
pressure_translation_noncompressive_passed: true
pressure_translation_components_preserved: true
pressure_translation_direction_preserved: true
boundary_violation_count: 0
```
