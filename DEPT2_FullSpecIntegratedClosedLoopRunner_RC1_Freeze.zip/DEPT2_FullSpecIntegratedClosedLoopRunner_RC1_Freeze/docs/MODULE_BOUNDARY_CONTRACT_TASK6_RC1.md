# MODULE BOUNDARY CONTRACT TASK6 RC1

## 固定境界

Task6 では、次の境界を固定する。

```text
world_adapter:
  疑似現実状態とstepを所有する。
  DEPT内部の仮説やshadow stateから直接書き戻されない。

gk_builder:
  world_state + trace から G_t / K_t を毎周回生成する。
  G/Kへの書き戻しは禁止。

ot_observation_module:
  O_t_native / O_t_action_view / O_t_exploration_view / residual_noise_log を出す。
  G/K生成器ではない。
  上位圧formal inputではない。

upper_pressure_module:
  formal G/K packet のみから M_t と weak pressure を出す。
  O_t / v8 / exploration / action 情報を混ぜない。

pressure_translation_module:
  weak pressure を H11 local pressure field と PressureIntentBundle に翻訳する。
  まだActionFrameは作らない。

parameter_shadow_box:
  H11 local pressure field と formal G/K を使って bounded shadow update を行う。
  shadow carryoverは許可。
  本更新は禁止。
  canonical theta writeは禁止。
  world writeは禁止。
  G/K writebackは禁止。

exploration_module:
  Task6ではplaceholder boundary。
  未検証候補は作用側へ渡さない。

action_execution_module:
  ActionFrameを作り、ActionModuleを呼ぶ。
  ActionModuleはActionFrameだけを読む。
```

## parameter_shadow_box 入力契約

許可入力:

```text
formal_packet:
  gk_builderが作った formal G/K packet

h11_local_pressure_field:
  pressure_translation_module が作った H11 local pressure field
```

禁止入力:

```text
O_t
v8
exploration result
exploration sidecar
action_surface
action_candidate
ActionFrame
ActionModule result
world truth
```

## parameter_shadow_box 出力契約

```text
parameter_registry:
  参照用registry。canonical theta storeではない。

parameter_updates:
  shadow-only更新差分。

shadow_parameter_state:
  runner-owned shadow state。

parameter_shadow_audit:
  commit禁止・bounded delta・carryover・rollback-readyの監査。
```

## 禁止claim

```text
本パラメーター更新完了
canonical theta更新可能
world state更新可能
G/K writeback可能
現実投入可能
安全性証明済み
```

## 許可claim

```text
限定的な疑似現実閉ループrunnerにおいて、
parameter_shadow_box を shadow-only bounded carryover として統合し、
本更新禁止・canonical write禁止・world/GK writeback禁止を監査可能にした。
```
