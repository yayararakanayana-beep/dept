# Task18: Ablation Validation RC1

## 目的

Task18 は、Task17 までで統合された FullSpec Integrated Closed Loop Runner から主要部品を制御的に外し、各部品の寄与を切り分ける検証である。

目的は性能優位性の主張ではない。目的は、以下を確認することにある。

- 探索、ノイズ台帳、v8局所監査、探索橋、同時発火門、shadow更新がそれぞれ何に効いているか
- 外しても境界違反にならない部品と、機能低下が明確に出る部品を分けること
- Task19 freeze 前に残すべき watch 項目を明示すること

## 実行したablation matrix

- A00 full integrated baseline
- A01 no exploration module
- A02 no residual noise ledger signal
- A03 no local audit signal
- A04 no exploration bridge projection
- A05 no coactivation gate modulation
- A06 no parameter shadow delta

## ablation の扱い

Task18 では、危険な境界違反を起こすために部品を壊すのではなく、境界を守ったまま寄与だけを取り除く。

例:

- noise ledger ablation は、ノイズ行を捨てず、信号強度だけをゼロ化する。
- local audit ablation は、v8をG/K生成器やActionModule入力にせず、確認信号だけを無効化する。
- exploration bridge ablation は、sidecarを非圧縮保持したまま、action-readable projectionだけを無効化する。
- coactivation gate ablation は、gate呼び出し自体は残し、decisionをallowに固定する。
- parameter shadow ablation は、shadow-only契約は残し、deltaだけをゼロ化する。

## 固定した検査観点

- boundary violation がないこと
- canonical parameter write がないこと
- world/G/K/O_t への不正書き戻しがないこと
- unverified exploration candidate がprojection化されないこと
- sidecarが非圧縮で保持されること
- gateはActionFrame前に存在すること
- ActionModuleはActionFrameだけを受け取ること
- ablationによる機能低下がmatrixとdeltaに残ること

## 結果要約

7ケースを実行した。

- pass: 2
- pass_with_ablation_effect: 5
- fail: 0
- boundary violation: 0
- canonical write: 0
- world write by shadow: 0
- G/K writeback: 0

主な観測結果:

- exploration moduleをoffにすると、exploration projection は0になる。
- noise ledger signalを消すと、noise visibility が消え、探索projectionとActionFrame強度が変化する。
- local audit signalを消すと、探索projectionが成立しなくなる。
- exploration bridge projectionを消すと、sidecarは残るが作用側への探索寄与は落ちる。
- coactivation gate modulationを消すと、riskがある状態でもallowになり、ActionFrame強度が上がる。
- parameter shadow deltaを消すと、仮パラメーター更新の遅延寄与が消える。

## 重要な非claim

Task18 は以下を主張しない。

- 現実投入可能
- 安全性証明済み
- deployment-ready
- combined interference solved
- 本パラメーター更新可能
- canonical write可能
- 各モジュールの最適性

Task18 の許される主張は、限定的な疑似現実ablation matrixにおいて、主要部品の寄与を境界違反なしに診断可能にした、という範囲に限る。

## 次タスク

次は Task19: FullSpec Integrated Closed Loop Runner RC1 Freeze。

ただし、Task19前に追加で見るなら、Task18bとして以下を行う余地がある。

- coactivation gate threshold sensitivity
- exploration projection strength sensitivity
- noise ledger threshold sensitivity
- local audit threshold sensitivity
