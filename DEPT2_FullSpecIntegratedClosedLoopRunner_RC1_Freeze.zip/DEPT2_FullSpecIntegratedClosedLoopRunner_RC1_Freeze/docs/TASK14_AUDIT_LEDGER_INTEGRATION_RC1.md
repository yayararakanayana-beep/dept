# Task14: audit_ledger_module Integration RC1

## Goal

Strengthen the FullSpec runner audit layer by consolidating distributed module
artifacts and audits into a unified ledger that can support later boundary tests,
minimal integration tests, stress/scenario tests, and ablation validation.

## Scope

Task14 is an audit integration task.  It does not change the control pathway.
It indexes and validates what the previous modules already produce.

## Added structures

### 1. unified_audit_ledger

Per-cycle, per-module table.  The expected shape is:

```text
rows = steps * 13 modules
```

It tracks module order, input refs, output refs, audit table, audit status, and
whether the module boundary is OK.

### 2. artifact_trace_index

A persisted output index for every table produced by the runner.  This makes it
possible to know which tables exist, how many rows they have, and whether they
are tagged with loop step, seed, and scenario.

### 3. module_dependency_audit

Ordered module dependency edges.  This is intentionally explicit so later tests
can verify that dependency direction remains clean:

```text
world -> G/K -> upper pressure -> pressure translation -> shadow/action planning
```

and that ActionModule does not receive direct G/K, O_t, v8, sidecar, or parameter
box inputs.

### 4. audit_ledger_summary

One-row Task14 proof table.

## Non-mutation rule

The audit ledger must not write back to runtime state.  It is a recorder, not a
controller.

Forbidden:

```text
audit_ledger -> world write
audit_ledger -> G/K write
audit_ledger -> O_t write
audit_ledger -> canonical parameter write
audit_ledger -> ActionModule input
```

## Validation

Task14 tests check:

- all 13 modules are indexed for every cycle,
- all persisted artifacts are indexed,
- module dependency direction is preserved,
- no reverse core dependency is introduced,
- no direct core input reaches ActionModule,
- no canonical write is introduced,
- audit ledger summary passes.

## Result

```text
39 passed
boundary_violation_count: 0
all_sanity_checks_passed: true
```
