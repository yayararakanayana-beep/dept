# Task14: Action Execution Integration RC1

## Goal

Strengthen the modular FullSpec runner by making `action_execution_module` the
only module that:

1. builds ActionFrame after the coactivation gate, and
2. calls the ActionModule adapter through ActionFrame-only input.

## Boundary

Task14 fixes the following boundary:

```text
ActionSurfacePlanning -> pre-gate candidates only
CoactivationGate -> allow / dampen / defer / block / monitor_only
ActionExecution -> ActionFrame + adapter call
ActionModule -> reads ActionFrame only
WorldAdapter -> steps pseudo-reality from ActionFrame
```

The ActionModule must not directly read:

```text
G/K
O_t
v8 internals
exploration sidecar
parameter box
canonical parameter state
```

## Implementation notes

Task14 adds:

- `action_frame_id`,
- `action_frame_builder_contract`,
- `action_execution_stage`,
- ActionFrame-only boundary flags,
- `action_execution_audit`,
- cycle audit fields for action execution status,
- boundary guard validation for the ActionFrame / ActionModule adapter boundary.

The world transition continues to occur through:

```text
world_adapter.step(action_frame)
```

This preserves the separation:

```text
DEPT2 judgment / planning -> ActionFrame -> ActionModule adapter -> pseudo-reality
```

## Validation

Task14 validates that:

- action execution audit is emitted once per cycle,
- coactivation gate is applied before ActionFrame generation,
- ActionFrame contract is present,
- ActionModule is called by adapter,
- ActionModule receives ActionFrame only,
- direct G/K/O_t/v8/sidecar/parameter-box input is not passed,
- no canonical parameter write is performed,
- no G/K or O_t writeback is performed,
- world time advances exactly one step through adapter execution.

## Scope limit

Task14 does not implement the full exploration module or final coactivation-gate
logic. Those remain downstream tasks.
