# Module Boundary Contract - Task11 RC1

## Module

`action_surface_planning_module`

## Allowed inputs

- `graph_objects`
- `O_t_action_view`
- `PressureIntentBundle`
- shadow parameter summary
- exploration projection placeholder

## Outputs

- `action_affordance`
- `action_candidates`
- `local_observation_needs`
- `action_surface_planning_audit`
- `sequence_events` side-channel

## Required guarantees

```text
action candidates are pre-gate candidates
action candidates are not ActionFrame
action planner does not call ActionModule
ActionModule receives only ActionFrame downstream
action planner does not read G/K directly
action planner does not write G/K
action planner does not write world
action planner does not write canonical parameter
O_t_action_view is not ActionModule direct input
O_t_action_view is not upper pressure formal input
```

## Guarded failure modes

- missing planning audit
- candidate without pre-ActionFrame contract
- planning creates ActionFrame
- planning calls ActionModule
- planning performs writeback
- local observation needs missing
- O_t direct ActionModule input
