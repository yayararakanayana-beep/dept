# Module Boundary Contract - Task4 RC1

## Task4で固定した境界

### world_adapter

疑似現実状態の所有者です。
G/K、O_t、parameter shadow、ActionModule内部はworldへ書き戻しません。

### gk_builder

world traceからG/Kを生成します。
G/Kは毎周回再生成されます。
O_t、v8、exploration、action_surfaceの情報はformal packetへ混ぜません。

### ot_observation_module

下位局所観測面を作ります。

```text
world trace + G/K + lower graph objects
↓
O_t_native
O_t_action_view
O_t_exploration_view
residual_noise_log
```

禁止事項:

```text
G/K生成器化
上位圧formal input化
ActionModule直接入力化
world / G/Kへの書き戻し
```

### residual_noise_log

未分類ノイズを保存する台帳です。

禁止事項:

```text
低ノイズ行の破棄
未分類ノイズの破棄
G/Kへの書き戻し
worldへの書き戻し
上位圧formal inputへの混入
```

### action_surface_planning_module

O_t_action_viewを作用候補生成前の局所文脈として使います。
ただし、ActionModuleにO_tを直接読ませません。

### ActionModule

ActionModuleの入力はActionFrameだけです。

```text
ActionModule reads:
  ActionFrame only

ActionModule does not read:
  G/K
  O_t
  v8
  exploration sidecar
  parameter box
```

## Task4 guard対象

```text
O_t required fields
O_t no G/K generation
O_t no formal upper input
O_t no ActionModule direct input
O_t no world writeback
residual_noise_log required fields
residual_noise_log all rows retained
residual_noise_log no G/K/world writeback
noise ledger audit present
cycle audit row contains O_t/noise counts
```
