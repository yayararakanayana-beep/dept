# Task15: Boundary Guard Integration RC1

## Goal

Integrate `boundary_guard` as a first-class guard layer for the modular FullSpec
closed-loop runner.

The guard collects the boundary assumptions that have been fixed across Task3 to
Task14 and makes them visible as a per-cycle invariant audit.

## Scope

Task15 strengthens diagnostics only. It does not change the core control policy,
ActionModule logic, exploration logic, parameter commit behavior, or canonical
world/G/K state.

## New artifacts

| Artifact | Meaning |
|---|---|
| `boundary_guard_audit` | One row per invariant per cycle. |
| `boundary_violation_report` | Empty when all guard rules pass; contains failed guard rules and legacy validation violations otherwise. |
| `boundary_guard_summary` | One-row summary of guard status. |

## Boundary rule families

1. world / trace ownership
2. G/K read-only generation
3. O_t separation
4. residual/noise retention
5. G/K-only upper pressure
6. non-compressive pressure translation
7. shadow-only parameter updates
8. exploration placeholder containment
9. sidecar/projection separation
10. pre-ActionFrame action planning
11. coactivation gate before ActionFrame
12. ActionModule ActionFrame-only boundary
13. cycle audit row completeness
14. guard diagnostic-only contract

## Pass condition

```text
boundary_guard_audit exists
boundary_guard_summary.boundary_guard_status == pass
boundary_violation_report has 0 rows
cycle boundary_violation_count == 0
all_sanity_checks_passed == true
```

## Non-claims

Task15 does not prove safety, deployment readiness, or final combined-interference
resolution. It only freezes the diagnostic guard layer for the current modular
runner.
