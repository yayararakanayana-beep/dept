# Task19: FullSpec Integrated Closed Loop Runner RC1 Freeze

## 1. 位置づけ

Task19は、Task2〜Task18で作成した統合runnerを **RC1 freeze package** として固定する段階である。

ここでは新しい制御能力を追加しない。目的は、すでに統合済みの閉ループ実行器について、再実行可能性・境界契約・検証結果・claim範囲を固定することである。

## 2. Freeze対象

Freeze対象は以下である。

```text
DEPT2 FullSpec Integrated Closed Loop Runner RC1
```

含まれる主要モジュールは以下。

1. world_adapter
2. gk_builder
3. ot_observation_module
4. upper_pressure_module
5. parameter_shadow_box
6. exploration_module
7. local_audit_module
8. pressure_translation_module
9. action_surface_planning_module
10. exploration_bridge_module
11. coactivation_gate_module
12. action_execution_module
13. audit_ledger_module / boundary_guard

## 3. Freeze済みの流れ

```text
PseudoReality state / trace
→ G_t / K_t
→ O_t_native / O_t_action_view / O_t_exploration_view / residual_noise_log
→ M_t / weak pressure
→ shadow parameter state
→ H11 local pressure field / PressureIntentBundle
→ exploration candidates / sandbox / local audit
→ exploration projection + full sidecar
→ action candidates / local observation needs
→ coactivation gate decision
→ ActionFrame
→ ActionModule adapter
→ PseudoReality transition
→ unified audit ledger / boundary guard
```

## 4. Freeze条件

Task19では以下をfreeze条件とする。

- Task16 minimal integration matrix がpassする。
- Task17 stress matrix がfailを出さない。
- Task18 ablation matrix がfailを出さない。
- 境界違反が0である。
- canonical parameter write が0である。
- shadowからworldへの直接writeが0である。
- G/K writeback が0である。
- ActionModule が ActionFrame のみを正式入力として受け取る。
- residual noise ledger が保持される。
- exploration sidecar が保持される。
- coactivation gate がActionFrame前に動く。

## 5. RC1として許されるclaim

このパッケージで許されるclaimは以下に限定する。

> 限定的な疑似現実上で、観測・圧・探索・作用・監査を統合したFullSpec Integrated Closed Loop Runner RC1を凍結した。

## 6. RC1で禁止するclaim

以下は主張しない。

- 現実投入可能
- 安全性証明済み
- deployment-ready
- 外部ベンチマーク優位
- combined interference solved
- 本パラメーター更新可能
- canonical write可能
- G/K writeback可能
- 人間・制度・現実系への実運用可能性

## 7. 次フェーズ

次に自然なのは、RC1 freezeを起点にした以下のどちらかである。

- Task20: 本更新前段のcommit proposal設計
- Task20b: stress / ablation watch項目の追加深掘り

ただし、本パラメーター更新はまだ許可しない。
