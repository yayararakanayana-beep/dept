# Task10: exploration_bridge_module Integration RC1

Task10 strengthens the exploration bridge between verified exploration candidates and downstream action-side planning.

## Input

- `exploration_decision`
- `exploration_sandbox`
- `exploration_local_audit`

## Output

- `exploration_projection`
- `exploration_sidecar`

## Contract

The bridge must separate exploration information into:

- a thin action-readable projection;
- a full, non-compressed sidecar for audit and recovery.

Only candidates satisfying all of the following may be projected:

- `decision_status == sandbox_pass`
- `sandbox_verified == True`
- `local_audit_passed == True`
- `v8_support_status == pass`
- `unverified_candidate_can_pass == False`

The bridge must not:

- write to world;
- write to G/K;
- write to O_t;
- update ParameterBox;
- create ActionFrame;
- call ActionModule;
- pass full sidecar into ActionModule.

## Boundary guard

Task10 strengthens `BG11_exploration_sidecar_retained_projection_thin` so that it checks:

- sidecar exists;
- full context is present;
- sidecar is non-compressed;
- if any candidate is projection-eligible, projection rows exist;
- projection rows are thin;
- projection rows are verified;
- projection rows passed local audit;
- sidecar is not direct ActionModule input.
