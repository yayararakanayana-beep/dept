# Module Boundary Contract - Task5 RC1

## Task5で追加された境界

### upper_pressure_module

入力:

```text
formal_packet
```

出力:

```text
M_t
weak_pressure
upper_pressure_audit
```

正式入力は `formal_packet` のみ。
`formal_packet` は `gk_builder` が `world_state + trace` から作った `G_t / K_t` の正式パケットである。

## 入力禁止

`upper_pressure_module` は以下を読まない。

```text
O_t
O_t_action_view
O_t_exploration_view
residual_noise_log
v8 local audit
exploration candidates
exploration projection
exploration sidecar
action surface
action candidates
coactivation gate
ActionFrame
ActionModule result
world transition result
```

## 書き戻し禁止

`upper_pressure_module` は以下を書き換えない。

```text
world state
world trace
G_t
K_t
formal_packet
O_t
parameter canonical state
ActionFrame
```

## 監査条件

`upper_pressure_audit` は以下を満たす必要がある。

```text
formal_input_is_gk_only == True
formal_lower_leak_count == 0
m_lower_leak_count == 0
pressure_lower_leak_count == 0
upper_uses_ot == False
upper_uses_v8 == False
upper_uses_exploration == False
upper_uses_action_surface == False
upper_uses_action_result == False
truth_used_for_m_observation == False
truth_used_for_pressure_candidate == False
upper_writeback_performed == False
audit_status == pass
```

## O_tとの関係

Task5でも `O_t` は下位局所観測面である。
`O_t` は上位圧の正式入力ではない。

```text
O_t → action_surface_planning / exploration / audit
O_t ↛ upper_pressure_module
```

## explorationとの関係

Task5時点では探索は placeholder boundary である。
探索結果は上位圧生成に戻さない。

```text
exploration ↛ upper_pressure_module
```

## ActionModuleとの関係

`upper_pressure_module` は ActionModule 結果を見ない。
ActionModule は ActionFrame のみを読む。

```text
upper_pressure_module ↛ ActionModule result
ActionModule ← ActionFrame only
```
