# Module Boundary Contract — Task7 Exploration Module RC1

## exploration_module

### 入力許可

- G/K summary
- O_t exploration view
- residual noise ledger
- shadow parameter state summary

### 禁止

- upper_pressure_module の formal input へ探索結果を混ぜること
- ParameterBox を探索結果で更新すること
- world / G/K / O_t へ書き戻すこと
- ActionModule を呼ぶこと
- ActionFrameを作ること

### 出力

- candidates: 候補軸・根拠・score・risk
- sandbox: counterfactual screening結果
- decision: pass/watch/block相当、ただしTask7ではaction projectionを作らない

## boundary guard変更

Task15では placeholder のため `passed_count == 0` を要求していたが、Task7では sandbox verified な候補のpassは許す。したがって guard 条件は以下に変更した。

```text
unverified_candidate_can_pass == false
all_passed_candidates_verified == true
exploration_generates_pressure == false
exploration_updates_parameter_box == false
exploration_executes_action == false
```
