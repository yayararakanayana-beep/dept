# Module Boundary Contract - Task14 RC1

## Action execution boundary

`action_execution_module` has two internal responsibilities:

```text
action_frame_builder
  pre-gate candidates + gate decision -> ActionFrame

action_module_adapter
  ActionFrame -> ActionModule/world_adapter.step
```

The two are kept in one external module because the boundary belongs together:
`ActionFrame` is the only formal input to ActionModule.

## Required guarantees

```text
ActionFrame is created only after coactivation gate.
ActionModule is called only by action_module_adapter.
ActionModule receives ActionFrame only.
ActionModule does not receive G/K.
ActionModule does not receive O_t.
ActionModule does not receive v8 internals.
ActionModule does not receive exploration sidecar.
ActionModule does not receive parameter box.
ActionModule does not write canonical parameters.
ActionModule does not write G/K.
ActionModule does not write O_t.
```

## Audit table

Task14 adds `action_execution_audit` with one row per cycle.

Required fields include:

```text
action_execution_contract
audit_status
source_action_candidate_rows
action_frame_rows
coactivation_gate_decision
coactivation_gate_applied_before_actionframe
action_frame_contract_present
actionmodule_called_by_adapter
actionmodule_input_contract
actionmodule_received_actionframe_only
direct_gk_input_to_actionmodule
direct_ot_input_to_actionmodule
direct_v8_input_to_actionmodule
direct_exploration_sidecar_input_to_actionmodule
direct_parameter_box_input_to_actionmodule
canonical_parameter_write_performed
gk_writeback_performed
ot_writeback_performed
world_step_performed_by_adapter
world_t_before
world_t_after
```
