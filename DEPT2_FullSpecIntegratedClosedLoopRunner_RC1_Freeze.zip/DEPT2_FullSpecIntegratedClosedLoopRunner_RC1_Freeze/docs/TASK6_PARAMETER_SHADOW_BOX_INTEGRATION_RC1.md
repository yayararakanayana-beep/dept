# Task6: parameter_shadow_box 統合 RC1

## 目的

Task6 は、Task5 で固定した `upper_pressure_module` の G/K-only 境界を保持したまま、
`parameter_shadow_box` を正式な shadow-only パラメーター仮更新モジュールとして強化する。

中心契約は次の通り。

```text
formal G/K packet
  +
H11 local pressure field
  ↓
bounded shadow update
  ↓
shadow parameter state carryover
  ↓
parameter_shadow_audit
```

ここでの更新は **仮更新のみ** である。
本更新、canonical theta write、world write、G/K writeback は行わない。

## 実装内容

### 1. parameter_shadow_box の強化

`dept2_fullspec_runner_rc1/modules/parameter_shadow_box.py` を強化し、次を追加した。

- `parameter_shadow_audit` の出力
- previous / next shadow fingerprint
- shadow carryover continuity check
- rollback-ready flag
- commit blocked flag
- canonical theta write禁止 flag
- world write禁止 flag
- G/K writeback禁止 flag
- bounded delta check
- lower artifact leakage rejection

### 2. shadow state の位置づけ

`LowerParameterGovernanceBox` の内部状態は、Task6では canonical theta ではなく、runner が所有する shadow state として扱う。

```text
allowed:
  shadow carryover
  bounded theta delta
  rollback-ready trace
  audit logging

blocked:
  lower_parameter_commit
  canonical_theta_write
  world_state_write
  canonical_GK_writeback
  deployment claim
```

### 3. parameter_shadow_audit

1 cycle ごとに `parameter_shadow_audit` を出す。

主な列:

```text
parameter_shadow_contract
shadow_cycle_index
formal_packet_fingerprint
h11_pressure_fingerprint
previous_shadow_fingerprint
new_shadow_fingerprint
previous_shadow_fingerprint_matches_last_cycle
shadow_carryover_enabled
shadow_state_rows
parameter_update_rows
updated_parameter_rows
max_abs_theta_delta
total_abs_theta_delta
max_allowed_step_delta
bounded_delta_pass
rollback_ready
commit_status
commit_gate_passed
lower_parameter_update_committed
canonical_write_performed
canonical_theta_written
world_write_performed
world_state_written
gk_writeback_performed
canonical_gk_written
truth_used_for_parameter_update
audit_status
```

### 4. BoundaryGuard 追加

`validate_parameter_shadow_audit()` を追加した。

検査する境界:

```text
shadow_carryover_enabled == True
previous_shadow_fingerprint_matches_last_cycle == True
bounded_delta_pass == True
rollback_ready == True
commit_status == not_committed
commit_gate_passed == False
lower_parameter_update_committed == False
canonical_write_performed == False
canonical_theta_written == False
world_write_performed == False
world_state_written == False
gk_writeback_performed == False
canonical_gk_written == False
truth_used_for_parameter_update == False
audit_status == pass
```

### 5. cycle audit への統合

`cycle_audit_row` に以下を追加した。

```text
parameter_shadow_audit_rows
parameter_shadow_status
shadow_carryover_enabled
shadow_bounded_delta_pass
shadow_rollback_ready
shadow_commit_status
shadow_max_abs_delta
shadow_total_abs_delta
shadow_updated_parameter_rows
shadow_previous_fingerprint
shadow_new_fingerprint
```

これにより、1行のcycle auditから shadow parameter の境界状態を確認できる。

## 実行順序上の位置

Task6 時点の主線は以下。

```text
world_adapter
  ↓
gk_builder
  ↓
ot_observation_module
  ↓
upper_pressure_module
  ↓
pressure_translation_module
  ↓
parameter_shadow_box
  ↓
exploration placeholder
  ↓
action_surface_planning_module
  ↓
coactivation_gate_module
  ↓
action_execution_module
  ↓
world_adapter.step
  ↓
audit_ledger_module
```

概念上は `parameter_shadow_box` は weak pressure から仮更新を担う。
ただし既存RC1実装の `LowerParameterGovernanceBox` は H11 local pressure field を入力に使うため、実行順としては `pressure_translation_module` の後に呼ぶ。

これは本更新を意味しない。
Task6でも `shadow carryover` のみであり、canonical write は禁止である。

## 禁止事項

Task6で固定した禁止事項:

```text
parameter_shadow_box が canonical theta を書かない
parameter_shadow_box が world state を書かない
parameter_shadow_box が G/K へ書き戻さない
parameter_shadow_box が O_t / v8 / exploration / action 情報を直接入力にしない
parameter_shadow_box が本更新済み claim を出さない
ActionModule が shadow state を直接更新しない
```

## 確認実行

```bash
python runner/run_fullspec_integrated_closed_loop_runner_rc1.py \
  --steps 3 \
  --seed 42 \
  --scenario normal \
  --out results
```

確認結果:

```text
cycle_rows: 3
action_frame_rows: 440
ot_native_rows: 54
ot_action_view_rows: 54
ot_exploration_view_rows: 54
residual_noise_rows: 54
upper_pressure_audit_rows: 3
parameter_shadow_audit_rows: 3
upper_input_is_gk_only: true
upper_pressure_audit_passed: true
parameter_shadow_audit_passed: true
shadow_carryover_enabled: true
shadow_commit_status_all_not_committed: true
canonical_write_performed: false
world_write_performed: false
gk_writeback_performed: false
boundary_violation_count: 0
all_noise_retained: true
all_sanity_checks_passed: true
```

## テスト

```bash
pytest -q tests
```

結果:

```text
19 passed
```

## Task6 の範囲

Task6 は `parameter_shadow_box` の正式統合であり、探索本統合はまだ行わない。
探索モジュールは引き続き placeholder boundary である。

次の自然なタスクは `Task11: pressure_translation_module 統合` である。
