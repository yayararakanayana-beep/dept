# Task11: Action Surface Planning Integration RC1

## Goal

Strengthen the modular FullSpec runner by making `action_surface_planning_module`
an explicit pre-ActionFrame layer.

The module receives:

```text
O_t_action_view
+ graph_objects
+ PressureIntentBundle
+ shadow parameter summary
+ exploration projection placeholder
```

and produces:

```text
action affordance
pre-gate action candidates
local observation needs
action_surface_planning_audit
```

## Boundary

Task11 keeps the following boundaries fixed:

```text
ActionSurfacePlanning is not ActionModule.
ActionSurfacePlanning does not create ActionFrame.
ActionSurfacePlanning does not call ActionModule.
ActionSurfacePlanning does not write canonical parameters.
ActionSurfacePlanning does not write world state.
ActionSurfacePlanning does not write G/K.
O_t_action_view is used only for planning/local-observation needs,
not as ActionModule direct input and not as upper-pressure formal input.
```

## Implementation notes

The existing `ActionSurface` and repaired diagnostic policy are retained.
Task11 wraps them with:

- explicit `planning_stage`,
- candidate status = `pre_gate_candidate`,
- `local_observation_needs`,
- `action_surface_planning_audit`,
- boundary guard validation.

This means the existing action-candidate generation remains available, but it is
now audited as a candidate layer rather than silently blending into ActionFrame
or ActionModule execution.

## Validation

Task11 validates that:

- action candidates are emitted,
- local observation needs are emitted,
- candidates remain pre-ActionFrame,
- planning does not call ActionModule,
- planning does not write canonical/world/GK state,
- O_t_action_view is used for planning only,
- cycle audit records the planning status.

## Scope limit

Task11 does not implement the full exploration module or final coactivation gate
logic. Those remain downstream integration tasks.
