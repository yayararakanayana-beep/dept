# Module Boundary Contract - Task3 RC1

## Task3で強化した境界

### world_adapter boundary

`world_adapter` は疑似現実状態の唯一の所有者です。

- `snapshot()` は読み取り用traceを返す
- `step()` はActionFrame由来の作用結果だけを世界に適用する
- G/K、O_t、上位圧、探索sidecar、parameter shadowを直接読まない
- G/KやO_tからworldへの書き戻しは禁止

### gk_builder boundary

`gk_builder` はworld traceから G_t / K_t を作るだけです。

- 入力は `entity_trace` と `relation_trace`
- 出力は `gt`, `kt`, `formal_packet`, `gk_build_audit`
- 入力traceは変更しない
- G/Kはworldへ書き戻さない
- formal_packetに lower artifact は混ぜない

### formal upper input boundary

`upper_pressure_module` に渡すformal inputは G/K のみです。

禁止prefix:

```text
ot_
v8_
exploration_
graph_object
action_surface
final_gate
action_frame
```

Task3では、formal inputにlower artifactが混ざっていないことを `formal_lower_leak_count` と `boundary_guard` で検査します。

## 継続して守る境界

- ParameterBoxはshadow-only
- canonical writeは禁止
- ActionModuleはActionFrameだけを読む
- exploration moduleはまだplaceholder boundary
- O_tはformal upper inputではない
