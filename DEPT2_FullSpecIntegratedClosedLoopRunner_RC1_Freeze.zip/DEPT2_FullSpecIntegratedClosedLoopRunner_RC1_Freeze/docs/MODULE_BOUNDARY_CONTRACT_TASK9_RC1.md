# Module Boundary Contract - Task11 RC1

## Fixed from earlier tasks

- `world_adapter` owns pseudo-reality state and trace.
- `gk_builder` derives G/K from world trace and never writes back.
- `ot_observation_module` creates lower local O_t views and residual/noise ledger, but is not upper formal input.
- `upper_pressure_module` uses formal G/K only.
- `parameter_shadow_box` performs bounded shadow carryover only; no canonical commit.

## Task11 addition

`pressure_translation_module` is a non-compressive translator from upper weak pressure to lower-readable H11-local pressure and semantic pressure intent.

### Allowed

```text
M_t + weak pressure
  -> H11 local pressure field
  -> PressureIntentBundle
```

### Forbidden

```text
pressure_translation_module -> ActionFrame
pressure_translation_module -> ActionModule
pressure_translation_module -> O_t direct input
pressure_translation_module -> v8 direct input
pressure_translation_module -> exploration direct input
pressure_translation_module -> G/K writeback
pressure_translation_module -> world writeback
pressure_translation_module -> canonical parameter write
```

## Audit fields

The required audit row includes:

- `component_identity_preserved`
- `component_direction_preserved`
- `noncompressive_translation_passed`
- `compression_allowed_before_action_planner`
- `action_frame_created_by_translation`
- `actionmodule_called_by_translation`
- `translation_writeback_performed`
- `pressure_translation_audit_status`

All Task11 validation requires:

```text
component_identity_preserved = true
component_direction_preserved = true
noncompressive_translation_passed = true
compression_allowed_before_action_planner = false
action_frame_created_by_translation = false
actionmodule_called_by_translation = false
translation_writeback_performed = false
pressure_translation_audit_status = pass
```
