# Module Boundary Contract - Task18 Ablation Validation RC1

Task18 は ablation diagnostic であり、部品を外す場合も境界契約を破らない。

## 共通禁止事項

- G/K writeback 禁止
- O_t writeback 禁止
- world state writeback 禁止
- canonical parameter write 禁止
- ActionModuleへのG/K/O_t/v8/sidecar/ParameterBox直接入力禁止
- unverified exploration candidate のprojection化禁止
- sidecar圧縮禁止
- gate迂回によるActionFrame生成禁止

## Ablation別契約

### no exploration module

探索候補生成を無効化する。zero-source監査は残す。基本閉ループは継続する。

### no residual noise ledger signal

ノイズ行は保持する。未分類ノイズを捨てない。ただし、寄与を見るため信号強度をゼロ化する。

### no local audit signal

v8局所監査の境界行は残す。v8はG/K生成器にも上位圧入力にもならない。ただし、local confirmation signalを無効化する。

### no exploration bridge projection

full sidecarを非圧縮保持する。action-readable projectionだけを無効化する。

### no coactivation gate modulation

gate呼び出しは維持する。ActionFrame前にgateがあることは保つ。ただしdecisionをallowに固定し、調整効果を無効化する。

### no parameter shadow delta

shadow-only契約、rollback-ready、no-commitは保つ。ただしshadow deltaをゼロ化する。

## Task18 claim boundary

Task18は診断であり、部品の完全最適性や現実安全性を示さない。
