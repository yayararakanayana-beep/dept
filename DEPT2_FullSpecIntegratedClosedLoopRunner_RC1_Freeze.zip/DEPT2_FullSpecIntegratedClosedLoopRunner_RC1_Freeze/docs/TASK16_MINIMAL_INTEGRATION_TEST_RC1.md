# Task16: Minimal Integration Test RC1

## 目的

Task16 は、Task2〜Task15で統合したFullSpec runnerが、最小条件で破綻せずに回るかを確認する検証層である。

ここでは新しい制御機能を増やさない。確認対象は以下である。

1. 1stepの探索on実行
2. 5stepの探索on実行
3. 5stepの探索off回帰実行

## 検証する境界

- G/Kはworld traceから毎周期生成される
- G/Kへの書き戻しはない
- O_tはG/K生成器でも上位圧formal inputでもない
- residual/noise ledgerは未分類ノイズを捨てない
- upper_pressure_moduleはformal G/Kのみを読む
- parameter_shadow_boxはshadow-onlyで、canonical writeしない
- exploration onでは、sandbox verified + local audit passed の候補だけprojection化される
- exploration offでは、探索候補・projectionは0でよいが、sidecarとzero-source local auditは残る
- ActionModuleはActionFrameだけを読む
- coactivation gateはActionFrame前に必ず通る
- boundary violation reportは空である

## Task16で追加した修正

探索off時に `exploration_local_audit` が完全に空だと、boundary guardが「v8監査欠落」と誤検出していた。
Task16では、探索候補が0件の時も `zero_source_audit_row=True` の監査行を出す。

これにより、探索offは「監査抜け」ではなく、明示的な探索無効化回帰として扱われる。

## 検証行列

| case_id | steps | exploration | 目的 |
|---|---:|---|---|
| one_step_exploration_on | 1 | on | 最小1周回が壊れないか |
| five_step_exploration_on | 5 | on | shadow carryover込みで複数周回が壊れないか |
| five_step_exploration_off | 5 | off | 探索なしでも基本閉ループが壊れないか |

## 実行コマンド

```bash
python validation/task16_minimal_integration_matrix.py results/task16_minimal_matrix
```

個別実行は以下。

```bash
python runner/run_fullspec_integrated_closed_loop_runner_rc1.py --steps 5 --seed 42 --scenario normal --out results
python runner/run_fullspec_integrated_closed_loop_runner_rc1.py --steps 5 --seed 42 --scenario normal --exploration-disabled --out results_off
```

## Task16の範囲外

Task16はstress検証ではない。
以下はTask17以降で扱う。

- 強い外乱
- relation shock
- overpressure
- 探索候補過多
- 複合干渉の本格解決
- ablationによる部品寄与評価
- parameter本更新検証
