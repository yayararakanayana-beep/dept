# Task12: Coactivation Gate Module Integration RC1

## 目的

Task12 の目的は、ActionFrame 生成前に、同一stepで発火する複数の圧力・探索・作用候補・shadow・risk/noise signal を評価し、
安全側の gate decision を出すことです。

## 入力

- `weak_pressure`
- `exploration_projection`
- `action_candidates`
- `action_local_audit`
- `shadow_parameter_state`
- `residual_noise_log`

## 出力

- `coactivation_gate`

主要列:

- `coactivation_gate_decision`: `allow / dampen / defer / block / monitor_only`
- `coactivation_risk_score`
- `pressure_component_score`
- `exploration_component_score`
- `action_component_score`
- `local_risk_component_score`
- `noise_component_score`
- `shadow_component_score`
- `gate_dampening_factor`
- `gate_required_before_actionframe`
- `coactivation_gate_audit_status`

## 判定意味

- `allow`: 低riskなのでそのまま通す。
- `dampen`: 中程度riskなので作用強度を弱めて通す。
- `defer`: 高riskなので今回stepでは遅らせる。
- `block`: かなり高いriskまたはhard block signalなので止める。
- `monitor_only`: 作用候補がないため監視のみ。

## 境界契約

- gate は ActionFrame を作らない。
- gate は ActionModule を呼ばない。
- gate は ParameterBox を更新しない。
- gate は world / G/K / O_t / canonical parameter へ書き戻さない。
- gate は exploration sidecar を ActionModule へ直接渡さない。
- ActionFrame は gate 後にのみ生成される。

## 注意

Task12 gate は RC1 の同時発火門であり、combined interference の完全解決ではありません。
