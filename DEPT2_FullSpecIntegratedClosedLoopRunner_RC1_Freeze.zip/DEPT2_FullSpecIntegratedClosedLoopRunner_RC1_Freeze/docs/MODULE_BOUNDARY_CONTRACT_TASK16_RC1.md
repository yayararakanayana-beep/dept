# Module Boundary Contract Task16 RC1

Task16では、既存13モジュールの境界を維持したまま、最小統合テストで再確認する。

## 追加固定

- exploration-enabled run: verified exploration projection must be present.
- exploration-disabled run: exploration candidates and projection must be empty, but sidecar and zero-source local audit must exist.
- zero-source local audit is not a bypass. It is an explicit audit record saying there were no exploration candidates to audit.
- ActionModule remains ActionFrame-only in both modes.
- Boundary guard must pass in both exploration-on and exploration-off modes.

## 禁止

- exploration off を boundary guard 迂回として扱うこと
- 空のlocal auditを無言で捨てること
- exploration sidecarをActionModuleへ直接渡すこと
- exploration projectionが未検証候補を含むこと
- parameter shadowをcanonicalにcommitすること
