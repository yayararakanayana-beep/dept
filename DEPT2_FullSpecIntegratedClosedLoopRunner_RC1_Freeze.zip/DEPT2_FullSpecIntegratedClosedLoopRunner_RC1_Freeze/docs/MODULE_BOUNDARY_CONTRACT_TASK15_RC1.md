# Module Boundary Contract - Task15 RC1

## Global rule

The runner is a wiring layer. Each module has an input/output contract. The
boundary guard checks these contracts but does not mutate runtime state.

## Diagnostic-only guard

`boundary_guard` may read:

- module audit tables,
- cycle audit row,
- artifact row counts,
- boundary flags.

`boundary_guard` must not write:

- world state,
- G/K,
- O_t,
- ActionFrame,
- canonical parameters.

## Required outputs

```text
boundary_guard_audit
boundary_violation_report
boundary_guard_summary
```

## Failure semantics

A failed invariant becomes a row in `boundary_violation_report` and is also
included in cycle-level boundary violation accounting. Later tasks may connect
this report to rollback or safe-stop logic, but Task15 only reports.
