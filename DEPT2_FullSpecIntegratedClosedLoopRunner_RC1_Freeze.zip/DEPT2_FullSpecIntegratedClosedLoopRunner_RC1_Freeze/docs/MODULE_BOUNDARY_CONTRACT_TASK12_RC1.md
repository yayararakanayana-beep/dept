# Module Boundary Contract - Task12 RC1

## coactivation_gate_module

### Allowed inputs

- weak pressure summary
- thin exploration projection
- pre-gate action candidates
- action-side local audit
- shadow parameter state summary
- residual/noise log summary

### Forbidden operations

- ActionFrame generation
- ActionModule call
- world write
- G/K writeback
- O_t writeback
- canonical parameter write
- ParameterBox update
- exploration sidecar direct input to ActionModule

### Required audit facts

- `gate_required_before_actionframe == true`
- `coactivation_gate_audit_status == pass`
- `coactivation_gate_decision in {allow, dampen, defer, block, monitor_only}`
- `action_frame_created_by_gate == false`
- `actionmodule_called_by_gate == false`
- writeback flags all false
