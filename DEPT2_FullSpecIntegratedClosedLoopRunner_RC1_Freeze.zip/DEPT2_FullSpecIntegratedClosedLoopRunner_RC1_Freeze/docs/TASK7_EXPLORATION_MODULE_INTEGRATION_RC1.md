# Task7: exploration_module 統合 RC1

## 目的

`exploration_module` を placeholder から、以下を持つ実モジュールへ強化した。

1. 探索候補生成
2. sandbox counterfactual screening
3. decision gate
4. lifecycle-ready audit fields
5. boundary guard連携

## 入力

- `G_t / K_t`
- `O_t_exploration_view`
- `residual_noise_log`
- `shadow_parameter_state`

## 出力

- `exploration_candidates`
- `exploration_sandbox`
- `exploration_decision`

## 守る境界

- 探索は圧を作らない。
- 探索は作用を実行しない。
- 探索は本パラメーターを更新しない。
- 探索は G/K / O_t / world に書き戻さない。
- `sandbox_pass` は sandbox verified な候補だけに許す。
- `unverified_candidate_can_pass` は常に false。

## Task7で意図的に保留したもの

- 探索bridge projectionの本統合: Task10
- 探索候補への本格 v8 local audit: Task8
- 同時発火門の本格統合: Task12

## 実行確認

`steps=3, seed=42, scenario=exploration_loss, exploration_enabled=True` で実行し、探索候補・sandbox・decisionが生成され、境界違反0で完了した。
