# Task5: upper_pressure_module 統合 RC1

## 目的

Task5 は、Task4 で明示化した `O_t` と `residual_noise_ledger` を保持したまま、
`upper_pressure_module` を正式な上位圧生成モジュールとして強化する。

中心契約は次の通り。

```text
formal G/K packet
  ↓
M_t
  ↓
weak pressure
```

`upper_pressure_module` の正式入力は `G_t / K_t` から作られた `formal_packet` のみである。
`O_t`、v8、探索、作用面、ActionFrame、ActionModule結果は混入させない。

## 実装内容

### 1. upper_pressure_module の強化

`dept2_fullspec_runner_rc1/modules/upper_pressure_module.py` を強化し、次を追加した。

- formal G/K packet の必須列検査
- O_t / v8 / exploration / graph_object / action_surface / action / final_gate / coactivation の混入拒否
- formal packet fingerprint の記録
- `M_t` への provenance annotation
- `weak_pressure` への provenance annotation
- `upper_pressure_audit` の出力

### 2. upper_pressure_audit の追加

1 cycle ごとに `upper_pressure_audit` を出す。

主な列:

```text
upper_pressure_contract
formal_input_contract_seen
formal_packet_fingerprint
formal_source_trace_fingerprint
formal_source_world_t
formal_rows
formal_lower_leak_count
formal_input_is_gk_only
m_rows
pressure_rows
m_lower_leak_count
pressure_lower_leak_count
approved_pressure_component_count
approved_pressure_l1_sum
upper_uses_ot
upper_uses_v8
upper_uses_exploration
upper_uses_action_surface
upper_uses_action_result
truth_used_for_m_observation
truth_used_for_pressure_candidate
upper_writeback_performed
audit_status
```

### 3. BoundaryGuard 追加

`validate_upper_pressure_audit()` を追加した。

検査する境界:

```text
formal_lower_leak_count == 0
m_lower_leak_count == 0
pressure_lower_leak_count == 0
formal_required_columns_missing_count == 0
upper_uses_ot == False
upper_uses_v8 == False
upper_uses_exploration == False
upper_uses_action_surface == False
upper_uses_action_result == False
truth_used_for_m_observation == False
truth_used_for_pressure_candidate == False
upper_writeback_performed == False
audit_status == pass
```

### 4. cycle audit への統合

`cycle_audit_row` に以下を追加した。

```text
upper_pressure_audit_rows
upper_input_is_gk_only
upper_audit_status
upper_formal_leak_count
upper_pressure_l1
```

これにより、1行のcycle auditから上位圧境界が通ったか確認できる。

## 実行順序上の位置

Task5 時点の主線は以下。

```text
world_adapter
  ↓
gk_builder
  ↓
ot_observation_module
  ↓
upper_pressure_module
  ↓
pressure_translation_module
  ↓
parameter_shadow_box
  ↓
exploration placeholder
  ↓
action_surface_planning_module
  ↓
coactivation_gate_module
  ↓
action_execution_module
  ↓
world_adapter.step
  ↓
audit_ledger_module
```

概念上は `parameter_shadow_box` は weak pressure から仮更新を担う。
ただし既存RC1実装の `LowerParameterGovernanceBox` は H11 local pressure field を入力に使うため、実行順としては `pressure_translation_module` の後に呼ぶ。

これは本更新を意味しない。
Task5でも `shadow carryover` のみであり、canonical write は禁止である。

## 禁止事項

Task5で固定した禁止事項:

```text
upper_pressure_module に O_t を混ぜない
upper_pressure_module に v8 を混ぜない
upper_pressure_module に exploration を混ぜない
upper_pressure_module に action_surface を混ぜない
upper_pressure_module に ActionFrame / ActionModule 結果を混ぜない
M_t / weak pressure から G/K や world へ書き戻さない
truth情報を M_t / weak pressure に使わない
```

## 確認実行

```bash
python runner/run_fullspec_integrated_closed_loop_runner_rc1.py \
  --steps 3 \
  --seed 42 \
  --scenario normal \
  --out results
```

確認結果:

```text
cycle_rows: 3
action_frame_rows: 440
ot_native_rows: 54
ot_action_view_rows: 54
ot_exploration_view_rows: 54
residual_noise_rows: 54
upper_pressure_audit_rows: 3
upper_input_is_gk_only: true
upper_pressure_audit_passed: true
boundary_violation_count: 0
all_noise_retained: true
all_sanity_checks_passed: true
```

## テスト

```bash
pytest -q \
  tests/test_fullspec_task3_world_gk_integration.py \
  tests/test_fullspec_task4_ot_noise_ledger.py \
  tests/test_fullspec_task5_upper_pressure.py
```

結果:

```text
14 passed
```

## Task5 の範囲

Task5 は `upper_pressure_module` の正式統合であり、探索本統合はまだ行わない。
探索モジュールは引き続き placeholder boundary である。

次の自然なタスクは `Task6: parameter_shadow_box 統合` である。
