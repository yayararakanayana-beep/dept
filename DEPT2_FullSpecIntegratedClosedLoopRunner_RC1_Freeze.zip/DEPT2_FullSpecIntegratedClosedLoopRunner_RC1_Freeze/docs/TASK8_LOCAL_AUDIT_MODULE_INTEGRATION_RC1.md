# Task8: local_audit_module Integration RC1

## 目的

Task8では、Task7でplaceholder性が残っていた局所監査を、共通の `local_audit_module` として統合する。

対象は2系統。

1. `exploration_v8_audit`  
   探索候補を探索橋へ渡す前に局所確認する。

2. `action_v8_check`  
   作用候補をActionFrameへ変換する前に局所確認する。

## 入力

- 探索側: `exploration_candidates`, `O_t_exploration_view`, `shadow_parameter_state`
- 作用側: `action_candidates`, `graph_objects`, `shadow_parameter_state`

## 出力

- `exploration_local_audit`
- `action_local_audit`

## 境界

- v8はG/K生成器ではない。
- v8は上位圧formal inputではない。
- v8は圧を生成しない。
- v8は作用を実行しない。
- v8はパラメーターBOXを更新しない。
- v8はworld / G/K / O_t / canonical parameterへ書き戻さない。

## 監査

Task8では、boundary guard に `BG10b_local_audit_v8_boundary` を追加した。

このルールは、探索側・作用側のlocal auditがどちらも存在し、`v8_support_status == pass` であり、v8が境界外の役割を持っていないことを確認する。
