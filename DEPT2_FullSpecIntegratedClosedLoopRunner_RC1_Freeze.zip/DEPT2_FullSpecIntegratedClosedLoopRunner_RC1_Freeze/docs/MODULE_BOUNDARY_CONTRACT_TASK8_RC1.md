# Module Boundary Contract — Task8 Local Audit RC1

## local_audit_module

### 許可される入力

- exploration candidates
- O_t exploration view
- action candidates
- graph objects / O_t action-derived local fields
- shadow parameter summary

### 許可される出力

- exploration local audit rows
- action local audit rows
- v8 confidence / conflict / unresolved / requested flags
- local audit boundary flags

### 禁止

- G/K生成
- 上位圧formal input化
- 圧生成
- ActionModule呼び出し
- parameter update
- world write
- G/K writeback
- O_t writeback
- canonical parameter write
- exploration sidecar圧縮
- ActionFrame生成

### 後続タスクへの接続

- Task10: exploration_bridge_module が `exploration_local_audit` を使って projection / sidecar を強化する。
- Task12: coactivation_gate_module が action/exploration local audit を同時発火門のrisk signalとして使う。
